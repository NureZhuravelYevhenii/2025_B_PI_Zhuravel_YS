﻿using MainAbstractions.Modules;
using MainAbstractions.Modules.Content;

namespace MainAbstractions.Builders;

/// <summary>
/// Class that creates physical files in a specific environment with some result.
/// </summary>
public interface IContentBuilder
{
    string ContentBuilderType { get; }
    string ContentType { get; }

    /// <summary>
    /// Parse modules seeded with dependencies in code in a specific environment.
    /// </summary>
    /// <param name="modules">Seeded with dependencies modules.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    /// <returns></returns>
    Task<Stream?> ParseInCodeAsync(IEnumerable<RawContent> rawContents, CancellationToken cancellationToken = default);
}
