﻿using MainAbstractions.Modules.Content;

namespace MainAbstractions.Modules;

/// <summary>
/// Sub module.
/// </summary>
public interface ISubModule : IModuleBase
{

    /// <summary>
    /// Creates content that need to be parsed by module.
    /// </summary>
    /// <param name="token">Cancellation token.</param>
    Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default);
}
