﻿using MainAbstractions.Modules.Content;

namespace MainAbstractions.Modules.Helpers;

/// <summary>
/// Provides utility methods for parsing module contents and facilitating conversions between various module types.
/// </summary>
public static class ModuleHelper
{
    /// <summary>
    /// Parses code in <see cref="IModule"/> and <see cref="ISubModule"/> into <see cref="IContent"/>.
    /// </summary>
    /// <param name="subModules">SubModules which code should be processed.</param>
    /// <param name="cancellationToken">Cancellation token.</param>
    public static async Task<IEnumerable<IContent>> ExecuteSubModulesAsync(IEnumerable<ISubModule> subModules, CancellationToken token = default)
    {
        var tasks = subModules.Select(subModule => subModule.ParseInCodeAsync(token)).ToList();
        await Task.WhenAll(tasks);

        return tasks.SelectMany(task => task.Result).ToList();
    }

    /// <summary>
    /// <summary>
    /// Converts the primary <see cref="IContent"/> instance to a specified type.
    /// </summary>
    /// <param name="contents">The primary content to be processed, represented as an <see cref="IContent"/> instance.</param>
    /// <param name="handlers">An array of content processors that define how the content will be transformed or processed.</param>
    public static async Task<IEnumerable<TContent>> ProcessContentWithHandlersAsync<TContent>(
        IEnumerable<IContent> contents,
        IDictionary<Type, Func<IContent, Task<IEnumerable<TContent>>>> handlers)
    {
        var contentTasks = new List<Task<IEnumerable<TContent>>>();
        foreach (var content in contents)
        {
            if (!handlers.TryGetValue(content.GetType(), out Func<IContent, Task<IEnumerable<TContent>>>? handler) || handler is null)
                continue;

            contentTasks.Add(handler(content));
        }

        await Task.WhenAll(contentTasks);

        return contentTasks.SelectMany(task => task.Result).ToList();
    }
}
