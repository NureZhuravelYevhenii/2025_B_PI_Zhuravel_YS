﻿namespace MainAbstractions.Modules.Metadata;

/// <summary>
/// Information about module.
/// </summary>
public class ModuleMetadata
{
    /// <summary>
    /// Name of the module.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    public string[] AcceptableContent { get; set; } = null!;
    public string[] ProducedContent { get; set; } = null!;
}