﻿namespace MainAbstractions.Modules.Metadata.Attributes;

public class IgnorePropertyAttribute : Attribute
{
}
