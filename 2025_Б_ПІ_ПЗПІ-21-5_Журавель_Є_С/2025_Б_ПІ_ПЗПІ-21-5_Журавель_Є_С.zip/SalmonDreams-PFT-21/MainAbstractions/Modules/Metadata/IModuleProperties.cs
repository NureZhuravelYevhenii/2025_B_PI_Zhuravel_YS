﻿namespace MainAbstractions.Modules.Metadata;

/// <summary>
/// Module's properties.
/// </summary>
public interface IModuleProperties { }
