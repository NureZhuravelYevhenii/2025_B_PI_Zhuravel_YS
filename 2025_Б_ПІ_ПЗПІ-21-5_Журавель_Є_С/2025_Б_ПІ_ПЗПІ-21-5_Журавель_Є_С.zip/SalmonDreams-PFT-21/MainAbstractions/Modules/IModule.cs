﻿using MainAbstractions.Modules.Content;

namespace MainAbstractions.Modules;

/// <summary>
/// Module.
/// </summary>
public interface IModule : IModuleBase
{
    /// <summary>
    /// Creates ready to creation content.
    /// </summary>
    /// <param name="token">Cancellation token.</param>
    Task<IEnumerable<RawContent>> ParseInCodeAsync(CancellationToken token = default);
}
