﻿using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using MainAbstractions.Modules.Metadata;

namespace MainAbstractions.Modules.BaseClasses;

/// <summary>
/// Defines base submodule structure.
/// </summary>
public class BaseSubModule<TProperties> : ISubModule
    where TProperties : class, IModuleProperties
{
    private IDictionary<Type, Func<IContent, Task<IEnumerable<IContent>>>> _handlers = new Dictionary<Type, Func<IContent, Task<IEnumerable<IContent>>>>();

    // <summary>
    /// SubModule's metadata.
    /// </summary>
    public virtual ModuleMetadata Metadata { get; set; } = null!;

    /// <summary>
    /// SubModule's properties relevant for a specific module generation.
    /// </summary>
    public virtual IModuleProperties Properties { get; set; } = null!;

    /// <summary>
    /// Submodules relevant for a specific submodule generation.
    /// </summary>
    public virtual IEnumerable<ISubModule> Modules { get; set; } = [];

    protected virtual TProperties PropertiesWithType => Properties as TProperties 
        ?? throw new ArgumentNullException($"Unable to get {typeof(TProperties).Name} properties.");

    /// <summary>
    /// Retrieves the contents from all the nested <see cref="ISubModule"/>.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    public virtual async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        var contents = await ModuleHelper.ExecuteSubModulesAsync(Modules, token);
        var newContents = await ModuleHelper.ProcessContentWithHandlersAsync(contents, _handlers);
        return contents.Concat(newContents).ToList();
    }

    protected void RegisterHandler<TType>(Func<TType, ICollection<IContent>, Task> handler)
        where TType : class, IContent
    {
        _handlers[typeof(TType)] = async (IContent rawContent) => 
        {
            var contents = new List<IContent>();
            var content = rawContent as TType;
            if (content is null)
                return contents;

            await handler(content, contents);

            return contents;
        };
    }
}
