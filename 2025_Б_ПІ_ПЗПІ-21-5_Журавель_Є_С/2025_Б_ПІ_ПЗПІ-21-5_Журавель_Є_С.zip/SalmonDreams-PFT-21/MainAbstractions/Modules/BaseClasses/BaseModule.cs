﻿using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using MainAbstractions.Modules.Metadata;

namespace MainAbstractions.Modules.BaseClasses;

/// <summary>
/// Defines base module structure.
/// </summary>
public class BaseModule<TProperties> : IModule
    where TProperties : class, IModuleProperties
{
    private IDictionary<Type, Func<IContent, Task<IEnumerable<RawContent>>>> _handlers { get; set; } = new Dictionary<Type, Func<IContent, Task<IEnumerable<RawContent>>>>();

    /// <summary>
    /// Module's metadata.
    /// </summary>
    public virtual ModuleMetadata Metadata { get; set; } = null!;

    /// <summary>
    /// Module's properties relevant for a specific module generation.
    /// </summary>
    public virtual IModuleProperties Properties { get; set; } = null!;

    /// <summary>
    /// Submodules relevant for a specific module generation.
    /// </summary>
    public virtual IEnumerable<ISubModule> Modules { get; set; } = [];

    protected virtual TProperties? PropertiesWithType => Properties as TProperties;

    /// <summary>
    /// Retrieves the contents from all the nested <see cref="ISubModule"/>.
    /// </summary>
    /// <param name="cancellationToken">Cancellation token.</param>
    public virtual async Task<IEnumerable<RawContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        var contents = await ModuleHelper.ExecuteSubModulesAsync(Modules, token);
        var newContents = await ModuleHelper.ProcessContentWithHandlersAsync(contents, _handlers);
        return newContents;
    }

    protected void RegisterHandler<TType>(Func<IContent, Task<IEnumerable<RawContent>>> handler)
    {
        _handlers[typeof(TType)] = handler;
    }
}
