﻿using MainAbstractions.Modules.Metadata;

namespace MainAbstractions.Modules
{
    /// <summary>
    /// Module base.
    /// </summary>
    public interface IModuleBase
    {
        /// <summary>
        /// Module metadata.
        /// </summary>
        ModuleMetadata Metadata { get; set; }

        /// <summary>
        /// Module properties
        /// </summary>
        IModuleProperties Properties { get; set; }

        /// <summary>
        /// Sub modules.
        /// </summary>
        IEnumerable<ISubModule> Modules { get; set; }
    }
}
