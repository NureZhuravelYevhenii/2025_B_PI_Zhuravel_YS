﻿namespace MainAbstractions.Modules.Content;

/// <summary>
/// Content ready for creation in specific environment.
/// </summary>
public class RawContent
{
    /// <summary>
    /// Name (location, etc.) of the file.
    /// </summary>
    public string Name { get; set; } = string.Empty;
    
    /// <summary>
    /// Content of the file.
    /// </summary>
    public byte[] Content { get; set; } = [];
}
