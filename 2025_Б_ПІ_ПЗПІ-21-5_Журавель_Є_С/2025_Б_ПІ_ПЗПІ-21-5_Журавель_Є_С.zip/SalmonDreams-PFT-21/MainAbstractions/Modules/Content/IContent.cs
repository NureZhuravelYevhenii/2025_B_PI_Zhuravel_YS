﻿namespace MainAbstractions.Modules.Content;

/// <summary>
/// Content.
/// </summary>
public interface IContent { }
