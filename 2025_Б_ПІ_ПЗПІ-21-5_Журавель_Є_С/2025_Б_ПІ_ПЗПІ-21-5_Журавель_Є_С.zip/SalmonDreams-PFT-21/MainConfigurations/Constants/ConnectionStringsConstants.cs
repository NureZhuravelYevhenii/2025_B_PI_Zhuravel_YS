﻿namespace MainConfigurations.Constants;

/// <summary>
/// Provides constants for connection strings.
/// </summary>
public static class ConnectionStringsConstants
{
    /// <summary>
    /// The connection string for modules.
    /// </summary>
    public const string ModuleConnectionString = "ModulesConnectionString";
}
