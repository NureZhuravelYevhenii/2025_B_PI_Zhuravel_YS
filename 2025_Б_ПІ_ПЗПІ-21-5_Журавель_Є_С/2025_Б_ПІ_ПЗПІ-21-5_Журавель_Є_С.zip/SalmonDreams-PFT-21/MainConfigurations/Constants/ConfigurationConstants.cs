﻿namespace MainConfigurations.Constants;

/// <summary>
/// Provides constants for configuration file names.
/// </summary>
public static class ConfigurationConstants
{
    /// <summary>
    /// The name of the main application configuration JSON file.
    /// </summary>
    public const string AppConfigurationJsonFileName = "appsettings.json";

    /// <summary>
    /// The format string for environment-specific application configuration JSON files.
    /// </summary>
    public const string AppConfigurationJsonEnvironmentFormatFileName = "appsettings.{0}.json";
}

