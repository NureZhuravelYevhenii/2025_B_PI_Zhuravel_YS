﻿namespace MainConfigurations.Constants;

/// <summary>
/// Provides constants for module metadata.
/// </summary>
public static class ModuleConstants
{
    /// <summary>
    /// The file name for module metadata.
    /// </summary>
    public const string ModuleMetadataFileName = "desc.json";
}
