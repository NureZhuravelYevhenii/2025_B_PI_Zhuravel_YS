﻿using DotNetModule.Entities;
using MainAbstractions.Modules.Content;

namespace DotNetModule.Abstractions;

/// <summary>
/// Defines a builder interface for constructing a Visual Studio solution file.
/// </summary>
public interface ISolutionBuilder
{
    /// <summary>
    /// Adds one or more projects to the solution.
    /// </summary>
    /// <param name="projectEntries">A collection of project entries, each containing the name, path, and GUID of a project.</param>
    /// <returns>The current instance of <see cref="ISolutionBuilder"/> for method chaining.</returns>
    ISolutionBuilder WithProjects(IEnumerable<ProjectEntry> projectEntries);

    /// <summary>
    /// Builds the solution file and returns the generated content.
    /// </summary>
    /// <returns>A <see cref="RawContent"/> object containing the constructed solution file content.</returns>
    RawContent Build();
}
