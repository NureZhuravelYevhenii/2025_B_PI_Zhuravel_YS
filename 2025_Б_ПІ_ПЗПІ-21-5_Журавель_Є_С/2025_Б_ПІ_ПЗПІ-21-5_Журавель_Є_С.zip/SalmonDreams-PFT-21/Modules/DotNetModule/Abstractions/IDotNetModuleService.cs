﻿using MainAbstractions.Modules.Content;

namespace DotNetModule.Abstractions;

/// <summary>
/// Service for creating and configuring ASP.NET modules.
/// </summary>
public interface IDotNetModuleService
{
    /// <summary>
    /// Creates a <see cref="RawContent"/> based on the specified <paramref name="contents"/> configuration.
    /// </summary>
    Task<IEnumerable<RawContent>> GetRawContents(CancellationToken token = default);
}
