﻿using DotNetModule.Contents.FileContentEntities;
using DotNetModule.Entities;
using MainAbstractions.Modules.Content;

namespace DotNetModule.Abstractions;

/// <summary>
/// Defines a builder interface for constructing a .csproj file.
/// </summary>
public interface IProjectBuilder
{
    /// <summary>
    /// Adds the specified dependencies to the project file.
    /// </summary>
    /// <param name="dependencies">A collection of dependencies to include in the project.</param>
    /// <returns>The current instance of <see cref="IProjectBuilder"/> for method chaining.</returns>
    IProjectBuilder WithDependencies(IEnumerable<Dependency> dependencies);

    /// <summary>
    /// Adds project references to the project file.
    /// </summary>
    /// <param name="projectRelations">A collection of project reference paths to include.</param>
    /// <returns>The current instance of <see cref="IProjectBuilder"/> for method chaining.</returns>
    IProjectBuilder WithProjectReferences(IEnumerable<string> projectRelations);

    /// <summary>
    /// Adds build actions to the project file.
    /// </summary>
    /// <param name="buildActions">A collection of file build actions.</param>
    /// <returns></returns>
    IProjectBuilder WithBuildActions(IEnumerable<BuildAction> buildActions);

    /// <summary>
    /// Builds the .csproj file and returns the generated content.
    /// </summary>
    /// <returns>A <see cref="RawContent"/> object containing the constructed .csproj file content.</returns>
    RawContent Build();
}
