﻿using MainAbstractions.Modules.Metadata;

namespace DotNetModule;

/// <summary>
/// Represents the components relevant for .NET app creation.
/// </summary>
public class DotNetModuleProperties : IModuleProperties
{
    /// <summary>
    /// Solution name.
    /// </summary>
    public string ProjectName { get; set; } = string.Empty;
}
