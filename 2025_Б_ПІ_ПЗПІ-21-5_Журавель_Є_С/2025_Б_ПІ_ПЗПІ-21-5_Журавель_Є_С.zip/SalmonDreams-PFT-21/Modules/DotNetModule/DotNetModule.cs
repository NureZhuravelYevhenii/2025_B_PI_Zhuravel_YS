﻿using DotNetModule.Services;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;

namespace DotNetModule;

/// <summary>
/// Provides functionality for generating .csproj, .sln and ordinary file contents for creating .NET application.
/// </summary>
public class DotNetModule : BaseModule<DotNetModuleProperties>
{
    public override async Task<IEnumerable<RawContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return await new DotNetModuleService(this).GetRawContents(token);
    }
}
