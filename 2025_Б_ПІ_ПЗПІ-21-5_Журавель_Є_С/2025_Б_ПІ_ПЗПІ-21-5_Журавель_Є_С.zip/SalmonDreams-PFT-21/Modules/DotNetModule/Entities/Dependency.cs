﻿namespace DotNetModule.Entities;

/// <summary>
/// Represents the definition of Package Reference in .csproj file.
/// </summary>
public class Dependency
{
    /// <summary>
    /// Package name.
    /// </summary>
    public string Include { get; set; } = string.Empty;

    /// <summary>
    /// Package version.
    /// </summary>
    public string Version { get; set; } = string.Empty;
    public IDictionary<string, string> Properties { get; set; } = new Dictionary<string, string>();

    public override int GetHashCode()
    {
        int hash = Include.GetHashCode();
        hash ^= Version.GetHashCode();

        foreach (var prop in Properties)
            hash ^= (prop.Key.GetHashCode() ^ prop.Value.GetHashCode());

        return hash;
    }

    public override bool Equals(object? obj)
    {
        if (obj is not Dependency other)
            return false;

        if (Include != other.Include || Version != other.Version)
            return false;

        if (Properties.Count != other.Properties.Count)
            return false;

        foreach (var kvp in Properties)
        {
            if (!other.Properties.TryGetValue(kvp.Key, out var otherValue) || kvp.Value != otherValue)
                return false;
        }

        return true;
    }
}
