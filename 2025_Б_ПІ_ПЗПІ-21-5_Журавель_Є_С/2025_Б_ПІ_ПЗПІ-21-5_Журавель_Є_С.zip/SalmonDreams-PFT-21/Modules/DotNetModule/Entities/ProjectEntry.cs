﻿namespace DotNetModule.Entities;

/// <summary>
/// Represents the definition of project file.
/// </summary>
public class ProjectEntry
{
    private const string WebSuffix = "Web";

    /// <summary>
    /// Whether it as Web project or not.
    /// </summary>
    public bool IsWeb { get; private set; }

    private string _name = string.Empty;

    /// <summary>
    /// Project name.
    /// </summary>
    public string Name 
    {
        get => _name;
        set 
        {
            _name = value;
            IsWeb = _name.EndsWith(WebSuffix);
        }
    }

    /// <summary>
    /// Project Guid.
    /// </summary>
    public Guid Guid { get; set; }
}
