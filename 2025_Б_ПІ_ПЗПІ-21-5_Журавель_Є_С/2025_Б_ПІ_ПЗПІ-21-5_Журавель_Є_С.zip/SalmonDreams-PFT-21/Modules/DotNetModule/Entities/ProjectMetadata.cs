﻿using DotNetModule.Contents.FileContentEntities;

namespace DotNetModule.Entities;

/// <summary>
/// Represents project's metadata.
/// </summary>
public class ProjectMetadata
{
    /// <summary>
    /// Project package references.
    /// </summary>
    public IEnumerable<Dependency> Dependencies { get; set; } = [];

    /// <summary>
    /// Collection of project on which primary project is dependent.
    /// </summary>
    public ICollection<string> ProjectReferences { get; set; } = [];

    /// <summary>
    /// Collection of project build actions.
    /// </summary>
    public ICollection<BuildAction> BuildActions { get; set; } = [];
}
