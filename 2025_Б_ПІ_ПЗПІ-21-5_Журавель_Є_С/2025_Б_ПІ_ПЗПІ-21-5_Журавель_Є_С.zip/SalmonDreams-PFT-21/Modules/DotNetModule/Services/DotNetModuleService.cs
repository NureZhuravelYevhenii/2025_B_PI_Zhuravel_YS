﻿using DotNetModule.Abstractions;
using DotNetModule.Builders;
using DotNetModule.Contents;
using DotNetModule.Contents.FileContentEntities;
using DotNetModule.Entities;
using GeneralHelpers;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using SharpCodeGenerator;
using System.Reflection;
using System.Text;

namespace DotNetModule.Services;

public class DotNetModuleService : IDotNetModuleService
{
    private readonly DotNetModule _dotNetModule;
    private readonly DotNetModuleProperties _properties;
    private static Assembly Assembly => typeof(DotNetModule).Assembly;

    private Dictionary<ProjectEntry, ProjectMetadata> _projectMetadatas = new();
    private readonly Lazy<StringCodeGenerator> _stringGenerator = new Lazy<StringCodeGenerator>();

    public DotNetModuleService(DotNetModule dotNetModule)
    {
        _dotNetModule = dotNetModule;
        _properties = _dotNetModule.Properties as DotNetModuleProperties
            ?? throw new ArgumentNullException("Unable to get module properties.");
    }

    public async Task<IEnumerable<RawContent>> GetRawContents(CancellationToken token = default)
    {
        var rawContents = new List<RawContent>();
        var contents = await GetModuleContentsAsync(token);

        foreach (var content in contents)
            await ProcessContent(content, rawContents);

        AddProjectContents(rawContents);
        AddSolutionFile(rawContents);

        return rawContents;
    }

    private async Task<IEnumerable<IContent>> GetModuleContentsAsync(CancellationToken token)
    {
        return await ModuleHelper.ExecuteSubModulesAsync(_dotNetModule.Modules, token);
    }

    private async Task ProcessContent(IContent content, List<RawContent> rawContents)
    {
        switch (content)
        {
            case FileContent fileContent:
                rawContents.Add(await GetFileRawContent(fileContent));
                break;
            case ProjectRelationContent projectRelationContent:
                AddProjectReferences(projectRelationContent);
                break;
        }
    }

    private void AddProjectReferences(ProjectRelationContent projectRelationContent)
    {
        AddProjectReferences(projectRelationContent.ProjectName, projectRelationContent.ProjectDependencies);
        foreach (var dependency in projectRelationContent.ProjectDependencies)
            AddProjectReferences(dependency, []);
    }

    private void AddProjectContents(List<RawContent> rawContents)
    {
        var projectContents = GetProjectFileRawContents();
        rawContents.AddRange(projectContents);
    }

    private void AddSolutionFile(List<RawContent> rawContents)
    {
        var slnFile = new SolutionBuilder(_dotNetModule).WithProjects(_projectMetadatas.Keys).Build();
        rawContents.Add(slnFile);
    }

    private void AddProjectDependencies(string projectName, IEnumerable<Dependency> projectDependencies)
    {
        var key = GetOrCreateProjectEntry(projectName);
        if (_projectMetadatas[key].Dependencies is not List<Dependency> dependencies)
        {
            dependencies = new List<Dependency>(_projectMetadatas[key].Dependencies);
            _projectMetadatas[key].Dependencies = dependencies;
        }

        dependencies.AddRange(projectDependencies);
    }

    private void AddBuildAction(string projectName, BuildAction buildAction)
    {
        if (buildAction is null)
            return;

        var key = GetOrCreateProjectEntry(projectName);
        if (_projectMetadatas[key].BuildActions is not List<BuildAction> buildActions)
        {
            buildActions = new List<BuildAction>(_projectMetadatas[key].BuildActions);
            _projectMetadatas[key].BuildActions = buildActions;
        }

        buildActions.Add(buildAction);
    }

    private void AddProjectReferences(string projectName, IEnumerable<string> projectReferences)
    {
        var key = GetOrCreateProjectEntry(projectName);
        foreach (var projectReference in projectReferences)
            _projectMetadatas[key].ProjectReferences.Add(projectReference);
    }

    private ProjectEntry GetOrCreateProjectEntry(string projectName)
    {
        var key = _projectMetadatas.Keys.FirstOrDefault(x => x.Name == projectName);
        if (key is not null)
            return key;

        key = new ProjectEntry
        {
            Name = projectName,
            Guid = Guid.NewGuid()
        };

        _projectMetadatas.Add(key, new ProjectMetadata());

        return key;
    }

    private async Task AddJwtConfigFile(List<RawContent> rawContents)
    {
        var jwtConfig = new RawContent
        {
            Name = $"Common/Configs",
            Content = Encoding.UTF8.GetBytes(await Assembly.GetResource("jwtConfig.json"))
        };

        rawContents.Add(jwtConfig);
    }

    private async Task<RawContent> GetFileRawContent(FileContent fileContent)
    {
        var projectName = fileContent.Location.Split("/")[0];
        AddProjectDependencies(projectName, fileContent.Dependencies);
        AddBuildAction(projectName, fileContent.BuildAction);

        return new RawContent
        {
            Name = fileContent.Location,
            Content = Encoding.UTF8.GetBytes(fileContent.Content ?? await _stringGenerator.Value.GenerateFileAsync(fileContent.StronglyTypedContent!))
        };
    }

    private IEnumerable<RawContent> GetProjectFileRawContents()
    {
        var rawContents = new List<RawContent>();
        foreach (var projectMetadata in _projectMetadatas)
        {
            var csProj = new ProjectBuilder(projectMetadata.Key)
                .WithDependencies(projectMetadata.Value.Dependencies.Distinct())
                .WithProjectReferences(projectMetadata.Value.ProjectReferences.Distinct())
                .WithBuildActions(projectMetadata.Value.BuildActions)
                .Build();

            rawContents.Add(csProj);
        }

        return rawContents;
    }
}
