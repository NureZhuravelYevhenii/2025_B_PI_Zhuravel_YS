﻿namespace DotNetModule.Contents.FileContentEntities;

/// <summary>
/// Represents an action to be performed in a solution context.
/// The build action controls what happens to the file when the project is compiled.
/// </summary>
public class BuildAction
{
    /// <summary>
    /// Name of the file associated with the build action.
    /// </summary>
    public string FileName { get; set; } = string.Empty;

    /// <summary>
    /// Name for the action.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Type of action to perform, such as "Compile", "None".
    /// </summary>
    public string Action { get; set; } = "Update";

    /// <summary>
    /// Additional parameters for the build action.
    /// </summary>
    public IDictionary<string, string> AdditionalParameters { get; set; } = new Dictionary<string, string>();
}
