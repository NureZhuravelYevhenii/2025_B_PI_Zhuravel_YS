﻿using MainAbstractions.Modules.Content;

namespace DotNetModule.Contents;

/// <summary>
/// Represents the definition of Project Reference section in .sln.
/// </summary>
public class ProjectRelationContent : IContent
{
    /// <summary>
    /// Primary project name.
    /// </summary>
    public string ProjectName { get; set; } = string.Empty;

    /// <summary>
    /// Project on which primary project is dependent.
    /// </summary>
    public IEnumerable<string> ProjectDependencies { get; set; } = [];
}
