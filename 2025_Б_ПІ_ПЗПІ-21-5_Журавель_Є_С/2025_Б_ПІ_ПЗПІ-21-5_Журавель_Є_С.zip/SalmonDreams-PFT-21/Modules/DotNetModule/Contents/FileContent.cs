﻿using DotNetModule.Contents.FileContentEntities;
using DotNetModule.Entities;
using MainAbstractions.Modules.Content;

namespace DotNetModule.Contents;

/// <summary>
/// Represents the definition of any ordinary file in .NET application, such as .cs, json etc.
/// </summary>
public class FileContent : IContent
{
    /// <summary>
    /// File Location.
    /// </summary>
    public string Location { get; set; } = string.Empty;

    /// <summary>
    /// File content.
    /// </summary>
    public string? Content { get; set; }

    /// <summary>
    /// Dynamic file content.
    /// </summary>
    public SharpCodeGenerator.Entities.File? StronglyTypedContent { get; set; }

    /// <summary>
    /// Package dependencies.
    /// </summary>
    public IEnumerable<Dependency> Dependencies { get; set; } = [];

    /// <summary>
    /// File's build actions.
    /// </summary>
    public BuildAction BuildAction { get; set; } = null!;
}
