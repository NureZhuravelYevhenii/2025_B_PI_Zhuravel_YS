﻿using DotNetModule.Abstractions;
using DotNetModule.Entities;
using GeneralHelpers;
using MainAbstractions.Modules.Content;
using System.Text;

namespace DotNetModule.Builders;

public class SolutionBuilder : ISolutionBuilder
{
    private readonly StringBuilder _content;
    private IEnumerable<ProjectEntry> _projectEntries;
    private readonly DotNetModule _module;
    private readonly DotNetModuleProperties _properties;

    private const int TAB_SIZE = 4;

    public SolutionBuilder(DotNetModule module)
    {
        _module = module;
        _properties = module.Properties as DotNetModuleProperties
            ?? throw new ArgumentException("Unable to retrieve module properties.");
        
        _content = new StringBuilder();
        _projectEntries = [];
    }

    public ISolutionBuilder WithProjects(IEnumerable<ProjectEntry> projectEnties)
    {
        _projectEntries = projectEnties;
        return this;
    }

    public RawContent Build()
    {
        BuildSolutionHeader();
        AddProjectSection();
        AddGlobalSectionContainer();

        return CreateRawContent();
    }

    private void BuildSolutionHeader()
    {
        AppendToContent(new[]
        {
            "\"Microsoft Visual Studio Solution File, Format Version 12.00\"",
            "# Visual Studio Version 17",
            "VisualStudioVersion = 17.8.34408.163",
            "MinimumVisualStudioVersion = 10.0.40219.1"
        });
    }

    private void AddGlobalSectionContainer()
    {
        AppendToContent("Global");
        AddSolutionConfigurationPlatformsSection();
        AddProjectConfigurationPlatformsSection();
        AddSolutionProperties();
        AddExtensibilityGlobals();
        AppendToContent("EndGlobal");
    }

    private void AddSolutionConfigurationPlatformsSection()
    {
        AppendToContent(new[]
        {
            "GlobalSection(SolutionConfigurationPlatforms) = preSolution",
            "    Debug|Any CPU = Debug|Any CPU",
            "    Release|Any CPU = Release|Any CPU",
            "EndGlobalSection"
        }, TAB_SIZE);
    }

    private void AddProjectSection()
    {
        foreach (var projectEntry in _projectEntries)
        {
            AppendToContent(new[]
            {
                $"Project(\"{Guid.NewGuid()}\\\") = \"{projectEntry.Name}\", \"{projectEntry.Name}\\{projectEntry.Name}.csproj\", \"{{{projectEntry.Guid}}}\"",
                "EndProject"
            });
        }
    }

    private void AddProjectConfigurationPlatformsSection()
    {
        AppendToContent("GlobalSection(ProjectConfigurationPlatforms) = postSolution", TAB_SIZE);
        foreach (var projectEntry in _projectEntries)
            AddProjectConfigurationSection(projectEntry.Guid);
        AppendToContent("EndGlobalSection", TAB_SIZE);
    }

    private void AddProjectConfigurationSection(Guid projectGuid)
    {
        AppendToContent(new[]
        {
            $"{{{projectGuid}}}.Debug|Any CPU.ActiveCfg = Debug|Any CPU",
            $"{{{projectGuid}}}.Debug|Any CPU.Build.0 = Debug|Any CPU",
            $"{{{projectGuid}}}.Release|Any CPU.ActiveCfg = Release|Any CPU",
            $"{{{projectGuid}}}.Release|Any CPU.Build.0 = Release|Any CPU"
        }, TAB_SIZE * 2);
    }

    private void AddSolutionProperties()
    {
        AppendToContent(new[]
        {
            $"GlobalSection(SolutionProperties) = preSolution",
            $"    HideSolutionNode = FALSE",
            $"EndGlobalSection",
        }, TAB_SIZE);
    }

    private void AddExtensibilityGlobals()
    {
        AppendToContent(new[]
        {
            $"GlobalSection(ExtensibilityGlobals) = postSolution",
            $"    SolutionGuid = {{{Guid.NewGuid()}}}",
            $"EndGlobalSection",
        }, TAB_SIZE);
    }

    private void AppendToContent(string line, int indent = 0)
    {
        _content.AppendLine(line.ShiftEachLineWithIndentation(indent));
    }

    private void AppendToContent(IEnumerable<string> lines, int indent = 0)
    {
        foreach (var line in lines)
            AppendToContent(line, indent);
    }

    private RawContent CreateRawContent()
    {
        return new RawContent
        {
            Name = $"{_properties.ProjectName}.sln",
            Content = Encoding.UTF8.GetBytes(_content.ToString())
        };
    }
}
