﻿using DotNetModule.Abstractions;
using DotNetModule.Contents.FileContentEntities;
using DotNetModule.Entities;
using GeneralHelpers;
using MainAbstractions.Modules.Content;
using System.Text;

namespace DotNetModule.Builders;

public class ProjectBuilder : IProjectBuilder
{
    private readonly ProjectEntry _projectEntry;

    private readonly StringBuilder _content;
    private int _indentLevel;

    private IEnumerable<Dependency> _dependencies = [];
    private IEnumerable<string> _projectReferences = [];
    private IEnumerable<BuildAction> _buildActions = [];

    public ProjectBuilder(ProjectEntry projectEntry)
    {
        _projectEntry = projectEntry;

        _dependencies = [];
        _projectReferences = [];

        _content = new StringBuilder();
        _indentLevel = 0;
    }

    public IProjectBuilder WithDependencies(IEnumerable<Dependency> dependencies)
    {
        _dependencies = dependencies;
        return this;
    }

    public IProjectBuilder WithProjectReferences(IEnumerable<string> projectRelations)
    {
        _projectReferences = projectRelations;
        return this;
    }

    public IProjectBuilder WithBuildActions(IEnumerable<BuildAction> buildActions)
    {
        _buildActions = buildActions;
        return this;
    }

    public RawContent Build()
    {
        AddSdkSection();
        AppendPropertyGroup(new[] { "<TargetFramework>net8.0</TargetFramework>" });
        AddDependencies();
        AddBuildActions();
        AddProjectReferences();
        AppendLine("</Project>");

        return CreateRawContent();
    }

    private void AddSdkSection()
    {
        string sdk = GetSdkForProject();
        AppendLine($"<Project Sdk=\"{sdk}\">");
    }

    private string GetSdkForProject()
    {
        return _projectEntry.IsWeb
            ? "Microsoft.NET.Sdk.Web"
            : "Microsoft.NET.Sdk";
    }

    private void AddDependencies()
    {
        if (!_dependencies.Any())
            return;

        AppendItemGroup(_dependencies.Select(d => $"<PackageReference Include=\"{d.Include}\" Version=\"{d.Version}\" />"));
    }

    private void AddBuildActions()
    {
        if (!_buildActions.Any())
            return;

        AppendItemGroup(
            _buildActions.Select(ba => $"<Content Remove=\"{ba.FileName}\"/>")
        );

        var groupedBuildActions = _buildActions.GroupBy(ba => ba.Name);

        foreach (var group in groupedBuildActions)
        {
            AppendItemGroup(
                group.Select(ba => $"<{ba.Name} Include=\"{ba.FileName}\"/>")
            );

            AppendItemGroup(
                group.SelectMany(ba => CreateBuildActionElements(ba))
            );
        }
    }

    private IEnumerable<string> CreateBuildActionElements(BuildAction buildAction)
    {
        var elements = new List<string>();
        if (!buildAction.AdditionalParameters.Any())
        {
            elements.Add($"<{buildAction.Name} {buildAction.Action}=\"{buildAction.FileName}\"/>");
            return elements;
        }

        elements.Add($"<{buildAction.Name} {buildAction.Action}=\"{buildAction.FileName}\">");
        foreach (var parameter in buildAction.AdditionalParameters)
            elements.Add($"  <{parameter.Key}>{parameter.Value}</{parameter.Key}>");

        elements.Add($"</{buildAction.Name}>");

        return elements;
    }

    private void AddProjectReferences()
    {
        if (!_projectReferences.Any())
            return;

        AppendItemGroup(_projectReferences.Select(pr => $"<ProjectReference Include=\"..\\{pr}\\{pr}.csproj\" />"));
    }

    private RawContent CreateRawContent()
    {
        var projectName = _projectEntry.Name;

        return new RawContent
        {
            Name = $"{projectName}/{projectName}.csproj",
            Content = Encoding.UTF8.GetBytes(_content.ToString())
        };
    }

    private void AppendItemGroup(IEnumerable<string> items)
    {
        AppendLine("<ItemGroup>");
        IncreaseIndent();

        foreach (var item in items)
            AppendLine(item);

        DecreaseIndent();
        AppendLine("</ItemGroup>");
    }

    private void AppendPropertyGroup(IEnumerable<string> properties)
    {
        AppendLine("<PropertyGroup>");
        IncreaseIndent();

        foreach (var property in properties)
            AppendLine(property);

        DecreaseIndent();
        AppendLine("</PropertyGroup>");
    }

    private void AppendLine(string line)
    {
        _content.AppendLine(line.ShiftEachLineWithIndentation(_indentLevel * 2));
    }

    private void IncreaseIndent()
    {
        _indentLevel++;
    }

    private void DecreaseIndent()
    {
        _indentLevel--;
    }
}
