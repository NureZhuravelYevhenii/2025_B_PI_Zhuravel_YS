﻿using DAL.Entities.BaseEntities;

namespace DAL.Abstractions;

/// <summary>
/// Interface for managing transactions and repositories.
/// </summary>
public interface IUnitOfWork
{
    /// <summary>
    /// Asynchronously commits all changes made in the current unit of work.
    /// </summary>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task CommitAsync(CancellationToken token = default);

    /// <summary>
    /// Asynchronously retrieves a repository for a specific entity type.
    /// </summary>
    /// <typeparam name="T">The type of entity for which to retrieve the repository.</typeparam>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the repository for the specified entity type.</returns>
    Task<IRepository<T>> GetRepositoryAsync<T>(CancellationToken token = default) where T : BaseEntity;

    /// <summary>
    /// Asynchronously retrieves a specific repository by type.
    /// </summary>
    /// <typeparam name="T">The type of the specific repository to retrieve.</typeparam>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the specific repository.</returns>
    Task<T> GetSpecificRepository<T>(CancellationToken token = default);
}

