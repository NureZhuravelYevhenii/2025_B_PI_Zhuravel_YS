﻿namespace BLL.Entities.Modules;

public class ModuleDefinition
{
    public string Name { get; set; } = string.Empty;
    public IEnumerable<string> AccaptableContents { get; set; } = new List<string>();
    public IEnumerable<string> ProducedContents { get; set; } = new List<string>();
    public IEnumerable<PropertyDefinition> Properties { get; set; } = new List<PropertyDefinition>();
}
