﻿namespace BLL.Entities;

public class SimplifiedModule
{
    public string Name { get; set; } = string.Empty;
    public IDictionary<string, object> Properties { get; set; } = new Dictionary<string, object>();
    public IEnumerable<SimplifiedModule> Modules { get; set; } = new List<SimplifiedModule>();
}
