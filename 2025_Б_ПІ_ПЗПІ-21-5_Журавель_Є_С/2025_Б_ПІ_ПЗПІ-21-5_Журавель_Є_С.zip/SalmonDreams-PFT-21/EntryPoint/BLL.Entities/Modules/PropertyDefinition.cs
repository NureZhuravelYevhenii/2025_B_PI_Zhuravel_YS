﻿namespace BLL.Entities.Modules;

public class PropertyDefinition
{
    public string Name { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public IEnumerable<PropertyDefinition> Properties { get; set; } = new List<PropertyDefinition>();
    public IEnumerable<string> EnumValues { get; set; } = new List<string>();
}
