﻿namespace BLL.Entities.Users;

public class UserCreationDto
{
    public string Login { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string ApprovePassword { get; set; } = string.Empty;
    public bool IsAdmin { get; set; } = false;
}
