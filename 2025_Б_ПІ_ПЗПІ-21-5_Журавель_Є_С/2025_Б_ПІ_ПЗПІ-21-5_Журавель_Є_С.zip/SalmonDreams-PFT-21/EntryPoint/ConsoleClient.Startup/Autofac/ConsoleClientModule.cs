﻿using Autofac;
using BLL.Startup.Autofac;
using Domain.Startup.Autofac;

namespace ConsoleClient.Startup.Autofac;

public class ConsoleClientModule : Module
{
    protected override void Load(ContainerBuilder builder) 
    {
        builder.RegisterModule<BLLModule>();
        builder.RegisterModule<DomainModule>();
    }
}
