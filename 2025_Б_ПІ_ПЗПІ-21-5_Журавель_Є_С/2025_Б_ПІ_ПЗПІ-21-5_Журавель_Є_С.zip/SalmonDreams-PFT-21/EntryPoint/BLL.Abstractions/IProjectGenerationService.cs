﻿using BLL.Entities;
using MainAbstractions.Modules.Content;

namespace BLL.Abstractions;
public interface IProjectGenerationService
{
    Task<IEnumerable<RawContent>> GenerateProjectAsync(IEnumerable<SimplifiedModule> simplifiedModules, CancellationToken token = default);
}
