﻿using BLL.Entities.Modules;
using DAL.Entities;
using Domain.Enums;
using MainAbstractions.Modules;

namespace BLL.Abstractions;

/// <summary>
/// Interface for managing modules and sub-modules.
/// </summary>
public interface IModuleService
{
    Task<IEnumerable<ModuleDefinition>> GetModuleDefinitionsAsync(ModuleTypes moduleType, CancellationToken token = default);

    /// <summary>
    /// Retrieves a module by its name and initializes its properties.
    /// </summary>
    /// <param name="name">The name of the module.</param>
    /// <param name="properties">A dictionary of properties to initialize the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the module instance.</returns>
    Task<TModuleAbstraction> GetModuleInstanceAsync<TModuleAbstraction>(string name, IDictionary<string, object> properties, CancellationToken token = default)
        where TModuleAbstraction : class, IModuleBase;

    /// <summary>
    /// Creates a new module with the specified name and assembly.
    /// </summary>
    /// <param name="assembly">The assembly data of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task<int> CreateModuleAsync(byte[] mainAssembly, IEnumerable<byte[]> additionalLibraries, ModuleTypes moduleType, CancellationToken token = default);

    /// <summary>
    /// Deletes a module by its name.
    /// </summary>
    /// <typeparam name="Module">The type of the module entity.</typeparam>
    /// <param name="name">The name of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task DeleteModuleAsync(string name, CancellationToken token = default);

    /// <summary>
    /// Deletes a module by its ID.
    /// </summary>
    /// <typeparam name="Module">The type of the module entity.</typeparam>
    /// <param name="id">The ID of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task DeleteModuleAsync(int id, CancellationToken token = default);

    /// <summary>
    /// Updates a module with the specified ID.
    /// </summary>
    /// <typeparam name="Module">The type of the module entity.</typeparam>
    /// <param name="moduleId">The Id of the module.</param>
    /// <param name="assembly">The new assembly data of the module. Optional.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task UpdateModuleAsync(int moduleId, byte[] assembly = null!, IEnumerable<byte[]> additionalLibraries = null!, CancellationToken token = default);

    /// <summary>
    /// Updates a module with the specified ID.
    /// </summary>
    /// <typeparam name="Module">The type of the module entity.</typeparam>
    /// <param name="moduleName">Name of the module.</param>
    /// <param name="assembly">The new assembly data of the module. Optional.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task UpdateModuleAsync(string moduleName, byte[] assembly = null!, IEnumerable<byte[]> additionalLibraries = null!, CancellationToken token = default);
}

