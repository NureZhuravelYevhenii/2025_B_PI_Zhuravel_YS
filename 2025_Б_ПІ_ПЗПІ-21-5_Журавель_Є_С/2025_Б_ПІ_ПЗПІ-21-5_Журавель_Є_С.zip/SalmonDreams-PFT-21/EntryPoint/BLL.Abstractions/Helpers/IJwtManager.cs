﻿using System.Security.Claims;

namespace BLL.Abstractions.Helpers;

public interface IJwtManager
{
    Task<IEnumerable<Claim>> DecodeTokenAsync(string jwtToken, CancellationToken token = default);
    Task<string> GetJwtTokenAsync(IEnumerable<Claim> claims, CancellationToken token = default);
}
