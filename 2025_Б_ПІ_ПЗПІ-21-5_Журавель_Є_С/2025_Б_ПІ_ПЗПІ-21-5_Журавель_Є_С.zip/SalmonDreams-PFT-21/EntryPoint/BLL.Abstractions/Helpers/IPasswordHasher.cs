﻿namespace BLL.Abstractions.Helpers;

public interface IHasher
{
    Task<(string Hash, string Salt)> HashAsync(string input, CancellationToken token = default);
    Task<bool> CompareStringWithHashAsync(string input, string salt, string hash, CancellationToken token = default);
}
