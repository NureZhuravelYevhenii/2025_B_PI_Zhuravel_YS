﻿using BLL.Entities;

namespace BLL.Abstractions;

public interface IParseService
{
    string MarkupType { get; }
    Task<IEnumerable<SimplifiedModule>> ParseToSimplifiedAsync(string input, CancellationToken token = default);
}
