﻿using BLL.Entities.Users;
using DAL.Entities;
using System.Linq.Expressions;

namespace BLL.Abstractions;

public interface IUserService
{
    Task<TokenPair> LoginAsync(UserLogin userLogin, CancellationToken token = default);
    Task<TokenPair> RegisterAsync(UserCreationDto user, CancellationToken token = default);
    Task<TokenPair> RefreshTokenAsync(string refreshToken, CancellationToken token = default);
    Task<UserDto?> GetUserAsync(Expression<Func<User, bool>> predicate, CancellationToken token = default);
    Task<UserDto?> GetUserAsync(int id, CancellationToken token = default);
    Task DeleteAsync(int id, CancellationToken token = default);
    Task UpdateAsync(UserUpdateDto updatedUser, CancellationToken token = default);
}
