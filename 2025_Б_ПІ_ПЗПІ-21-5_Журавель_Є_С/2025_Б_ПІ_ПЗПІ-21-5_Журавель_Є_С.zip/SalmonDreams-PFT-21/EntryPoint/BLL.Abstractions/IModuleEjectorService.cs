﻿using MainAbstractions.Modules;
using MainAbstractions.Modules.Metadata;
using System.Reflection;

namespace BLL.Abstractions;

public interface IModuleEjectorService
{
    TModule GetModule<TModule>(Assembly assembly) where TModule : class, IModuleBase;
    Task<ModuleMetadata> GetModuleMetadata(Assembly assembly, CancellationToken token = default);
    IModuleProperties GetModuleProperties(Assembly assembly, IDictionary<string, object> rawProperties = null!);
    Type GetModulePropertiesType(Assembly assembly);
}
