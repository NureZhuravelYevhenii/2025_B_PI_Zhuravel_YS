﻿using System.Runtime.Loader;

namespace BLL.Abstractions;

public interface IAssemblyLoadContextWrapper
{
    AssemblyLoadContext AssemblyLoadContext { get; }
}