﻿namespace BLL.Abstractions.Converters;

public interface IConvertersService
{
    IDictionary<Type, Func<object, object?>> Converters { get; }
}
