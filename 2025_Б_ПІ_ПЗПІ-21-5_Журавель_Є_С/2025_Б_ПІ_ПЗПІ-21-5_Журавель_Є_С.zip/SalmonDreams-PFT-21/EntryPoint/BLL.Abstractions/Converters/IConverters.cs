﻿namespace BLL.Abstractions.Converters;

/// <summary>
/// Converters for types, that have no explicit operators for default types (for example type has explicit Value property or something like getter).
/// Do not use it in user code that is not for registering new specific cnverters!!! Use it for segregation parser library specific types.
/// </summary>
public interface IConverters
{
    IDictionary<Type, Func<object, object?>> Converters { get; }
}
