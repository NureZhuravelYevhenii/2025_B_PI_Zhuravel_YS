﻿namespace WebClient.ModuleServices.Local;

public static class Modules
{
    public static readonly IReadOnlyDictionary<string, string> ModuleEntities = new Dictionary<string, string>
    {
        { "DotNetModule", @"Modules/DotNetModule/bin/Debug/net8.0" },
    };
}
