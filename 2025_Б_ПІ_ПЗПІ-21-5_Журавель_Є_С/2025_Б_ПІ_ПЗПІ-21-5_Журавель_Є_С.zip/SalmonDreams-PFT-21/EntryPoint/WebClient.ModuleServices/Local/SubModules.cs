﻿namespace WebClient.ModuleServices.Local;

public static class SubModules
{
    public static readonly IReadOnlyDictionary<string, string> SubModuleEntities = new Dictionary<string, string>
    {
        { "AspNet", "SubModules/AspNet/bin/Debug/net8.0" },
        { "EfCoreDataAccess", "SubModules/EfCoreDataAccess/bin/Debug/net8.0" },
        { "Entity", "SubModules/Entity/bin/Debug/net8.0" },
        { "IdentityEntity", "SubModules/IdentityEntity/bin/Debug/net8.0" },
        { "IdentityServices", "SubModules/IdentityServices/bin/Debug/net8.0" },
        { "JwtControllers", "SubModules/JwtControllers/bin/Debug/net8.0" },
        { "JwtIdentityEntity", "SubModules/JwtIdentityEntity/bin/Debug/net8.0" },
        { "JwtIdentityServices", "SubModules/JwtIdentityServices/bin/Debug/net8.0" },
        { "EntityModel", "SubModules/EntityModel/bin/Debug/net8.0" },
        { "Property", "SubModules/Property/bin/Debug/net8.0" },
        { "Relation", "SubModules/Relation/bin/Debug/net8.0" },
        { "Services", "SubModules/Services/bin/Debug/net8.0" },
        { "CrudControllers", "SubModules/CrudControllers/bin/Debug/net8.0" },
        { "TestSubModule", "SubModules/TestSubModule/bin/Debug/net8.0" },
        { "AutomapperRegistration", "SubModules/AutomapperRegistration/bin/Debug/net8.0" }
    };
}
