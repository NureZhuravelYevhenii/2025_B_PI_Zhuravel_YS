﻿namespace WebClient.ModuleServices;

public static class SubModules
{
    public static readonly IReadOnlyDictionary<string, string> SubModuleEntities = new Dictionary<string, string>
    {
        { "AspNet", "SubModules/AspNet" },
        { "EfCoreDataAccess", "SubModules/EfCoreDataAccess" },
        { "Entity", "SubModules/Entity" },
        { "IdentityEntity", "SubModules/IdentityEntity" },
        { "IdentityServices", "SubModules/IdentityServices" },
        { "JwtControllers", "SubModules/JwtControllers" },
        { "JwtIdentityEntity", "SubModules/JwtIdentityEntity" },
        { "JwtIdentityServices", "SubModules/JwtIdentityServices" },
        { "EntityModel", "SubModules/EntityModel" },
        { "Property", "SubModules/Property" },
        { "Relation", "SubModules/Relation" },
        { "Services", "SubModules/Services" },
        { "CrudControllers", "SubModules/CrudControllers" },
        { "TestSubModule", "SubModules/TestSubModule" },
        { "AutomapperRegistration", "SubModules/AutomapperRegistration" }
    };
}
