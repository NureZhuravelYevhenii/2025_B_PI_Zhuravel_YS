﻿using BLL.Abstractions;
using Domain.Configurations;
using Domain.Enums;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace WebClient.ModuleServices.Services;

public class RegisterModulesService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;

    public RegisterModulesService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = _serviceProvider.CreateScope();
        var moduleService = scope.ServiceProvider.GetRequiredService<IModuleService>();
        var debugConfiguration = scope.ServiceProvider.GetRequiredService<IOptions<DebugConfiguration>>().Value
            ?? throw new ArgumentNullException("Unable to retrieve Debug only configuration.");

#if DEBUG
        PopulateModules(moduleService, debugConfiguration, Local.SubModules.SubModuleEntities, ModuleTypes.SubModule).Wait();
        PopulateModules(moduleService, debugConfiguration, Local.Modules.ModuleEntities, ModuleTypes.Module).Wait();
#else
        PopulateModules(moduleService, debugConfiguration, SubModules.SubModuleEntities, ModuleTypes.SubModule).Wait();
        PopulateModules(moduleService, debugConfiguration, Modules.ModuleEntities, ModuleTypes.Module).Wait();
#endif
        return Task.CompletedTask;
    }

    private static async Task PopulateModules(IModuleService moduleService, DebugConfiguration debugConfiguration, IReadOnlyDictionary<string, string> modules, ModuleTypes moduleType)
    {
        foreach (var subModuleNamePath in modules)
        {
            var files = Directory.GetFiles(Path.Combine(debugConfiguration.RepositoryDirectory, subModuleNamePath.Value))
                .Where(file => file.Contains(".dll"));
            var libraries = new List<byte[]>();
            byte[] mainLibrary = null!;
            foreach (var library in files)
            {
                var libraryBytes = File.ReadAllBytes(library);
                if (libraryBytes.Length != 0)
                {
                    var nameOfLibrary = Path.GetFileName(library).Split('.').ToList();

                    if (string.Join('.', nameOfLibrary.Take(nameOfLibrary.Count - 1)) == subModuleNamePath.Key)
                    {
                        mainLibrary = libraryBytes;
                        continue;
                    }
                    libraries.Add(libraryBytes);
                }
            }

            if (mainLibrary is null)
            {
                throw new InvalidOperationException($"Unable to find main library for {subModuleNamePath.Key}.");
            }

            await moduleService.CreateModuleAsync(mainLibrary, libraries, moduleType);
        }
    }
}
