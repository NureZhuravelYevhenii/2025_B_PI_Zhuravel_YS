﻿using Adapters.Startup.Autofac;
using Autofac;
using BLL.Startup.Autofac;
using Domain.Startup.Autofac;

namespace WebClient.Startup.Autofac;

public class WebClientModule : Module
{
    protected override void Load(ContainerBuilder builder) 
    {
        builder.RegisterModule<AdaptersModule>();
        builder.RegisterModule<BLLModule>();
        builder.RegisterModule<DomainModule>();
    }
}
