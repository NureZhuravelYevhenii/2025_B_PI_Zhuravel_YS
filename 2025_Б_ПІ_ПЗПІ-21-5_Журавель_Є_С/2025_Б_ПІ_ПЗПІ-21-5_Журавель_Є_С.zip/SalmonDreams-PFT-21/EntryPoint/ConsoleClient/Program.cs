﻿using Autofac;
using ConsoleClient;
using ConsoleClient.Startup.Autofac;
using Microsoft.Extensions.Configuration;

var containerBuilder = new ContainerBuilder();

var configurations = new ConfigurationBuilder()
    .AddJsonFile("appsettings.json", false)
    .Build();

containerBuilder.RegisterInstance((IConfiguration)configurations)
    .As<IConfiguration>();

containerBuilder.RegisterModule<ConsoleClientModule>();

await Runner.StartAsync(containerBuilder.Build());