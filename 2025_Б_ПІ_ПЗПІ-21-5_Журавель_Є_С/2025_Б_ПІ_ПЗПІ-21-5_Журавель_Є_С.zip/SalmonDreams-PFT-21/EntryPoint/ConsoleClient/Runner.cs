﻿using Autofac;

namespace ConsoleClient;

public static class Runner
{
    public static async Task StartAsync(IContainer container)
    {
    }
}
