﻿namespace Domain.Enums;

public enum ContentTypes
{
    AcceptableContent,
    ProducedContent,
}
