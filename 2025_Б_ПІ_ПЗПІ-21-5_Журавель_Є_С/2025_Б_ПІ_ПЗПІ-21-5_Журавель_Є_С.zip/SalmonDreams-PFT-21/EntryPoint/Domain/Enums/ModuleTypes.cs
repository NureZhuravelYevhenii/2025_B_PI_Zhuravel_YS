﻿namespace Domain.Enums;

public enum ModuleTypes
{
    Module,
    SubModule,
}
