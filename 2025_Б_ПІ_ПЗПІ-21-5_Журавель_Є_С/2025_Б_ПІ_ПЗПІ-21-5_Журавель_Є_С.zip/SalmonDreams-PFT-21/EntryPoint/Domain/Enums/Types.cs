﻿namespace Domain.Enums;

public enum Types
{
    String,
    Number,
    Boolean,
    Date,
    Enum,
    StringArray,
    NumberArray,
    BooleanArray,
    DateArray,
    EnumArray,
    Object,
}
