﻿namespace Domain.Configurations;

public class ElasticSearchConfiguration
{
    public string Host { get; set; } = string.Empty;
}
