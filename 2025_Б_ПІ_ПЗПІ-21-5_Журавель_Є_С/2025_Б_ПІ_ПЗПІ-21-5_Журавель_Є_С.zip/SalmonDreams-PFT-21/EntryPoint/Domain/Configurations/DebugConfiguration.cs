﻿namespace Domain.Configurations;

public class DebugConfiguration
{
    public string RepositoryDirectory { get; set; } = string.Empty;
}
