﻿namespace Domain.Constants;

public static class JwtHttpConstants
{
    public const string RefreshTokenCookieName = "refresh-token";
}