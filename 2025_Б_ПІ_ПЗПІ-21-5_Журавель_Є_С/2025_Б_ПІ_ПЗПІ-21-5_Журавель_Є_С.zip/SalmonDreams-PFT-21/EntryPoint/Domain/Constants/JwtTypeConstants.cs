﻿namespace Domain.Constants;

public static class JwtTypeConstants
{
    public const string Id = "id";
    public const string Nonce = "nonce";
}
