﻿using Adapters.Entities.Parameters;

namespace Adapters.Abstractions;

public interface IProjectGenerationFacade
{
    Task<(Stream?, string)> GenerateProjectArchiveAsync(ProjectGenerationFacadeParameters parameters, CancellationToken token = default);
}
