﻿using Autofac;
using BLL.Entities;
using BLL.Services;
using DAL.Startup.Autofac;
using Newtonsoft.Json;
using YamlDotNet.Serialization;

namespace BLL.Startup.Autofac;

public class BLLModule : Module
{
    protected override void Load(ContainerBuilder builder) 
    {
        var assembly = typeof(ModuleService).Assembly;

        builder.RegisterAssemblyTypes(assembly)
            .Where(t => t.Name.Contains("Service") 
            || t.Name.Contains("Builder") 
            || t.Name.Contains("Helper") 
            || t.Name.Contains("Manager") 
            || t.Name.Contains("Converters"))
            .AsSelf()
            .AsImplementedInterfaces();

        builder.RegisterInstance(new DeserializerBuilder()
            .WithCaseInsensitivePropertyMatching()
            .Build())
            .As<IDeserializer>();

        builder.RegisterType<Hasher>()
            .AsSelf()
            .AsImplementedInterfaces();

        builder.RegisterType<AssemblyLoadContextWrapper>()
            .AsSelf()
            .AsImplementedInterfaces()
            .InstancePerLifetimeScope();

        builder.RegisterModule<DALModule>();
    }
}