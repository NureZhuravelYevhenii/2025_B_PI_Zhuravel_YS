﻿using DAL.Entities.BaseEntities;
using DAL.Entities.ManyToManyEntities;

namespace DAL.Entities;

public class Content : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public IEnumerable<ModuleContent> ModuleContents { get; set; } = null!;
}
