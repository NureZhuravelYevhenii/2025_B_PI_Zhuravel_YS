﻿using DAL.Entities.BaseEntities;
using Domain.Enums;

namespace DAL.Entities;

public class Property : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public Types Type { get; set; }

    public int? ParentPropertyId { get; set; }
    public Property? ParentProperty { get; set; }

    public Enum? Enum { get; set; }

    public IEnumerable<Property> InternalProperties { get; set; } = null!;

    public int? PropertiesId { get; set; }
    public Properties? Properties { get; set; } = null!;
}
