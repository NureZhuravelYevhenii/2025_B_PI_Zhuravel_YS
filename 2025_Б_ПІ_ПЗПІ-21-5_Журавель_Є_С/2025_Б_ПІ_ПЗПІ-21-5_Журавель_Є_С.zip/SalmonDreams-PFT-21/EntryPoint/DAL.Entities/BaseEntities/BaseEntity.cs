﻿namespace DAL.Entities.BaseEntities;

/// <summary>
/// Base for database entities.
/// </summary>
public abstract class BaseEntity
{
    /// <summary>
    /// Id of the entity.
    /// </summary>
    public int Id { get; set; }
}
