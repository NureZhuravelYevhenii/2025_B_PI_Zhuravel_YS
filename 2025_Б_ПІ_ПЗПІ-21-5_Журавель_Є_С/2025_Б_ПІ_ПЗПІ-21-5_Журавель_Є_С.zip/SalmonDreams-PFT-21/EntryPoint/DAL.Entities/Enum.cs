﻿using DAL.Entities.BaseEntities;

namespace DAL.Entities;

public class Enum : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public IEnumerable<EnumValue> EnumValues { get; set; } = null!;
}
