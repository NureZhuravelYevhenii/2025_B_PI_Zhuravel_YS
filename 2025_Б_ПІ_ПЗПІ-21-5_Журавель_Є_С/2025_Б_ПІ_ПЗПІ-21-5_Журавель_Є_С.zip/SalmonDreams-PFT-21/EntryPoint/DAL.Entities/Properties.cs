﻿using DAL.Entities.BaseEntities;

namespace DAL.Entities;

public class Properties : BaseEntity
{
    public int ModuleId { get; set; }
    public Module Module { get; set; } = null!;
    public IEnumerable<Property> InternalProperties { get; set; } = new List<Property>();
}
