﻿using DAL.Entities.BaseEntities;

namespace DAL.Entities;

public class BinaryLibrary : BaseEntity
{
    /// <summary>
    /// Module id.
    /// </summary>
    public int ModuleId { get; set; }

    /// <summary>
    /// Is main library flag. 
    /// </summary>
    public bool IsMainLibrary { get; set; } = false;

    /// <summary>
    /// Bytes of the module assembly.
    /// </summary>
    public byte[] Assembly { get; set; } = [];

    public string Name { get; set; } = string.Empty;

    public Module Module { get; set; } = null!;
}