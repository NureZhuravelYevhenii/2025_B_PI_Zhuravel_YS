﻿using DAL.Entities.BaseEntities;

namespace DAL.Entities;

public class EnumValue : BaseEntity
{
    public string Name { get; set; } = string.Empty;

    public int EnumId { get; set; }
    public Enum Enum { get; set; } = null!;
}
