﻿using DAL.Entities.BaseEntities;
using DAL.Entities.ManyToManyEntities;
using Domain.Enums;

namespace DAL.Entities;

/// <summary>
/// Database model for Module entity.
/// </summary>
public class Module : BaseEntity
{
    /// <summary>
    /// Name of the module.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    public ModuleTypes Type { get; set; }

    /// <summary>
    /// Libraries related to the module.
    /// </summary>
    public IEnumerable<BinaryLibrary> Libraries { get; set; } = new List<BinaryLibrary>();

    public IEnumerable<ModuleContent> Contents { get; set; } = null!;

    public Properties Properties { get; set; } = null!;
}
