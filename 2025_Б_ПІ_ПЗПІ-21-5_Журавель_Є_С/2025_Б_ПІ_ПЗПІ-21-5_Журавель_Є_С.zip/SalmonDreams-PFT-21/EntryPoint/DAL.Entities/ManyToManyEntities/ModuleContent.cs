﻿using DAL.Entities.BaseEntities;
using Domain.Enums;

namespace DAL.Entities.ManyToManyEntities;

public class ModuleContent : BaseEntity
{
    public ContentTypes Type { get; set; }

    public int ModuleId { get; set; }
    public Module Module { get; set; } = null!;
    public int ContentId { get; set; }
    public Content Content { get; set; } = null!;
}
