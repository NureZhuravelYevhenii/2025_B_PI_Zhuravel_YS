﻿using Autofac;
using MainConfigurations.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace DAL.Startup.Autofac;

public class DALModule : Module
{
    protected override void Load(ContainerBuilder builder) 
    {
        builder
            .RegisterType<UnitOfWork>()
            .AsSelf()
            .AsImplementedInterfaces();
        builder
            .Register(context =>
            {
                var configuration = context.Resolve<IConfiguration>();
                var options = new DbContextOptionsBuilder<BaseDbContext>()
                    .UseSqlServer(configuration.GetConnectionString(ConnectionStringsConstants.ModuleConnectionString))
                    .Options;

                return new BaseDbContext(options);
            })
            .AsSelf()
            .AsImplementedInterfaces();
        builder
            .RegisterGeneric(typeof(Repository<>))
            .AsSelf()
            .AsImplementedInterfaces();

        var assembly = typeof(UnitOfWork).Assembly;
        builder
            .RegisterAssemblyTypes(assembly)
            .Where(t => t.Name.Contains("Repository"))
            .AsSelf();
    }
}
