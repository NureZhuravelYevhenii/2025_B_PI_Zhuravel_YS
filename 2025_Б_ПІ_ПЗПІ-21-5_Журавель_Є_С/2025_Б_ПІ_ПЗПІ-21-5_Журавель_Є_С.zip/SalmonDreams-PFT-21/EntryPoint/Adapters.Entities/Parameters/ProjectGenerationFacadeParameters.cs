﻿namespace Adapters.Entities.Parameters;

public class ProjectGenerationFacadeParameters
{
    public string Input { get; set; } = string.Empty;
    public string MarkupType { get; set; } = string.Empty;
    public string ContentBuilder { get; set; } = string.Empty;
}
