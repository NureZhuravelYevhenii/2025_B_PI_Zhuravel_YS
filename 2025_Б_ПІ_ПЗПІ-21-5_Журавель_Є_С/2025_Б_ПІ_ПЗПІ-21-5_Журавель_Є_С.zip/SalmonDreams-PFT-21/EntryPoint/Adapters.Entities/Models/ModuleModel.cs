﻿namespace Adapters.Entities.Models;

public class ModuleModel
{
    public string Name { get; set; } = string.Empty;
    public IEnumerable<PropertyModel> Properties { get; set; } = [];
    public IEnumerable<string> AccaptableContents { get; set; } = [];
    public IEnumerable<string> ProducedContents { get; set; } = [];
}