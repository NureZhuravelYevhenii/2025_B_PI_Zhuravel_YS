﻿using Domain.Enums;

namespace Adapters.Entities.Models;

public class PropertyModel
{
    public string Name { get; set; } = string.Empty;
    public Types Type { get; set; }
    public IEnumerable<PropertyModel> Properties { get; set; } = [];
    public IEnumerable<string> EnumValues { get; set; } = [];
}
