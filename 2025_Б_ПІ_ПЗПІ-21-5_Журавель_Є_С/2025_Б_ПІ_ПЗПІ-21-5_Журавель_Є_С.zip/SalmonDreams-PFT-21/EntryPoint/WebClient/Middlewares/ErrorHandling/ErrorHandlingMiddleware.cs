﻿using Newtonsoft.Json;
using System.Text;
using WebClient.Models;

namespace WebClient.Middlewares.ErrorHandling;

public class ErrorHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ErrorHandlingMiddleware> _logger;

    public ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception: {Message}", ex.Message);

            var error = MapError(ex);
            context.Response.StatusCode = error.StatusCode;
            await context.Response.BodyWriter.WriteAsync(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(error)));
        }
    }

    private Error MapError(Exception ex)
    {
        var error = ex switch
        {
            ArgumentException exception => new Error
            {
                StatusCode = 400,
                Message = ex.Message,
            },
            _ => new Error
            {
                StatusCode = 500,
                Message = ex.Message,
            }
        };

        error = new ErrorWithStackTrace
        {
            Message = error.Message,
            StatusCode = error.StatusCode,
            StackTrace = ex.StackTrace
        };
        return error;
    }
}