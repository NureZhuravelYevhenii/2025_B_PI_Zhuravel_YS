﻿namespace WebClient.Middlewares.ErrorHandling
{
    public static class ErrorHandlingExtension
    {
        public static WebApplication UseErrorHandling(this WebApplication app)
        {
            app.UseMiddleware<ErrorHandlingMiddleware>();
            return app;
        }
    }
}
