﻿namespace WebClient.Models;

public class ErrorWithStackTrace : Error
{
    public string? StackTrace { get; set; } = string.Empty;
}
