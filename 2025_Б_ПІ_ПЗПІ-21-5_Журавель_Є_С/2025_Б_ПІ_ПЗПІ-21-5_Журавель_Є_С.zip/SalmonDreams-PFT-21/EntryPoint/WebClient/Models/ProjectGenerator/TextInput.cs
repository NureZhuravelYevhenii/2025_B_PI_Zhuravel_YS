﻿namespace WebClient.Models.ProjectGenerator;

public class TextInput
{
    public string Text { get; set; } = string.Empty;
    public string MarkupType { get; set; } = string.Empty;
}
