﻿namespace WebClient.Models.ProjectGenerator;

public class FileInput
{
    public IFormFile File { get; set; } = null!;
    public string? MarkupType { get; set; }
}
