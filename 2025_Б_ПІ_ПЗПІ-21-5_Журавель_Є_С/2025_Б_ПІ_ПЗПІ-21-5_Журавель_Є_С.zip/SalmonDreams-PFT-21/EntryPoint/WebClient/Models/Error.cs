﻿namespace WebClient.Models;

public class Error
{
    public string Message { get; set; } = string.Empty;
    public int StatusCode { get; set; }
}
