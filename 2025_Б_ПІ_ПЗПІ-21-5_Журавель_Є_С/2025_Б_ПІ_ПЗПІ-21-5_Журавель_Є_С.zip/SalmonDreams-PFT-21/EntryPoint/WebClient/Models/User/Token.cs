﻿namespace WebClient.Models.User;

public class Token
{
    public string AccessToken { get; set; } = string.Empty;
}
