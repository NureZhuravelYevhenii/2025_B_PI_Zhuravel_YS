using Autofac;
using Autofac.Extensions.DependencyInjection;
using Domain.Configurations;
using Elastic.Transport;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Prometheus;
using System.Reflection;
using System.Text;
using System.Text.Json.Serialization;
using WebClient.Middlewares.ErrorHandling;
using WebClient.ModuleServices.Services;
using WebClient.Services;
using WebClient.Startup.Autofac;

var builder = WebApplication.CreateBuilder(args);

builder.Services.UseHttpClientMetrics();

builder.Configuration.AddJsonFile(Path.Combine(Directory.GetParent(Assembly.GetExecutingAssembly().Location)!.FullName, "appsettings.json"));
// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
.AddJwtBearer(options =>
    {
        var jwtConfiguration = builder.Configuration.GetSection("JwtConfiguration").Get<JwtConfiguration>()
        ?? new JwtConfiguration();

        options.TokenValidationParameters = new TokenValidationParameters();

        options.TokenValidationParameters.ValidateIssuerSigningKey = jwtConfiguration.ValidateSecretKey;
        options.TokenValidationParameters.ValidateLifetime = jwtConfiguration.ValidateLifetime;
        options.TokenValidationParameters.ValidateIssuer = jwtConfiguration.ValidateIssuer;
        options.TokenValidationParameters.ValidateAudience = jwtConfiguration.ValidateAudience;

        if (jwtConfiguration.ValidateSecretKey)
            options.TokenValidationParameters.IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtConfiguration.SecretKey));

        if (jwtConfiguration.ValidateIssuer)
            options.TokenValidationParameters.ValidIssuer = jwtConfiguration.Issuer;

        if (jwtConfiguration.ValidateAudience)
            options.TokenValidationParameters.ValidAudience = jwtConfiguration.Audience;
    });

#if (!DEBUG)
builder.Host.UseSerilog();

var elasticSearchConfiguration = builder.Configuration.GetSection("ElasticSearchConfiguration").Get<ElasticSearchConfiguration>()
    ?? new ElasticSearchConfiguration();

builder.Services.AddLogging(loggingBuilder =>
{
    Serilog.Log.Logger = new LoggerConfiguration()
        .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
        .MinimumLevel.Override("System", LogEventLevel.Error)
        .Enrich.FromLogContext()
        .WriteTo.Console()
        .WriteTo.Elasticsearch([new Uri(elasticSearchConfiguration.Host)], opts =>
        {
            opts.TextFormatting = new EcsTextFormatterConfiguration<EcsDocument>();
            opts.DataStream = new DataStreamName("logs", "salmon-logs", "demo");
            opts.BootstrapMethod = BootstrapMethod.Failure;
        })
        .CreateLogger();

    loggingBuilder.AddSerilog(dispose: true);
});
#endif

builder.Services.AddLogging();

builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory()).ConfigureContainer<ContainerBuilder>(builder =>
{
    builder.RegisterModule<WebClientModule>();
});

builder.Services.AddHostedService<MigrationService>();

builder.Services.AddHostedService<RegisterModulesService>();

var app = builder.Build();

#if (!DEBUG)
app.UseMetricServer();
#endif

app.UseHttpMetrics();

// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

app.UseCors(builder =>
{
    builder.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin();
});

app.UseErrorHandling();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
