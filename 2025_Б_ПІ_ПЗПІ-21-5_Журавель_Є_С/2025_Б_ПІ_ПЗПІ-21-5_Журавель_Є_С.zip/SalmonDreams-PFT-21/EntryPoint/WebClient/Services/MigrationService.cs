﻿using DAL;
using Microsoft.EntityFrameworkCore;

namespace WebClient.Services;

public class MigrationService : BackgroundService
{
    private readonly IServiceProvider _serviceProvider;

    public MigrationService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var scope = _serviceProvider.CreateScope();
        var dbContext = scope.ServiceProvider.GetRequiredService<BaseDbContext>();
        dbContext.Database.Migrate();
        return Task.CompletedTask;
    }
}
