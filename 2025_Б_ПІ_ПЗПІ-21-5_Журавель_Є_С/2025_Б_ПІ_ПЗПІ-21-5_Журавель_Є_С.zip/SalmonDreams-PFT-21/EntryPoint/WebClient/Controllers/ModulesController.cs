﻿using BLL.Abstractions;
using Domain.Enums;
using Microsoft.AspNetCore.Mvc;

namespace WebClient.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ModulesController : ControllerBase
    {
        private readonly IModuleService _moduleService;

        public ModulesController(IModuleService moduleService)
        {
            _moduleService = moduleService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAsync(CancellationToken token)
        {
            return Ok(await _moduleService.GetModuleDefinitionsAsync(ModuleTypes.Module, token));
        }
    }
}
