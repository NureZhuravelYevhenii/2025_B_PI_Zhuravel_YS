﻿using BLL.Abstractions;
using Domain.Enums;
using Microsoft.AspNetCore.Mvc;

namespace WebClient.Controllers
{
    [Route("api/sub-modules")]
    [ApiController]
    public class SubModulesController : ControllerBase
    {
        private readonly IModuleService _moduleService;

        public SubModulesController(IModuleService moduleService)
        {
            _moduleService = moduleService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAsync(CancellationToken token)
        {
            return Ok(await _moduleService.GetModuleDefinitionsAsync(ModuleTypes.SubModule, token));
        }
    }
}
