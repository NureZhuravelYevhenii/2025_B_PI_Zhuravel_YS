﻿using Microsoft.AspNetCore.Mvc;

namespace WebClient.Controllers.BaseControllers;

public class BaseController : ControllerBase
{
    protected void AddCookie(string name, string value)
    {
        Response.Cookies.Append(name, value, new CookieOptions
        {
            HttpOnly = true,
            Domain = Request.Host.Host,
        });
    }

    protected string GetCookie(string name) => Request.Cookies.FirstOrDefault(pair => pair.Key == name).Value;
}