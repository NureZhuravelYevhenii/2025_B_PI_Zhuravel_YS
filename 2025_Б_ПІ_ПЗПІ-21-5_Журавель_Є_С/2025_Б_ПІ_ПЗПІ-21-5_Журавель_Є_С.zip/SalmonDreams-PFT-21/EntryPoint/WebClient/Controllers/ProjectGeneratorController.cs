﻿using Adapters;
using Adapters.Entities.Parameters;
using Microsoft.AspNetCore.Mvc;
using WebClient.Models.ProjectGenerator;

namespace WebClient.Controllers;

[Route("api/project-generator")]
[ApiController]
public class ProjectGeneratorController : ControllerBase
{
    private readonly ProjectGenerationFacade _projectGenerationFacade;

    public ProjectGeneratorController(ProjectGenerationFacade projectGenerationFacade)
    {
        _projectGenerationFacade = projectGenerationFacade;
    }

    [HttpPost("text/{contentBuilderType}")]
    public async Task<IActionResult> GenerateArchiveForTextAsync([FromBody]TextInput textInput, [FromRoute]string contentBuilderType, CancellationToken token)
    {
        var parameters = new ProjectGenerationFacadeParameters
        {
            Input = textInput.Text,
            MarkupType = textInput.MarkupType,
            ContentBuilder = contentBuilderType
        };
        var returnResult = await _projectGenerationFacade.GenerateProjectArchiveAsync(parameters, token);
        return returnResult.Item1 is not null 
            ? File(returnResult.Item1, returnResult.Item2)
            : Ok();
    }

    [HttpPost("file/{contentBuilderType}")]
    public async Task<IActionResult> GenerateArchiveForFileAsync(FileInput fileInput, [FromRoute] string contentBuilderType, CancellationToken token)
    {
        var markupType = fileInput.MarkupType;

        if(markupType is null)
            markupType = fileInput.File.FileName.Split('.').LastOrDefault() 
                ?? throw new ArgumentException("There is no markup type specified.");

        using var memoryStream = new MemoryStream();
        await fileInput.File.CopyToAsync(memoryStream);
        using var streamReader = new StreamReader(memoryStream);
        var input = await streamReader.ReadToEndAsync();

        var parameters = new ProjectGenerationFacadeParameters
        {
            Input = input,
            MarkupType = markupType,
            ContentBuilder = contentBuilderType
        };
        var returnResult = await _projectGenerationFacade.GenerateProjectArchiveAsync(parameters, token);
        return returnResult.Item1 is not null
            ? File(returnResult.Item1, returnResult.Item2)
            : Ok();
    }
}
