﻿using BLL.Abstractions;
using BLL.Entities.Users;
using Domain.Constants;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using WebClient.Controllers.BaseControllers;
using WebClient.Models.User;

namespace WebClient.Controllers;

[Route("api/[controller]")]
[ApiController]
public class UsersController : BaseController
{
    private readonly IUserService _userService;

    public UsersController(IUserService userService)
    {
        _userService = userService;
    }

    [HttpPost("register")]
    public async Task<IActionResult> RegisterAsync(UserCreationDto newUser, CancellationToken token)
    {
        return FormTokensResponse(await _userService.RegisterAsync(newUser, token));
    }

    [HttpPost("login")]
    public async Task<IActionResult> LoginAsync(UserLogin userLogin, CancellationToken token)
    {
        return FormTokensResponse(await _userService.LoginAsync(userLogin, token));
    }

    [HttpPost("refresh")]
    public async Task<IActionResult> RefreshAsync(CancellationToken token)
    {
        var refreshToken = GetCookie(JwtHttpConstants.RefreshTokenCookieName);
        if (string.IsNullOrEmpty(refreshToken))
            throw new UnauthorizedAccessException("There is no refresh token specified");

        return FormTokensResponse(await _userService.RefreshTokenAsync(refreshToken, token));
    }

    [Authorize]
    [HttpGet]
    public async Task<IActionResult> GetUserAsync(CancellationToken token)
    {
        var idStr = User.FindFirstValue(JwtTypeConstants.Id)
            ?? throw new ArgumentException("Unable to get id from token.");

        var id = int.Parse(idStr);

        return Ok(await _userService.GetUserAsync(id, token));
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetUserAsync(int id, CancellationToken token)
    {
        return Ok(await _userService.GetUserAsync(id, token));
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteUserAsync(int id, CancellationToken token)
    {
        await _userService.DeleteAsync(id, token);
        return Ok();
    }

    [HttpPut]
    public async Task<IActionResult> UpdateUserAsync(UserUpdateDto updatedUser, CancellationToken token)
    {
        await _userService.UpdateAsync(updatedUser, token);
        return Ok();
    }

    private IActionResult FormTokensResponse(TokenPair tokens)
    {
        AddCookie(JwtHttpConstants.RefreshTokenCookieName, tokens.RefreshToken);

        return Ok(new Token
        {
            AccessToken = tokens.AccessToken,
        });
    }
}