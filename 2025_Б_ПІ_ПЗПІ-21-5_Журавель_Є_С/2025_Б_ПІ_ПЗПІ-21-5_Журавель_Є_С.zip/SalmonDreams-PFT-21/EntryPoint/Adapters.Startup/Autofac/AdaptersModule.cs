﻿using Autofac;

namespace Adapters.Startup.Autofac;

public class AdaptersModule : Module
{
    protected override void Load(ContainerBuilder builder)
    {
        builder.RegisterAssemblyTypes(typeof(ProjectGenerationFacade).Assembly)
            .Where(t => t.Name.Contains("Facade"))
            .AsSelf()
            .AsImplementedInterfaces();
    }
}