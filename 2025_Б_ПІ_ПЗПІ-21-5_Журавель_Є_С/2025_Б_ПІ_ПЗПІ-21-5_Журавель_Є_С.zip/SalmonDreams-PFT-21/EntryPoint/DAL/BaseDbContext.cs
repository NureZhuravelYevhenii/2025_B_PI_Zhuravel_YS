﻿using DAL.Entities;
using Microsoft.EntityFrameworkCore;

namespace DAL;

/// <summary>
/// Custom DbContext implementation for this project.
/// </summary>
public class BaseDbContext : DbContext
{
    /// <summary>
    /// Modules table definition.
    /// </summary>
    public DbSet<Module> Modules { get; set; }

    /// <summary>
    /// SubModules table definition.
    /// </summary>
    public DbSet<User> Users { get; set; }

    public BaseDbContext(DbContextOptions<BaseDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(BaseDbContext).Assembly);
    }
}