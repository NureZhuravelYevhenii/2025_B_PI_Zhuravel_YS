﻿using MainConfigurations.Constants;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DAL.DesignTimeTypes;

public class DesignTimeFactory : IDesignTimeDbContextFactory<BaseDbContext>
{
    public BaseDbContext CreateDbContext(string[] args)
    {
        var configurations = new ConfigurationBuilder()
            .AddJsonFile(ConfigurationConstants.AppConfigurationJsonFileName, false)
            .Build();

        var options = new DbContextOptionsBuilder<BaseDbContext>()
            .UseSqlServer(configurations.GetConnectionString(ConnectionStringsConstants.ModuleConnectionString))
            .Options;

        return new BaseDbContext(options);
    }
}