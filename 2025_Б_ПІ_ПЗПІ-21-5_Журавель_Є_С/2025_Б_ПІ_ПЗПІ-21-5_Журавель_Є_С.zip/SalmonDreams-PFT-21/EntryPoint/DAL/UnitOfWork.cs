﻿using Autofac;
using DAL.Abstractions;
using DAL.Entities.BaseEntities;

namespace DAL;

/// <summary>
/// Unit of Work class for managing transactions and repositories.
/// </summary>
public class UnitOfWork : IUnitOfWork
{
    private static IEnumerable<Type> _assemblyTypes = typeof(UnitOfWork).Assembly.GetTypes();

    private readonly BaseDbContext _dbContext;
    private readonly IComponentContext _componentContext;
    private readonly IDictionary<Type, object> _instantiatedRepositories = new Dictionary<Type, object>();

    /// <summary>
    /// Initializes a new instance of the <see cref="UnitOfWork"/> class.
    /// </summary>
    /// <param name="dbContext">The database context to be used.</param>
    /// <param name="componentContext">The service provider for resolving dependencies.</param>
    public UnitOfWork(BaseDbContext dbContext, IComponentContext componentContext)
    {
        _dbContext = dbContext;
        _componentContext = componentContext;
    }

    /// <summary>
    /// Asynchronously commits all changes made in the current unit of work.
    /// </summary>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public Task CommitAsync(CancellationToken token = default)
    {
        return _dbContext.SaveChangesAsync(token);
    }

    /// <summary>
    /// Asynchronously retrieves a repository for a specific entity type.
    /// </summary>
    /// <typeparam name="T">The type of entity for which to retrieve the repository.</typeparam>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the repository for the specified entity type.</returns>
    public Task<IRepository<T>> GetRepositoryAsync<T>(CancellationToken token = default) where T : BaseEntity
    {
        var repositoryType = typeof(IRepository<T>);
        if (_instantiatedRepositories.ContainsKey(repositoryType))
        {
            return Task.FromResult((IRepository<T>)_instantiatedRepositories[repositoryType]);
        }

        var specificRepositories = _assemblyTypes.Where(t => t.IsAssignableTo(typeof(IRepository<T>)));
        if (!specificRepositories.Any())
        {
            var repository = new Repository<T>(_dbContext);
            _instantiatedRepositories[repositoryType] = repository;
            return Task.FromResult((IRepository<T>)repository);
        }

        return GetSpecificRepository(specificRepositories.First(), token)
            .ContinueWith(task => (IRepository<T>)task.Result, token);
    }

    /// <summary>
    /// Asynchronously retrieves a specific repository by type.
    /// </summary>
    /// <typeparam name="T">The type of the specific repository to retrieve.</typeparam>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the specific repository.</returns>
    public Task<T> GetSpecificRepository<T>(CancellationToken token = default)
    {
        var repositoryType = typeof(T);
        if (_instantiatedRepositories.ContainsKey(repositoryType))
        {
            return Task.FromResult((T)_instantiatedRepositories[repositoryType]);
        }

        return GetSpecificRepository(typeof(T), token)
            .ContinueWith(task => (T)task.Result, token);
    }

    /// <summary>
    /// Asynchronously retrieves a specific repository by type.
    /// </summary>
    /// <param name="specificRepositoryType">The type of the specific repository to retrieve.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the specific repository.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the specific repository cannot be created.</exception>
    private Task<object> GetSpecificRepository(Type specificRepositoryType, CancellationToken token)
    {
        var constructor = specificRepositoryType.GetConstructors().First();
        var parameters = constructor.GetParameters();
        var parameterValues = new List<object>();
        foreach (var parameter in parameters)
        {
            if (parameter.ParameterType.IsAssignableFrom(typeof(BaseDbContext)))
                parameterValues.Add(_dbContext);
            else
                parameterValues.Add(_componentContext.Resolve(parameter.ParameterType));
        }

        var specificRepository = constructor.Invoke(parameterValues.ToArray());
        if (specificRepository is null)
            throw new InvalidOperationException($"Unable to create {specificRepositoryType.Name}.");
        _instantiatedRepositories[specificRepositoryType] = specificRepository;
        return Task.FromResult(specificRepository);
    }
}
