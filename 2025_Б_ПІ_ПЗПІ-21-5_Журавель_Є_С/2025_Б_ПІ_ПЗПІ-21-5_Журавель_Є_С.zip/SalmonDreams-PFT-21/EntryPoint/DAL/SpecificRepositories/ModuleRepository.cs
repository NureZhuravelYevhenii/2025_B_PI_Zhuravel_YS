﻿using DAL.Abstractions;
using DAL.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq.Expressions;

namespace DAL.SpecificRepositories;

public class ModuleRepository : Repository<Module>, IRepository<Module>
{
    private readonly BaseDbContext _context;

    public ModuleRepository(BaseDbContext context) : base(context)
    {
        _context = context;
    }

    public override async Task<IQueryable<Module>> GetByPredicateAsync(Expression<Func<Module, bool>> predicate, int skip = 0, int take = int.MaxValue, CancellationToken token = default)
    {
        var modules = await _dbSet
            .Where(predicate)
            .Take(take)
            .Skip(skip)
            .Include(module => module.Contents)
                .ThenInclude(mc => mc.Content)
            .Include(module => module.Properties)
            .ToListAsync();

        return await LoadSubPropertiesAsync(modules, token);
    }

    public override async Task<IQueryable<Module>> GetAllAsync(int skip = 0, int take = int.MaxValue, CancellationToken token = default)
    {
        var modules = await _dbSet
            .Take(take)
            .Skip(skip)
            .Include(module => module.Contents)
                .ThenInclude(mc => mc.Content)
            .Include(module => module.Properties)
            .ToListAsync();

        return await LoadSubPropertiesAsync(modules, token);
    }

    public override async Task<Module?> GetByIdAsync(int id, CancellationToken token = default)
    {
        var module = await _dbSet
            .Include(module => module.Contents)
                .ThenInclude(mc => mc.Content)
            .Include(module => module.Properties)
            .FirstOrDefaultAsync(module => module.Id == id);

        if (module is null)
            return null;

        return await LoadSubPropertiesAsync(module, token);
    }

    public override async Task<Module?> GetByPredicateFirstAsync(Expression<Func<Module, bool>> predicate, CancellationToken token = default)
    {
        var module = await _dbSet
            .Include(module => module.Contents)
                .ThenInclude(mc => mc.Content)
            .Include(module => module.Properties)
            .FirstOrDefaultAsync(predicate);

        if (module is null)
            return null;

        return await LoadSubPropertiesAsync(module, token);
    }

    private async Task<IQueryable<Module>> LoadSubPropertiesAsync(IEnumerable<Module> modules, CancellationToken token = default)
    {
        foreach (var module in modules)
        {
            await LoadSubPropertiesAsync(module, token);
        }

        return modules.AsQueryable();
    }

    private async Task<Module> LoadSubPropertiesAsync(Module module, CancellationToken token = default)
    {
        if (module.Properties is null)
            return module;

        await _context.Set<Property>()
            .Include(prop => prop.Enum)
                .ThenInclude(@enum => @enum.EnumValues)
            .Where(prop => prop.PropertiesId == module.Properties.Id)
            .LoadAsync(token);
        return module;
    }
}