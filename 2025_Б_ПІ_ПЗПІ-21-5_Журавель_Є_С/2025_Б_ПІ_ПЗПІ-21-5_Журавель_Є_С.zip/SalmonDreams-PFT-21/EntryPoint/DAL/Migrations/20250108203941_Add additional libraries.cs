﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class Addadditionallibraries : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Assembly",
                table: "SubModules");

            migrationBuilder.DropColumn(
                name: "Assembly",
                table: "Modules");

            migrationBuilder.CreateTable(
                name: "ModuleBinaryLibrary",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ModuleId = table.Column<int>(type: "int", nullable: false),
                    IsMainLibrary = table.Column<bool>(type: "bit", nullable: false),
                    Assembly = table.Column<byte[]>(type: "varbinary(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModuleBinaryLibrary", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ModuleBinaryLibrary_Modules_ModuleId",
                        column: x => x.ModuleId,
                        principalTable: "Modules",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SubModuleBinaryLibrary",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ModuleId = table.Column<int>(type: "int", nullable: false),
                    IsMainLibrary = table.Column<bool>(type: "bit", nullable: false),
                    Assembly = table.Column<byte[]>(type: "varbinary(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubModuleBinaryLibrary", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SubModuleBinaryLibrary_SubModules_ModuleId",
                        column: x => x.ModuleId,
                        principalTable: "SubModules",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ModuleBinaryLibrary_ModuleId",
                table: "ModuleBinaryLibrary",
                column: "ModuleId");

            migrationBuilder.CreateIndex(
                name: "IX_SubModuleBinaryLibrary_ModuleId",
                table: "SubModuleBinaryLibrary",
                column: "ModuleId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ModuleBinaryLibrary");

            migrationBuilder.DropTable(
                name: "SubModuleBinaryLibrary");

            migrationBuilder.AddColumn<byte[]>(
                name: "Assembly",
                table: "SubModules",
                type: "varbinary(max)",
                nullable: false,
                defaultValue: new byte[0]);

            migrationBuilder.AddColumn<byte[]>(
                name: "Assembly",
                table: "Modules",
                type: "varbinary(max)",
                nullable: false,
                defaultValue: new byte[0]);
        }
    }
}
