﻿using Autofac;
using AutoMapper;
using Domain.Configurations;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace Domain.Startup.Autofac;

public class DomainModule : Module
{
    protected override void Load(ContainerBuilder builder) 
    {
        builder.RegisterInstance(new MapperConfiguration(expression =>
            {
                expression.AddProfile<BLL.Mapper.GeneralProfile>();
            }).CreateMapper())
            .As<IMapper>()
            .AsSelf()
            .AsImplementedInterfaces();

        builder.Register(context =>
        {
            var configuration = context.Resolve<IConfiguration>();

            return Options.Create(configuration.GetSection("JwtConfiguration").Get<JwtConfiguration>() ?? new JwtConfiguration());
        })
            .As<IOptions<JwtConfiguration>>();

        builder.Register(context =>
        {
            var configuration = context.Resolve<IConfiguration>();

            return Options.Create(configuration.GetSection("DebugConfig").Get<DebugConfiguration>() ?? new DebugConfiguration());
        })
            .As<IOptions<DebugConfiguration>>();
    }
}
