﻿using BLL.Abstractions;
using System.Runtime.Loader;

namespace BLL;

public class AssemblyLoadContextWrapper : IAssemblyLoadContextWrapper, IDisposable
{
    public AssemblyLoadContext AssemblyLoadContext { get; }

    public AssemblyLoadContextWrapper()
    {
        AssemblyLoadContext = new AssemblyLoadContext($"{Guid.NewGuid()}");
    }

    public void Dispose()
    {
        if (AssemblyLoadContext.IsCollectible)
            AssemblyLoadContext?.Unload();
    }
}
