﻿using BLL.Abstractions.Converters;
using Newtonsoft.Json.Linq;

namespace BLL.Services.Converters;

public class NewtonJsonConverters : IConverters
{
    public IDictionary<Type, Func<object, object?>> Converters => new Dictionary<Type, Func<object, object?>>
    {
        { typeof(JValue), obj => ((JValue)obj).Value }
    };
}
