﻿using BLL.Abstractions.Converters;

namespace BLL.Services.Converters;

public class ConvertersService : IConvertersService
{
    public IDictionary<Type, Func<object, object?>> Converters { get; }

    public ConvertersService(IEnumerable<IConverters> converters)
    {
        Converters = converters.SelectMany(conv => conv.Converters).ToDictionary(conv => conv.Key, conv => conv.Value);
    }
}