﻿using BLL.Abstractions;
using BLL.Entities;
using Newtonsoft.Json;

namespace BLL.Services;

public class JsonParseService : IParseService
{
    public string MarkupType => "json";

    public Task<IEnumerable<SimplifiedModule>> ParseToSimplifiedAsync(string input, CancellationToken token = default)
    {
        return Task.FromResult(JsonConvert.DeserializeObject<IEnumerable<SimplifiedModule>>(input) 
            ?? throw new ArgumentException($"Unable to deserialize: {input}"));
    }
}
