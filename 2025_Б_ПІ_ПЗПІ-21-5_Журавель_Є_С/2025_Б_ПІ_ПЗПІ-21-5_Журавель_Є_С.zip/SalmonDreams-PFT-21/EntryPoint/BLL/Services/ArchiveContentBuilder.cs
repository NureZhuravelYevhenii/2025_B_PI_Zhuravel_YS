﻿using ICSharpCode.SharpZipLib.Zip;
using MainAbstractions.Builders;
using MainAbstractions.Modules.Content;

namespace BLL.Services;

public class ArchiveContentBuilder : IContentBuilder
{
    public string ContentBuilderType => "archive";
    public string ContentType => "application/zip";

    public async Task<Stream?> ParseInCodeAsync(IEnumerable<RawContent> rawContents, CancellationToken cancellationToken = default)
    {
        var archiveMemoryStream = new MemoryStream();
        var zipOutputStream = new ZipOutputStream(archiveMemoryStream);
        zipOutputStream.SetLevel(3);

        foreach (var content in rawContents)
        {
            var zipEntry = new ZipEntry(content.Name);
            zipEntry.Size = content.Content.Count();
            await zipOutputStream.PutNextEntryAsync(zipEntry);
            await zipOutputStream.WriteAsync(content.Content.ToArray(), cancellationToken);
            await zipOutputStream.CloseEntryAsync(cancellationToken);
        }

        zipOutputStream.IsStreamOwner = false;
        await zipOutputStream.FinishAsync(cancellationToken);
        archiveMemoryStream.Position = 0;

        return archiveMemoryStream;
    }
}
