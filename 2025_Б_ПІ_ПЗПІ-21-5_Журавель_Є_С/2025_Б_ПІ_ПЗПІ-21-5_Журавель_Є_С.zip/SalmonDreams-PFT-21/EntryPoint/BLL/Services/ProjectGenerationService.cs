﻿using BLL.Abstractions;
using BLL.Entities;
using MainAbstractions.Modules;
using MainAbstractions.Modules.Content;

namespace BLL.Services;

public class ProjectGenerationService : IProjectGenerationService
{
    private readonly IModuleService _moduleService;

    public ProjectGenerationService(IModuleService moduleService)
    {
        _moduleService = moduleService;
    }

    public async Task<IEnumerable<RawContent>> GenerateProjectAsync(IEnumerable<SimplifiedModule> simplifiedModules, CancellationToken token = default)
    {
        var content = new List<RawContent>();
        foreach (var module in simplifiedModules)
        {
            if(module is null)
                continue;
            var moduleInstance = await _moduleService.GetModuleInstanceAsync<IModule>(module.Name, module.Properties, token);
            moduleInstance.Modules = await GetSubModulesAsync(module.Modules, token);
            content.AddRange(await moduleInstance.ParseInCodeAsync(token));
        }

        return content;
    }

    private async Task<IEnumerable<ISubModule>> GetSubModulesAsync(IEnumerable<SimplifiedModule> modules, CancellationToken token)
    {
        var moduleInstances = new List<ISubModule>();
        foreach (var module in modules)
        {
            var moduleInstance = await _moduleService.GetModuleInstanceAsync<ISubModule>(module.Name, module.Properties, token);
            moduleInstance.Modules = await GetSubModulesAsync(module.Modules, token);
            moduleInstances.Add(moduleInstance);
        }
        return moduleInstances;
    }
}
