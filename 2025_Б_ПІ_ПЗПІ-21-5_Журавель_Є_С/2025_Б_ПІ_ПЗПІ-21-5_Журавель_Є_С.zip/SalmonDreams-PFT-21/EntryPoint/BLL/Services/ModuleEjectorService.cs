﻿using System.Collections;
using System.Linq.Expressions;
using System.Reflection;
using BLL.Abstractions;
using BLL.Abstractions.Converters;
using BLL.Helpersp;
using MainAbstractions.Modules;
using MainAbstractions.Modules.Metadata;
using MainConfigurations.Constants;
using Newtonsoft.Json;

namespace BLL.Services;

/// <summary>
/// Helper class for managing module extraction and instantiation.
/// </summary>
public class ModuleEjectorService : IModuleEjectorService
{
    private static IDictionary<Type, Action<object, PropertyInfo, IEnumerable<object>>> AssignEnumerableWithValueCastDictionary = new Dictionary<Type, Action<object, PropertyInfo, IEnumerable<object>>>();

    private static MethodInfo _firstOrDefault = typeof(Enumerable)
        .GetMethods()
        .FirstOrDefault(m => m.Name == "FirstOrDefault" && m.GetParameters().Length == 2 && m.GetParameters().Any(param => param.ParameterType.Name.Contains("Func")))
        ?? throw new InvalidOperationException("Unable to get FirstOrDefault from Enumerable.");
    private static MethodInfo _select = typeof(Enumerable).GetMethods().FirstOrDefault(m => m.Name == "Select")
        ?? throw new InvalidOperationException("Unable to find Select in type IEnumerable<object>.");
    private static MethodInfo _getType = typeof(object).GetMethod("GetType")
        ?? throw new InvalidOperationException("Unable to find GetType in type object.");
    private static MethodInfo _setValue = typeof(PropertyInfo).GetMethod("SetValue", [typeof(object), typeof(object)])
        ?? throw new InvalidOperationException("Unable to find SetValue in type PropertyInfo.");

    private readonly IConvertersService _convertersService;

    public ModuleEjectorService(IConvertersService convertersService)
    {
        _convertersService = convertersService;
    }

    /// <summary>
    /// Retrieves a module instance from the specified assembly.
    /// </summary>
    /// <typeparam name="TModule">The type of the module to retrieve.</typeparam>
    /// <param name="assembly">The assembly to search for the module.</param>
    /// <param name="moduleName">The name of the module.</param>
    /// <returns>The instance of the module.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the module class cannot be found or instantiated.</exception>
    public TModule GetModule<TModule>(Assembly assembly) where TModule : class, IModuleBase
    {
        var moduleType = assembly.GetTypes().FirstOrDefault(t => t.IsClass && t.IsAssignableTo(typeof(TModule)))
            ?? throw new InvalidOperationException($"Unable to get class from assembly {assembly.GetName()}.");
        var module = Activator.CreateInstance(moduleType) as TModule
            ?? throw new InvalidOperationException($"Unable to create instance of module class {moduleType.Name} for assembly {assembly.GetName()}.");
        return module;
    }

    /// <summary>
    /// Asynchronously retrieves metadata for a specified module from the assembly.
    /// </summary>
    /// <param name="assembly">The assembly to search for the module metadata.</param>
    /// <param name="moduleName">The name of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the module metadata.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the module metadata cannot be found or read.</exception>
    public async Task<ModuleMetadata> GetModuleMetadata(Assembly assembly, CancellationToken token = default)
    {
        var assemblyName = assembly.GetName().Name
            ?? throw new InvalidOperationException($"Unable to get assembly name for {assembly.FullName}.");
        var moduleMetadataStream = assembly.GetManifestResourceStream($"{assemblyName}.{ModuleConstants.ModuleMetadataFileName}")
            ?? throw new InvalidOperationException($"Unable to get description file for assembly {assembly.GetName()}.");
        return JsonConvert.DeserializeObject<ModuleMetadata>(await new StreamReader(moduleMetadataStream).ReadToEndAsync(token))
            ?? throw new InvalidOperationException($"Unable to read description file for assembly {assembly.GetName()}.");
    }

    /// <summary>
    /// Retrieves module properties for a specified module from the assembly.
    /// </summary>
    /// <param name="assembly">The assembly to search for the module properties.</param>
    /// <param name="moduleName">The name of the module.</param>
    /// <param name="rawProperties">A dictionary of raw properties to seed into the module properties.</param>
    /// <returns>The instance of the module properties.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the module properties cannot be created or instantiated.</exception>
    public IModuleProperties GetModuleProperties(Assembly assembly, IDictionary<string, object> rawProperties = null!)
    {
        rawProperties ??= new Dictionary<string, object>();

        var modulePropertiesType = assembly.GetTypes().FirstOrDefault(t => t.IsClass && t.IsAssignableTo(typeof(IModuleProperties)))
            ?? throw new InvalidOperationException($"Unable to create module properties for assembly {assembly.GetName()}.");
        var moduleProperties = Activator.CreateInstance(modulePropertiesType) as IModuleProperties
            ?? throw new InvalidOperationException($"Unable to instantiate module properties for assembly {assembly.GetName()}.");

        if (rawProperties.Keys.Count > 0)
        {
            SeedProperties(moduleProperties, modulePropertiesType, rawProperties);
        }

        return moduleProperties;
    }

    public Type GetModulePropertiesType(Assembly assembly)
    {
        return assembly.GetTypes().FirstOrDefault(t => t.IsClass && t.IsAssignableTo(typeof(IModuleProperties)))
            ?? throw new InvalidOperationException($"Unable to create module properties for assembly {assembly.GetName()}.");
    }

    /// <summary>
    /// Seeds the specified properties into the module properties instance.
    /// </summary>
    /// <param name="moduleProperties">The module properties instance.</param>
    /// <param name="modulePropertiesType">The type of the module properties.</param>
    /// <param name="rawProperties">The dictionary of raw properties.</param>
    private void SeedProperties(IModuleProperties moduleProperties, Type modulePropertiesType, IDictionary<string, object> rawProperties)
        => SeedObject(modulePropertiesType, rawProperties, moduleProperties);

    /// <summary>
    /// Creates an instance of the specified type and seeds the specified properties into it.
    /// </summary>
    /// <param name="typeToSeed">The type to create an instance of.</param>
    /// <param name="data">The dictionary of raw properties.</param>
    /// <param name="instance">An optional existing instance to seed the properties into.</param>
    /// <returns>The instance of the specified type with the properties seeded.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the instance of the specified type cannot be created.</exception>
    private object SeedObject(Type typeToSeed, IDictionary<string, object> data, object instance = null!)
    {
        instance ??= Activator.CreateInstance(typeToSeed)
            ?? throw new InvalidOperationException($"Unable to create instance of type {typeToSeed.Name}.");

        data = data.ToDictionary(kv => kv.Key.ToLower(), kv => kv.Value);
        var existedProperties = data.Keys;
        var properties = typeToSeed.GetProperties()
            .Where(p => existedProperties.Contains(p.Name.ToLower()));

        foreach (var prop in properties)
        {
            var value = data[prop.Name.ToLower()];
            var valueType = value.GetType();
            var propertyType = prop.PropertyType;
            if (propertyType.IsEnum && valueType == typeof(string))
            {
                value = Enum.Parse(propertyType, (string)value);
            }
            if (TypeHelper.IsDictionary(valueType) && !TypeHelper.IsDictionary(propertyType))
            {
                value = SeedObject(propertyType, (IDictionary<string, object>)value);
            }
            else if (TypeHelper.IsEnumerable(valueType) && TypeHelper.IsEnumerable(propertyType) && !valueType.IsAssignableTo(propertyType))
            {
                var assignDelegate = GetAssignEnumerableWithValueCast(propertyType.GetGenericArguments().First());

                assignDelegate(instance, prop, (IEnumerable<object>)value);
                continue;
            }

            prop.SetValue(instance, value);
        }

        return instance;
    }

    private Action<object, PropertyInfo, IEnumerable<object>> GetAssignEnumerableWithValueCast(Type enumerableValueType)
    {
        if (AssignEnumerableWithValueCastDictionary.ContainsKey(enumerableValueType))
            return AssignEnumerableWithValueCastDictionary[enumerableValueType];

        var convertors = _convertersService.Converters;

        var returnLabel = Expression.Label();

        var instanceParameter = Expression.Parameter(typeof(object), "instance");
        var propertyInfoParameter = Expression.Parameter(typeof(PropertyInfo), "propertyInfo");
        var enumerableToAssignParameter = Expression.Parameter(typeof(IEnumerable<object>), "enumerableToAssign");

        var convertersConstant = Expression.Constant(convertors);
        var firstObjectVariable = Expression.Variable(typeof(object), "firstElement");
        var firstObjectAssign = Expression.Assign(
            firstObjectVariable,
            Expression.Call(
                null,
                _firstOrDefault.MakeGenericMethod(typeof(object)),
                enumerableToAssignParameter, 
                Expression.Lambda(
                    Expression.Constant(true),
                    Expression.Parameter(typeof(object)))));
        var ifFirstObjectIsNullStatement = Expression.IfThen(
            Expression.Equal(
                firstObjectVariable,
                Expression.Constant(null)),
            Expression.Block(
                Expression.Call(
                    propertyInfoParameter,
                    _setValue,
                    instanceParameter,
                    Expression.Constant(
                        Activator.CreateInstance(typeof(List<>).MakeGenericType(enumerableValueType)))),
                Expression.Return(returnLabel)));

        var keyValueParameter = Expression.Parameter(typeof(KeyValuePair<Type, Func<object, object?>>), "kv");
        var convertorPredicate = Expression.Lambda(Expression.Equal(Expression.Call(firstObjectVariable, _getType), Expression.Property(keyValueParameter, "Key")), keyValueParameter);
        var convertorVariable = Expression.Variable(typeof(Func<object, object?>), "convertor");

        var getConvertor = Expression.Call(null, _firstOrDefault.MakeGenericMethod(typeof(KeyValuePair<Type, Func<object, object?>>)), convertersConstant, convertorPredicate);
        var assigningConvertor = Expression.Assign(convertorVariable, Expression.Property(getConvertor, "Value"));

        var castExpressionParameter = Expression.Parameter(typeof(object), "obj");
        var castExpression = Expression.Lambda(Expression.Convert(castExpressionParameter, enumerableValueType), castExpressionParameter);

        var castExpressionWithConverter = Expression.Lambda(Expression.Convert(Expression.Invoke(convertorVariable, castExpressionParameter), enumerableValueType), castExpressionParameter);

        var selectMethod = Expression.Call(null, _select.MakeGenericMethod(typeof(object), enumerableValueType), enumerableToAssignParameter, castExpression);

        var selectMethodWithConvertor = Expression.Call(null, _select.MakeGenericMethod(typeof(object), enumerableValueType), enumerableToAssignParameter, castExpressionWithConverter);

        var newCollectionVariable = Expression.Variable(typeof(object), "newCollection");
        var assignCastedCollectionToNewCollection = Expression.Assign(newCollectionVariable, selectMethod);
        var assignCastedCollectionToNewCollectionWithConverter = Expression.Assign(newCollectionVariable, selectMethodWithConvertor);

        var ifConverterStatement = Expression.IfThenElse(Expression.Equal(convertorVariable, Expression.Constant(null)), assignCastedCollectionToNewCollection, assignCastedCollectionToNewCollectionWithConverter);

        var assignMethod = Expression.Call(propertyInfoParameter, _setValue, instanceParameter, newCollectionVariable);

        var lambda = Expression.Lambda<Action<object, PropertyInfo, IEnumerable<object>>>(
            Expression.Block(
                [newCollectionVariable, convertorVariable, firstObjectVariable],
                firstObjectAssign,
                ifFirstObjectIsNullStatement,
                assigningConvertor,
                ifConverterStatement,
                assignMethod,
                Expression.Label(returnLabel)),
            instanceParameter,
            propertyInfoParameter,
            enumerableToAssignParameter);

        var compiledLambda = lambda.Compile();

        AssignEnumerableWithValueCastDictionary.Add(enumerableValueType, compiledLambda);
        return compiledLambda;
    }
}
