﻿using BLL.Abstractions;
using BLL.Entities.Modules;
using BLL.Helpers;
using DAL.Abstractions;
using DAL.Entities;
using DAL.Entities.ManyToManyEntities;
using Domain.Enums;
using MainAbstractions.Modules;
using System.Reflection;
using System.Runtime.Loader;
using System.Text;
using YamlDotNet.Core.Tokens;
using DALModule = DAL.Entities.Module;

namespace BLL.Services;

/// <summary>
/// Service class for managing modules and sub-modules.
/// </summary>
public class ModuleService : IModuleService
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IModuleEjectorService _moduleEjectorService;

    /// <summary>
    /// Initializes a new instance of the <see cref="ModuleService"/> class.
    /// </summary>
    /// <param name="unitOfWork">The unit of work.</param>
    public ModuleService(IUnitOfWork unitOfWork, IModuleEjectorService moduleEjectorService)
    {
        _unitOfWork = unitOfWork;
        _moduleEjectorService = moduleEjectorService;
    }

    /// <summary>
    /// Retrieves a module by its name and initializes its properties.
    /// </summary>
    /// <param name="name">The name of the module.</param>
    /// <param name="properties">A dictionary of properties to initialize the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the module instance.</returns>
    public async Task<TModuleAbstraction> GetModuleInstanceAsync<TModuleAbstraction>(string name, IDictionary<string, object> properties, CancellationToken token = default)
        where TModuleAbstraction : class, IModuleBase
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);
        var libraryRepository = await _unitOfWork.GetRepositoryAsync<BinaryLibrary>(token);

        var module = await repository.GetByPredicateFirstAsync(m => m.Name == name, token)
            ?? throw new ArgumentException($"Unable to find module {name}.");

        var libraries = (await libraryRepository.GetByPredicateAsync(l => l.ModuleId == module.Id, token: token)).ToList();

        if (!libraries.Any(library => library.IsMainLibrary))
            throw new InvalidOperationException($"No main library presented in {name} module.");

        Assembly mainAssembly = null!;

        foreach (var library in libraries)
        {
            using var assemblyStream = new MemoryStream(library.Assembly);
            var assembly = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);
            if (library.IsMainLibrary)
            {
                mainAssembly = assembly;
            }
        }

        TModuleAbstraction moduleInstance = _moduleEjectorService.GetModule<TModuleAbstraction>(mainAssembly);
        moduleInstance.Metadata = await _moduleEjectorService.GetModuleMetadata(mainAssembly, token);
        moduleInstance.Properties = _moduleEjectorService.GetModuleProperties(mainAssembly, properties);

        return moduleInstance;
    }

    public async Task<IEnumerable<ModuleDefinition>> GetModuleDefinitionsAsync(ModuleTypes moduleType, CancellationToken token = default)
    {
        var moduleRepository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);

        var modules = await moduleRepository.GetByPredicateAsync(m => m.Type == moduleType, token: token);

        return modules.Select(GetModuleDefinition);
    }

    /// <summary>
    /// Creates a new module with the specified name and assembly.
    /// </summary>
    /// <param name="assembly">The assembly data of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task<int> CreateModuleAsync(byte[] mainAssembly, IEnumerable<byte[]> additionalLibraries, ModuleTypes moduleType, CancellationToken token = default)
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);

        var module = new DALModule
        {
            Name = await GetModuleNameAsync(mainAssembly, token),
            Type = moduleType,
        };

        var existedModule = await repository.GetByPredicateFirstAsync(exModule => exModule.Name == module.Name, token);
        if (existedModule is not null)
        {
            await UpdateModuleAsync(existedModule, module, mainAssembly, additionalLibraries, token);

            return existedModule.Id;
        }
        else
        {
            await repository.AddAsync(module, token);
            await _unitOfWork.CommitAsync(token);

            await AddLibrariesToModuleAsync(module, mainAssembly, additionalLibraries, token);

            using var assemblyStream = new MemoryStream(mainAssembly);
            var assemblyObj = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);
            await AddProperties(_moduleEjectorService.GetModulePropertiesType(assemblyObj), module.Id, token);

            var moduleMetadata = await _moduleEjectorService.GetModuleMetadata(assemblyObj, token);

            await AddContentsAsync(module.Id, moduleMetadata.AcceptableContent, ContentTypes.AcceptableContent, token);
            await AddContentsAsync(module.Id, moduleMetadata.ProducedContent, ContentTypes.ProducedContent, token);

            return module.Id;
        }
    }

    /// <summary>
    /// Deletes a module by its name.
    /// </summary>
    /// <typeparam name="DALModule">The type of the module entity.</typeparam>
    /// <param name="name">The name of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task DeleteModuleAsync(string name, CancellationToken token = default)
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);
        var module = await repository.GetByPredicateFirstAsync(m => m.Name == name, token)
            ?? throw new ArgumentException($"Unable to find module {name}.");
        await repository.DeleteAsync(module.Id, token);
        await _unitOfWork.CommitAsync(token);
    }

    /// <summary>
    /// Deletes a module by its ID.
    /// </summary>
    /// <typeparam name="DALModule">The type of the module entity.</typeparam>
    /// <param name="id">The ID of the module.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task DeleteModuleAsync(int id, CancellationToken token = default)
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);
        await repository.DeleteAsync(id, token);
        await _unitOfWork.CommitAsync(token);
    }

    /// <summary>
    /// Updates a module with the specified ID.
    /// </summary>
    /// <typeparam name="DALModule">The type of the module entity.</typeparam>
    /// <param name="moduleId">The Id of the module.</param>
    /// <param name="assembly">The new assembly data of the module. Optional.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task UpdateModuleAsync(int moduleId, byte[] assembly = null!, IEnumerable<byte[]> additionalAssemblies = null!, CancellationToken token = default)
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);
        var libraryRepository = await _unitOfWork.GetRepositoryAsync<BinaryLibrary>(token);

        var module = await repository.GetByIdAsync(moduleId, token)
            ?? throw new ArgumentException($"Unable to find module with id {moduleId}.");

        if (assembly is not null && additionalAssemblies is not null)
        {
            await DeleteLibrariesFromModule(module.Id, token);
            await AddLibrariesToModuleAsync(module, assembly, additionalAssemblies, token);

            module.Name = await GetModuleNameAsync(assembly, token);
            await _unitOfWork.CommitAsync(token);

            await DeleteProperties(module.Id, token);
            using var assemblyStream = new MemoryStream(assembly);
            var assemblyObj = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);
            await AddProperties(_moduleEjectorService.GetModulePropertiesType(assemblyObj), module.Id, token);

            var moduleMetadata = await _moduleEjectorService.GetModuleMetadata(assemblyObj, token);

            await DeleteAssociatedContentAsync(module.Id, token);
            await AddContentsAsync(module.Id, moduleMetadata.AcceptableContent, ContentTypes.AcceptableContent, token);
            await AddContentsAsync(module.Id, moduleMetadata.ProducedContent, ContentTypes.ProducedContent, token);
        }
    }

    /// <summary>
    /// Updates a module with the specified ID.
    /// </summary>
    /// <typeparam name="DALModule">The type of the module entity.</typeparam>
    /// <param name="moduleName">Name of the module.</param>
    /// <param name="assembly">The new assembly data of the module. Optional.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task UpdateModuleAsync(string moduleName, byte[] assembly = null!, IEnumerable<byte[]> additionalAssemblies = null!, CancellationToken token = default)
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);
        var libraryRepository = await _unitOfWork.GetRepositoryAsync<BinaryLibrary>(token);

        var module = await repository.GetByPredicateFirstAsync(m => m.Name == moduleName, token)
            ?? throw new ArgumentException($"Unable to find module {moduleName}.");

        if (assembly is not null)
        {
            await DeleteLibrariesFromModule(module.Id, token);
            await AddLibrariesToModuleAsync(module, assembly, additionalAssemblies, token);

            await UpdateModuleEntityAsync(module, new DALModule
            {
                Name = await GetModuleNameAsync(assembly, token),
            }, token);

            await DeleteProperties(module.Id, token);
            using var assemblyStream = new MemoryStream(assembly);
            var assemblyObj = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);
            await AddProperties(_moduleEjectorService.GetModulePropertiesType(assemblyObj), module.Id, token);

            var moduleMetadata = await _moduleEjectorService.GetModuleMetadata(assemblyObj, token);

            await DeleteAssociatedContentAsync(module.Id, token);
            await AddContentsAsync(module.Id, moduleMetadata.AcceptableContent, ContentTypes.AcceptableContent, token);
            await AddContentsAsync(module.Id, moduleMetadata.ProducedContent, ContentTypes.ProducedContent, token);
        }
    }

    /// <summary>
    /// Updates a module with the specified ID.
    /// </summary>
    /// <typeparam name="DALModule">The type of the module entity.</typeparam>
    /// <param name="module">Module entity.</param>
    /// <param name="assembly">The new assembly data of the module. Optional.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    private async Task UpdateModuleAsync(DALModule existedModule, DALModule newModule, byte[] assembly = null!, IEnumerable<byte[]> additionalAssemblies = null!, CancellationToken token = default)
    {
        var repository = await _unitOfWork.GetRepositoryAsync<DALModule>(token);
        var libraryRepository = await _unitOfWork.GetRepositoryAsync<BinaryLibrary>(token);

        if (existedModule is null)
            return;

        if (assembly is not null)
        {
            await DeleteLibrariesFromModule(existedModule.Id, token);
            await AddLibrariesToModuleAsync(existedModule, assembly, additionalAssemblies, token);

            await UpdateModuleEntityAsync(existedModule, newModule, token);

            await DeleteProperties(existedModule.Id, token);
            using var assemblyStream = new MemoryStream(assembly);
            var assemblyObj = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);
            await AddProperties(_moduleEjectorService.GetModulePropertiesType(assemblyObj), existedModule.Id, token);

            var moduleMetadata = await _moduleEjectorService.GetModuleMetadata(assemblyObj, token);

            await DeleteAssociatedContentAsync(existedModule.Id, token);
            await AddContentsAsync(existedModule.Id, moduleMetadata.AcceptableContent, ContentTypes.AcceptableContent, token);
            await AddContentsAsync(existedModule.Id, moduleMetadata.ProducedContent, ContentTypes.ProducedContent, token);
        }
    }

    private async Task<string> GetModuleNameAsync(byte[] assembly, CancellationToken token)
    {
        using var assemblyStream = new MemoryStream(assembly);
        var assemblyInstance = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);
        var moduleMetadata = await _moduleEjectorService.GetModuleMetadata(assemblyInstance, token);
        return moduleMetadata.Name;
    }

    private async Task<Properties> AddProperties(Type propertiesType, int moduleId, CancellationToken token = default)
    {
        var propertyRepository = await _unitOfWork.GetRepositoryAsync<Properties>(token);

        var properties = new Properties
        {
            ModuleId = moduleId,
        };

        properties.InternalProperties = PropertyHelper.GetProperties(properties, propertiesType);

        await propertyRepository.AddAsync(properties, token);
        await _unitOfWork.CommitAsync(token);
        return properties;
    }

    private async Task DeleteProperties(int moduleId, CancellationToken token = default)
    {
        var propertyRepository = await _unitOfWork.GetRepositoryAsync<Properties>(token);

        var properties = await propertyRepository.GetByPredicateFirstAsync(p => p.ModuleId == moduleId, token);
        if (properties is not null)
        {
            await propertyRepository.DeleteAsync(properties.Id, token);
            await _unitOfWork.CommitAsync(token);
        }
    }

    private async Task<IEnumerable<BinaryLibrary>> AddLibrariesToModuleAsync(DALModule module, byte[] mainAssembly, IEnumerable<byte[]> additionalLibraries, CancellationToken token = default)
    {
        var result = new List<BinaryLibrary>();
        var unloadedLibraries = additionalLibraries.ToList();
        while (unloadedLibraries.Count != 0)
        {
            var tempUnloadedLibraries = new List<byte[]>();
            foreach (var library in unloadedLibraries)
            {
                try
                {
                    result.Add(await AddLibrary(library, module.Id, token: token));
                }
                catch (Exception)
                {
                    continue;
                }
            }

            if (tempUnloadedLibraries.Count == unloadedLibraries.Count)
            {
                throw new InvalidOperationException("Unable to load libraries.");
            }

            unloadedLibraries = tempUnloadedLibraries;
        }

        result.Add(await AddLibrary(mainAssembly, module.Id, true, token));

        await _unitOfWork.CommitAsync(token);

        return result;
    }

    private async Task DeleteLibrariesFromModule(int moduleId, CancellationToken token = default)
    {
        var libraryRepository = await _unitOfWork.GetRepositoryAsync<BinaryLibrary>(token);
        await libraryRepository.DeleteRangeAsync(await libraryRepository.GetByPredicateAsync(library => library.ModuleId == moduleId, token: token));
    }

    private async Task<BinaryLibrary> AddLibrary(byte[] assembly, int moduleId, bool isMainLibrary = false, CancellationToken token = default)
    {
        var libraryRepository = await _unitOfWork.GetRepositoryAsync<BinaryLibrary>(token);

        using var assemblyStream = new MemoryStream(assembly);
        var assemblyInstance = AssemblyLoadContext.Default.LoadFromStream(assemblyStream);

        var library = new BinaryLibrary
        {
            Name = assemblyInstance.FullName ?? string.Empty,
            Assembly = assembly,
            IsMainLibrary = isMainLibrary,
            ModuleId = moduleId,
        };

        await libraryRepository.AddAsync(library, token);
        await _unitOfWork.CommitAsync(token);

        return library;
    }

    private async Task<IEnumerable<Content>> AddContentsAsync(int moduleId, IEnumerable<string> contentNames, ContentTypes contentType, CancellationToken token = default)
    {
        if (contentNames is null)
            return new List<Content>();

        var contents = new List<Content>();
        foreach (var contentName in contentNames)
        {
            var content = await AddContentAsync(moduleId, contentName, contentType, token);
            contents.Add(content);
        }
        return contents;
    }

    private async Task<Content> AddContentAsync(int moduleId, string contentName, ContentTypes contentType, CancellationToken token = default)
    {
        var contentRepository = await _unitOfWork.GetRepositoryAsync<Content>(token);
        var moduleContentRepository = await _unitOfWork.GetRepositoryAsync<ModuleContent>(token);

        var content = await contentRepository.GetByPredicateFirstAsync(c => c.Name == contentName);
        if (content is null)
        {
            content = new Content
            {
                Name = contentName,
            };

            await contentRepository.AddAsync(content, token);
            await _unitOfWork.CommitAsync(token);
        }

        var moduleContent = new ModuleContent
        {
            ModuleId = moduleId,
            ContentId = content.Id,
            Type = contentType,
        };
        await moduleContentRepository.AddAsync(moduleContent, token);
        await _unitOfWork.CommitAsync(token);

        return content;
    }

    private async Task DeleteAssociatedContentAsync(int moduleId, CancellationToken token = default)
    {
        var contentRepository = await _unitOfWork.GetRepositoryAsync<Content>(token);
        var moduleContentRepository = await _unitOfWork.GetRepositoryAsync<ModuleContent>(token);

        var moduleContents = await moduleContentRepository.GetByPredicateAsync(mc => mc.ModuleId == moduleId, token: token);
        await moduleContentRepository.DeleteRangeAsync(moduleContents, token);
        await _unitOfWork.CommitAsync(token);
    }

    private async Task UpdateModuleEntityAsync(DALModule existedModule, DALModule newModule, CancellationToken token = default)
    {
        existedModule.Name = newModule.Name;
        existedModule.Type = newModule.Type;
        await _unitOfWork.CommitAsync(token);
    }

    private ModuleDefinition GetModuleDefinition(DALModule module)
    {
        return new ModuleDefinition
        {
            Name = module.Name,
            AccaptableContents = module.Contents
                .Where(mc => mc.Type == ContentTypes.AcceptableContent)
                .Select(mc => mc.Content.Name),
            ProducedContents = module.Contents
                .Where(mc => mc.Type == ContentTypes.ProducedContent)
                .Select(mc => mc.Content.Name),
            Properties = module.Properties.InternalProperties.Select(MapProperty),
        };
    }

    private PropertyDefinition MapProperty(Property property)
    {
        return new PropertyDefinition
        {
            Name = property.Name,
            Type = property.Type.ToString().Aggregate(new StringBuilder(), (sb, nc) => sb.Length > 0 ? sb.Append(char.IsUpper(nc) ? $"-{char.ToLower(nc)}" : char.ToLower(nc)) : sb.Append(char.ToLower(nc)), sb => sb.ToString()),
            EnumValues = property.Enum?.EnumValues?.Select(ev => ev.Name) ?? [],
            Properties = property.InternalProperties?.Select(MapProperty) ?? [],
        };
    }
}
