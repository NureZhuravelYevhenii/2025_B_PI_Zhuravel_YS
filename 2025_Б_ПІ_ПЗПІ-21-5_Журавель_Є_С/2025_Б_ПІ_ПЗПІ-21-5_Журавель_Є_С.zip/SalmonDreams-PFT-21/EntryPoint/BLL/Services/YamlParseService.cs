﻿using BLL.Abstractions;
using BLL.Entities;
using YamlDotNet.Serialization;

namespace BLL.Services;

public class YamlParseService : IParseService
{
    private readonly IDeserializer _deserializer;

    public YamlParseService(IModuleService moduleService, IDeserializer deserializer)
    {
        _deserializer = deserializer;
    }

    public string MarkupType => "yaml";

    public Task<IEnumerable<SimplifiedModule>> ParseToSimplifiedAsync(string input, CancellationToken token = default)
    {
        return Task.FromResult(_deserializer.Deserialize<IEnumerable<SimplifiedModule>>(input));
    }
}
