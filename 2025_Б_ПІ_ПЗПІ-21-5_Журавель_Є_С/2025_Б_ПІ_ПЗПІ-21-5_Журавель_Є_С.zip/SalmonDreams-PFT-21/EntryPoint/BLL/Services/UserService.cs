﻿using AutoMapper;
using BLL.Abstractions;
using BLL.Abstractions.Helpers;
using BLL.Entities.Users;
using DAL.Abstractions;
using DAL.Entities;
using Domain.Constants;
using System.Linq.Expressions;
using System.Security.Claims;
using System.Security.Cryptography;

public class UserService : IUserService
{
    private readonly IHasher _hasher;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IJwtManager _jwtManager;
    private readonly IMapper _mapper;

    public UserService(
        IHasher hasher,
        IUnitOfWork unitOfWork, 
        IJwtManager jwtManager,
        IMapper mapper)
    {
        _hasher = hasher;
        _unitOfWork = unitOfWork;
        _jwtManager = jwtManager;
        _mapper = mapper;
    }

    public async Task<TokenPair> LoginAsync(UserLogin userLogin, CancellationToken token = default)
    {
        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);
        var user = await userRepository.GetByPredicateFirstAsync(u => u.Login == userLogin.Login, token);

        if (user == null)
            throw new UnauthorizedAccessException("Invalid login.");

        if (!await _hasher.CompareStringWithHashAsync(userLogin.Password, user.PasswordSalt, user.PasswordHash, token))
            throw new UnauthorizedAccessException("Invalid password.");

        return await GenerateTokenPairAsync(user, token);
    }

    public async Task<TokenPair> RegisterAsync(UserCreationDto userDto, CancellationToken token = default)
    {
        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);

        var user = _mapper.Map<User>(userDto);

        (string hash, string salt) = await _hasher.HashAsync(userDto.Password, token);
        user.PasswordSalt = salt;
        user.PasswordHash = hash;

        try
        {
            await userRepository.AddAsync(user, token);
            await _unitOfWork.CommitAsync(token);

            return await GenerateTokenPairAsync(user, token);
        }
        catch
        {
            throw new ArgumentException($"Unable to create user with {userDto.Login} login and {userDto.Email}.");
        }
    }

    public async Task<TokenPair> RefreshTokenAsync(string refreshToken, CancellationToken token = default)
    {
        var claims = await _jwtManager.DecodeTokenAsync(refreshToken, token);
        var userIdClaim = claims.FirstOrDefault(c => c.Type == JwtTypeConstants.Id);
        if (userIdClaim is null)
            throw new UnauthorizedAccessException("Invalid refresh token.");

        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);
        var user = await userRepository.GetByIdAsync(int.Parse(userIdClaim.Value), token);

        if (user == null || user.RefreshToken != refreshToken)
        {
            throw new UnauthorizedAccessException("Invalid refresh token.");
        }

        return await GenerateTokenPairAsync(user, token);
    }

    public async Task<UserDto?> GetUserAsync(Expression<Func<User, bool>> predicate, CancellationToken token = default)
    {
        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);
        var user = await userRepository.GetByPredicateFirstAsync(predicate, token);

        if (user is null)
            throw new ArgumentException($"There is no user with this condition.");

        return _mapper.Map<UserDto>(user);
    }

    public async Task<UserDto?> GetUserAsync(int id, CancellationToken token = default)
    {
        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);
        var user = await userRepository.GetByIdAsync(id, token);

        if (user is null)
            throw new ArgumentException($"There is no user with this {id} id.");

        return _mapper.Map<UserDto>(user);
    }

    public async Task DeleteAsync(int id, CancellationToken token = default)
    {
        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);
        await userRepository.DeleteAsync(id, token);
        await _unitOfWork.CommitAsync(token);
    }

    public async Task UpdateAsync(UserUpdateDto updatedUserDto, CancellationToken token = default)
    {
        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);

        var user = _mapper.Map<User>(updatedUserDto);

        if (!string.IsNullOrEmpty(updatedUserDto.Password))
        {
            var (passwordHash, salt) = await _hasher.HashAsync(updatedUserDto.Password, token);
            user.PasswordHash = passwordHash;
            user.PasswordSalt = salt;
        }

        await userRepository.UpdateAsync(user, token);
        await _unitOfWork.CommitAsync(token);
    }

    private async Task<TokenPair> GenerateTokenPairAsync(User user, CancellationToken token)
    {
        var accessToken = await _jwtManager.GetJwtTokenAsync(GetClaimsForAccessToken(user), token);
        var refreshToken = await _jwtManager.GetJwtTokenAsync(GetClaimsForRefreshToken(user), token);
        user.RefreshToken = refreshToken;

        var userRepository = await _unitOfWork.GetRepositoryAsync<User>(token);
        await userRepository.UpdateAsync(user, token);
        await _unitOfWork.CommitAsync(token);

        return new TokenPair
        {
            AccessToken = accessToken,
            RefreshToken = refreshToken
        };
    }

    private IEnumerable<Claim> GetClaimsForAccessToken(User user) => [
        new Claim(JwtTypeConstants.Id, user.Id.ToString())
        ];

    private IEnumerable<Claim> GetClaimsForRefreshToken(User user) => [
        new Claim(JwtTypeConstants.Id, user.Id.ToString()),
        new Claim(JwtTypeConstants.Nonce, GenerateRandomString())
        ];

    private string GenerateRandomString()
    {
        var randomBytes = new byte[128];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomBytes);
        return Convert.ToBase64String(randomBytes);
    }
}
