﻿using BLL.Abstractions.Helpers;
using System.Security.Cryptography;

public class Hasher : IHasher
{
    private const int SaltSize = 16;
    private const int KeySize = 32;
    private const int Iterations = 10000;

    public Task<(string Hash, string Salt)> HashAsync(string input, CancellationToken token = default)
    {
        using (var rng = RandomNumberGenerator.Create())
        {
            var saltBytes = new byte[SaltSize];
            rng.GetBytes(saltBytes);
            var salt = Convert.ToBase64String(saltBytes);

            var hash = ComputeHash(input, saltBytes, token);
            return Task.FromResult((hash, salt));
        }
    }

    public Task<bool> CompareStringWithHashAsync(string input, string salt, string hash, CancellationToken token = default)
    {
        var saltBytes = Convert.FromBase64String(salt);
        var computedHash = ComputeHash(input, saltBytes, token);

        return Task.FromResult(computedHash == hash);
    }

    private string ComputeHash(string input, byte[] saltBytes, CancellationToken token)
    {
        using (var deriveBytes = new Rfc2898DeriveBytes(input, saltBytes, Iterations, HashAlgorithmName.SHA256))
        {
            var key = deriveBytes.GetBytes(KeySize);
            return Convert.ToBase64String(key);
        }
    }
}
