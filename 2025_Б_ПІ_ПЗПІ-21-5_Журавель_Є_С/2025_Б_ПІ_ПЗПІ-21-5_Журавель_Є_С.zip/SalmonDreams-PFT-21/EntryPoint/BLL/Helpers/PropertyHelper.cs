﻿using AutoMapper.Internal;
using BLL.Helpersp;
using DAL.Entities;
using Domain.Enums;

namespace BLL.Helpers;

public static class PropertyHelper
{
    private static readonly IDictionary<Type, Types> _predefinedTypes = new Dictionary<Type, Types>
    {
        { typeof(string), Types.String },
        { typeof(char), Types.Number },
        { typeof(byte), Types.Number },
        { typeof(int), Types.Number },
        { typeof(long), Types.Number },
        { typeof(decimal), Types.Number },
        { typeof(float), Types.Number },
        { typeof(double), Types.Number },
        { typeof(bool), Types.Boolean },
        { typeof(DateTime), Types.Date },
        { typeof(IEnumerable<string>), Types.StringArray },
        { typeof(IEnumerable<char>), Types.NumberArray },
        { typeof(IEnumerable<byte>), Types.NumberArray },
        { typeof(IEnumerable<int>), Types.NumberArray },
        { typeof(IEnumerable<long>), Types.NumberArray },
        { typeof(IEnumerable<decimal>), Types.NumberArray },
        { typeof(IEnumerable<float>), Types.NumberArray },
        { typeof(IEnumerable<double>), Types.NumberArray },
        { typeof(IEnumerable<bool>), Types.BooleanArray },
        { typeof(IEnumerable<DateTime>), Types.DateArray }
    };

    public static IEnumerable<Property> GetProperties(Properties properties, Type propertiesType, Property parentProperty = null!)
    {
        return propertiesType.GetProperties()
            .Where(prop => prop.IsPublic() && prop.CanWrite)
            .Select(prop => 
            {
                var propertyType = Types.Object;
            
                var typeDefined = _predefinedTypes.Any(kv => prop.PropertyType.IsAssignableTo(kv.Key));
                if (typeDefined)
                    propertyType = _predefinedTypes.First(kv => prop.PropertyType.IsAssignableTo(kv.Key)).Value;
                else if (prop.PropertyType.IsEnum)
                    propertyType = Types.Enum;
                else if (TypeHelper.IsEnumerable(prop.PropertyType) && TypeHelper.IsEnumerableTypeMeetsConditions(prop.PropertyType, type => type.IsEnum))
                    propertyType = Types.EnumArray;

                var property = new Property
                {
                    Name = prop.Name,
                    ParentProperty = parentProperty,
                    Properties = properties,
                    Type = propertyType,
                    Enum = propertyType == Types.Enum || propertyType == Types.EnumArray ? new DAL.Entities.Enum
                    {
                        Name = prop.PropertyType.Name,
                        EnumValues = System.Enum.GetNames(prop.PropertyType).Select(name => new EnumValue
                        {
                            Name = name
                        }).ToList(),
                    }
                    : null
                };

                var internalProperties = typeDefined ? new List<Property>() : GetProperties(properties, prop.PropertyType, property);
                property.InternalProperties = internalProperties;

                return property;
            })
            .ToList();
    }
}