﻿using BLL.Abstractions.Helpers;
using Domain.Configurations;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BLL.Helpers;

public class JwtManager : IJwtManager
{
    private readonly JwtConfiguration _jwtConfiguration;

    public JwtManager(IOptions<JwtConfiguration> jwtConfigurationOptions)
    {
        _jwtConfiguration = jwtConfigurationOptions.Value 
            ?? throw new ArgumentException(nameof(jwtConfigurationOptions));
    }

    public Task<IEnumerable<Claim>> DecodeTokenAsync(string jwtToken, CancellationToken token = default)
    {
        var tokenHandler = new JwtSecurityTokenHandler();

        var tokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = _jwtConfiguration.ValidateIssuer,
            ValidateLifetime = _jwtConfiguration.ValidateLifetime,
            ValidateAudience = _jwtConfiguration.ValidateAudience,
            ValidateIssuerSigningKey = _jwtConfiguration.ValidateSecretKey,

            ValidIssuer = _jwtConfiguration.Issuer,
            ValidAudience = _jwtConfiguration.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtConfiguration.SecretKey)),
        };

        try
        {
            var principal = tokenHandler.ValidateToken(jwtToken, tokenValidationParameters, out var validatedToken);
            return Task.FromResult(principal.Claims);
        }
        catch
        {
            return Task.FromResult(new List<Claim>().AsEnumerable());
        }
    }

    public Task<string> GetJwtTokenAsync(IEnumerable<Claim> claims, CancellationToken token = default)
    {
        SigningCredentials? signingCredentials = null;
        if(_jwtConfiguration.ValidateSecretKey)
            signingCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtConfiguration.SecretKey)), SecurityAlgorithms.HmacSha256);

        DateTime? expires = null;
        if (_jwtConfiguration.ValidateLifetime)
            expires = DateTime.Now.AddMinutes(_jwtConfiguration.LifetimeInMinutes);

        string? issuer = null;
        if (_jwtConfiguration.ValidateIssuer)
            issuer = _jwtConfiguration.Issuer;

        string? audience = null;
        if (_jwtConfiguration.ValidateAudience)
            audience = _jwtConfiguration.Audience;

        var jwtToken = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(30),
            signingCredentials: signingCredentials
        );

        return Task.FromResult(new JwtSecurityTokenHandler().WriteToken(jwtToken));
    }
}
