﻿using System.Collections;

namespace BLL.Helpersp;

public static class TypeHelper
{
    /// <summary>
    /// Determines whether the specified type is a dictionary.
    /// </summary>
    /// <param name="type">The type to check.</param>
    /// <returns><c>true</c> if the specified type is a dictionary; otherwise, <c>false</c>.</returns>
    public static bool IsDictionary(Type type) =>
        type.IsConstructedGenericType &&
        type.GetGenericArguments().Length == 2 &&
        type.IsAssignableTo(typeof(IDictionary<,>).MakeGenericType(type.GetGenericArguments()));

    /// <summary>
    /// Determines whether the specified type is a enumerable.
    /// </summary>
    /// <param name="type">The type to check.</param>
    /// <returns><c>true</c> if the specified type is a enumerable; otherwise, <c>false</c>.</returns>
    public static bool IsEnumerable(Type type) =>
        type.IsConstructedGenericType &&
        type.GetGenericArguments().Length == 1 &&
        type.IsAssignableTo(typeof(IEnumerable<>).MakeGenericType(type.GetGenericArguments()))
        ||
        type.IsAssignableTo(typeof(IEnumerable));

    public static bool IsEnumerableTypeMeetsConditions(Type enumerableType, Func<Type, bool> predicate) =>
        predicate(enumerableType.GetGenericArguments().First());

}
