﻿using Adapters.Abstractions;
using Adapters.Entities.Parameters;
using BLL.Abstractions;
using MainAbstractions.Builders;

namespace Adapters;

public class ProjectGenerationFacade : IProjectGenerationFacade
{
    private readonly IEnumerable<IParseService> _parseServices;
    private readonly IEnumerable<IContentBuilder> _contentBuilders;

    private IDictionary<string, IParseService> _parseServicesWithType;
    private IDictionary<string, IContentBuilder> _contentBuildersWithType;

    private readonly IProjectGenerationService _projectGenerationService;

    public ProjectGenerationFacade(IEnumerable<IParseService> parseServices, IEnumerable<IContentBuilder> contentBuilders, IProjectGenerationService projectGenerationService)
    {
        _parseServices = parseServices;
        _contentBuilders = contentBuilders;

        _parseServicesWithType = _parseServices.ToDictionary(parseService => parseService.MarkupType);
        _contentBuildersWithType = _contentBuilders.ToDictionary(contentBuilder => contentBuilder.ContentBuilderType);

        _projectGenerationService = projectGenerationService;
    }

    public async Task<(Stream?, string)> GenerateProjectArchiveAsync(ProjectGenerationFacadeParameters parameters, CancellationToken token = default)
    {
        var parseService = GetParseService(parameters.MarkupType);
        var archiveContentBuilder = GetContentBuilder(parameters.ContentBuilder);

        var simplifiedModules = await parseService.ParseToSimplifiedAsync(parameters.Input, token);
        var contents = await _projectGenerationService.GenerateProjectAsync(simplifiedModules, token);
        return (await archiveContentBuilder.ParseInCodeAsync(contents, token), archiveContentBuilder.ContentType);
    }

    private IParseService GetParseService(string markupType)
    {
        return _parseServicesWithType.TryGetValue(markupType.ToLower(), out IParseService? parseService) 
            ? parseService
            : throw new ArgumentException($"Unable to process {markupType} markup type.");
    }

    private IContentBuilder GetContentBuilder(string contentBuilder)
    {
        return _contentBuildersWithType.TryGetValue(contentBuilder.ToLower(), out IContentBuilder? contentBuilderObj)
            ? contentBuilderObj
            : throw new ArgumentException($"Unable to process {contentBuilder} content builder.");
    }
}
