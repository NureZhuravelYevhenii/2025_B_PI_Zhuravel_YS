﻿using AutoMapper;
using BLL.Entities.Users;
using DAL.Entities;

namespace BLL.Mapper;

public class GeneralProfile : Profile
{
	public GeneralProfile()
    {
        CreateMap<User, UserCreationDto>().ReverseMap();
        CreateMap<User, UserDto>().ReverseMap();
        CreateMap<User, UserLogin>().ReverseMap();
        CreateMap<User, UserUpdateDto>().ReverseMap();
    }
}
