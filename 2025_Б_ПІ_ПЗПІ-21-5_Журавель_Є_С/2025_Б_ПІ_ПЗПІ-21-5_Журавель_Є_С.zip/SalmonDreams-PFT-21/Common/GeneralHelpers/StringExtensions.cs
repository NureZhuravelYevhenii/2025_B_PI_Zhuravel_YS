﻿using System.Text.RegularExpressions;

namespace GeneralHelpers;

/// <summary>
/// Provides extension methods for string manipulation.
/// </summary>
public static class StringExtensions
{
    private const string ENTITY_PLACEHOLDER = "Entity";

    /// <summary>
    /// Shifts each line of the input string by a specified number of spaces for indentation.
    /// </summary>
    public static string ShiftEachLineWithIndentation(this string input, int indent = 4)
    {
        if (input is null)
            return string.Empty;

        var indentation = new string(' ', indent);
        return indentation + input.Replace(Environment.NewLine, Environment.NewLine + indentation);
    }

    /// <summary>
    /// Replaces the entity occurences in the string with appropriate entity type.
    /// </summary>
    /// <param name="source">A string that should be modified.</param>
    /// <param name="newEntityName">The entity type name.</param>

    public static string ReplaceEntity(this string source, string newEntityName)
    {
        if (source is null)
            throw new ArgumentNullException(nameof(source));

        return source.Replace(ENTITY_PLACEHOLDER, newEntityName, StringComparison.Ordinal);
    }

    /// <summary>
    /// Replaces multiple consecutive whitespace characters in a string with a single underscore.
    /// Removes all leading whitespaces but preserves trailing underscores if necessary.
    /// </summary>
    /// <param name="input">The input string to process.</param>
    /// <returns>A formatted string with single underscores replacing multiple spaces.</returns>
    public static string ReplaceMultipleSpaces(this string input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        return Regex.Replace(input.Trim(), @"\s+", "_");
    }
}
