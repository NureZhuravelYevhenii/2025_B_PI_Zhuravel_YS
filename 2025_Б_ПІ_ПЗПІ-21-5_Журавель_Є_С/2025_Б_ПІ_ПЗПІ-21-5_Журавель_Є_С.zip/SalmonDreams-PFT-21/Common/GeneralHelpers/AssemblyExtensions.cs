﻿using Microsoft.Extensions.Caching.Memory;
using System.Reflection;

namespace GeneralHelpers;

/// <summary>
/// Provides extension methods for the <see cref="Assembly"/> class.
/// </summary>
public static class AssemblyExtensions
{
    private static readonly IMemoryCache _cache = ServiceProviderFactory.GetService<IMemoryCache>();

    private static readonly MemoryCacheEntryOptions _cacheOptions = new MemoryCacheEntryOptions
    {
        SlidingExpiration = TimeSpan.FromMinutes(5),
        AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(10)
    };

    /// <summary>
    /// Asynchronously retrieves a resource from the specified assembly. 
    /// Caches the resource content for quick subsequent access.
    /// </summary>
    /// <param name="assembly">The assembly containing the resource.</param>
    /// <param name="resourceName">The name of the resource to retrieve.</param>
    public static async Task<string> GetResource(this Assembly assembly, string resourceName)
    {
        var cacheKey = $"{assembly.FullName}:{resourceName}";
        if (_cache.TryGetValue(cacheKey, out string? cachedResource) && cachedResource is not null)
            return cachedResource;

        var fullResourceName = assembly.GetManifestResourceNames().FirstOrDefault(name => name.EndsWith($".{resourceName}", StringComparison.Ordinal))
            ?? throw new InvalidOperationException($"Unable to load resource with name {resourceName}.");

        var resource = assembly.GetManifestResourceStream(fullResourceName)
            ?? throw new InvalidOperationException($"Unable to stream resource with name {resourceName}.");

        using var reader = new StreamReader(resource);
        var resourceContent = await reader.ReadToEndAsync();

        _cache.Set(cacheKey, resourceContent, _cacheOptions);

        return resourceContent;
    }
}
