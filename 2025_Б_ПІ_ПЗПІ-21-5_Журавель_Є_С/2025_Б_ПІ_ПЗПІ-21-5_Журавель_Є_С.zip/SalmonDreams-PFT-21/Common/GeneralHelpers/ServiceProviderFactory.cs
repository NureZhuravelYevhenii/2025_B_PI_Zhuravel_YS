﻿using Microsoft.Extensions.DependencyInjection;

namespace GeneralHelpers;

/// <summary>
/// A static factory for accessing services in scenarios where dependency injection is not available.
/// Services are registered and resolved from a singleton <see cref="IServiceProvider"/>.
/// </summary>
public static class ServiceProviderFactory
{
    private static readonly Lazy<IServiceProvider> _serviceProvider = new(() =>
    {
        var services = new ServiceCollection();
        RegisterServices(services);

        return services.BuildServiceProvider();
    });

    /// <summary>
    /// Registers services with the provided <see cref="IServiceCollection"/>.
    /// This method can be extended to register additional services as needed.
    /// </summary>
    /// <param name="services">The service collection to register services.</param>
    private static void RegisterServices(IServiceCollection services)
    {
        services.AddMemoryCache();
    }

    /// <summary>
    /// Resolves a service of type <typeparamref name="T"/> from the singleton ServiceProvider instance.
    /// </summary>
    /// <typeparam name="T">The type of the service to resolve. Must be a class or interface.</typeparam>
    /// <returns>An instance of the requested service.</returns>
    /// <exception cref="InvalidOperationException">Thrown if the service is not registered.</exception>
    public static T GetService<T>() where T : class
    {
        return _serviceProvider.Value.GetRequiredService<T>();
    }
}
