﻿using Property;

namespace PropertySubModuleHelpers;

/// <summary>
/// Provides extension methods for <see cref="PropertyType">.
/// </summary>
public static class PropertyTypeExtensions
{
    /// <summary>
    /// Retrieves the C# type associated for a specified <see cref="PropertyType">.
    /// </summary>
    public static Type? GetTypeFromPropertyType(this PropertyType propertyType) => propertyType switch
    {
        PropertyType.String => typeof(string),
        PropertyType.Long => typeof(long),
        PropertyType.Bool => typeof(bool),
        PropertyType.DateTime => typeof(DateTime),
        PropertyType.Decimal => typeof(decimal),
        PropertyType.Int => typeof(int),
        _ => null,
    };
}
