﻿using Relation;

/// <summary>
/// Provides functionality to detect loops in a directed graph represented by entity relationships.
/// </summary>
public static class RelationLoopDetector
{
    /// <summary>
    /// Determines whether the given list of relationships contains a loop.
    /// </summary>
    /// <param name="relations">List of entity relationships.</param>
    /// <returns>True if a cycle exists; otherwise, false.</returns>
    public static bool HasLoop(IEnumerable<RelationContent> relations)
    {
        var graph = BuildGraph(relations);
        var visited = new HashSet<string>();
        var recStack = new HashSet<string>();

        return graph.Keys.Any(node => DetectCycle(node, graph, visited, recStack));
    }

    /// <summary>
    /// Recursively detects a cycle in the graph using Depth-First Search (DFS).
    /// </summary>
    private static bool DetectCycle(
        string node,
        Dictionary<string, HashSet<string>> graph,
        HashSet<string> visited,
        HashSet<string> recStack)
    {
        if (!visited.Add(node))
            return recStack.Contains(node);

        recStack.Add(node);

        if (graph.TryGetValue(node, out var neighbors))
        {
            if (neighbors.Any(neighbor => DetectCycle(neighbor, graph, visited, recStack)))
                return true;
        }

        recStack.Remove(node);
        return false;
    }

    /// <summary>
    /// Builds the adjacency list representation of the graph from entity relationships.
    /// </summary>
    private static Dictionary<string, HashSet<string>> BuildGraph(IEnumerable<RelationContent> relations)
    {
        var graph = new Dictionary<string, HashSet<string>>(StringComparer.Ordinal);

        foreach (var relation in relations)
        {
            if (!graph.TryGetValue(relation.BaseEntity, out var neighbors))
                graph[relation.BaseEntity] = neighbors = new HashSet<string>();

            neighbors.Add(relation.SecondaryEntity);
        }

        return graph;
    }
}
