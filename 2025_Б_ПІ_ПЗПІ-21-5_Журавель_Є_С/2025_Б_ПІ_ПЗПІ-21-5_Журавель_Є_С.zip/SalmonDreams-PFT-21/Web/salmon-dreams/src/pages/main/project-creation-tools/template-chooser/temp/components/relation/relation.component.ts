import { Component } from '@angular/core';
import { Relation } from '../../models/relation';
import { RelationTypes } from '../../models/relation-types';
import { EntityWithId } from '../../models/entity-with-id';
import { EnumComponent } from '../../../../../../../shared/inputs/enum-input/enum-input.component';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { ButtonModule } from 'primeng/button';

const invalidEntityId = 0;

@Component({
  selector: 'app-relation',
  imports: [EnumComponent, ButtonModule],
  templateUrl: './relation.component.html',
  styleUrl: './relation.component.scss',
})
export class RelationComponent {
  onRelationChanged: (relation: Relation) => void;
  providedEntities: { [id: number]: EntityWithId };

  providedEntitiesAsNameDictionary: { [name: string]: EntityWithId[] } = {};
  providedEntityNamesAsArray: string[] = [];

  relationTypesAsStringArray: string[] = Object.keys(RelationTypes);

  relation: Relation;

  secondaryEntityName = '';
  primaryEntityName = '';

  constructor(config: DynamicDialogConfig, private ref: DynamicDialogRef) {
    const mappedConfig = config.data as {
      onRelationChanged: (relation: Relation) => void;
      relation: Relation;
      providedEntities: { [id: number]: EntityWithId };
    };

    this.onRelationChanged = mappedConfig.onRelationChanged;
    this.providedEntities = mappedConfig.providedEntities;
    this.relation = mappedConfig.relation;

    const providedEntitiesAsArray = Object.values(this.providedEntities);
    for (let providedEntity of providedEntitiesAsArray) {
      let entities: EntityWithId[] = [];
      if (this.providedEntitiesAsNameDictionary[providedEntity.name]) {
        entities = this.providedEntitiesAsNameDictionary[providedEntity.name];
      } else {
        this.providedEntitiesAsNameDictionary[providedEntity.name] = entities;
      }
      entities.push(providedEntity);
    }

    this.providedEntityNamesAsArray = providedEntitiesAsArray.map(
      (entity) => entity.name
    );

    this.relation.primaryEntityId = this.relation.primaryEntityId;
    this.primaryEntityName = this.findEntityName(this.relation.primaryEntityId);
    this.relation.secondaryEntityId = this.relation.secondaryEntityId;
    this.secondaryEntityName = this.findEntityName(
      this.relation.secondaryEntityId
    );
    this.relation.relationType = this.relation.relationType;
  }

  changeSecondaryEntity(entityName: string) {
    this.relation.secondaryEntityId = this.findEntityId(entityName);
    this.secondaryEntityName = entityName;
    this.onRelationChanged(this.relation);
  }

  changePrimaryEntity(entityName: string) {
    this.relation.primaryEntityId = this.findEntityId(entityName);
    this.primaryEntityName = entityName;
    this.onRelationChanged(this.relation);
  }

  changeRelationType(relationType: string) {
    this.relation.relationType =
      RelationTypes[relationType as keyof typeof RelationTypes];
    this.onRelationChanged(this.relation);
  }

  findEntityId(entityName: string) {
    const providedEntities = this.providedEntitiesAsNameDictionary[entityName];
    if (providedEntities && providedEntities.length) {
      return providedEntities[0].id;
    }
    return invalidEntityId;
  }

  findEntityName(entityId: number) {
    return entityId ? this.providedEntities[entityId].name : '';
  }

  close() {
    this.ref.close();
  }
}
