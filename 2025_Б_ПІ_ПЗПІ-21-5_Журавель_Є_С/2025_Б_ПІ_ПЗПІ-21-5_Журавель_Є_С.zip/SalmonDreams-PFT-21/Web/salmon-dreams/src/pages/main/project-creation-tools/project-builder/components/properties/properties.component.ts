import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { Property } from '../../../../../../models/modules/property';
import { PropertyComponent } from './components/property/property.component';
import { ButtonModule } from 'primeng/button';

@Component({
    selector: 'app-properties',
    imports: [PropertyComponent, ButtonModule],
    templateUrl: './properties.component.html',
    styleUrl: './properties.component.scss'
})
export class PropertiesComponent implements OnInit, OnChanges {
  propertiesWithValues: { [name: string]: any } = {};
  showProperties = false;

  providedPropertiesWithValues = input<{ [name: string]: any }>();
  properties = input<Property[]>();
  propertiesChanged = output<any>();

  showPropertiesClasses = ['properties'];
  unshowPropertiesClasses = ['hidden'];

  handleShowPropertiesClick() {
    this.showProperties = !this.showProperties;
  }

  changeValueHandler(name: string, value: any) {
    this.propertiesWithValues[name] = value;
    this.propertiesChanged.emit(this.propertiesWithValues);
  }

  seedValues() {
    const properties = this.properties();
    const propertiesWithValuesTemp = this.providedPropertiesWithValues();
    if (!propertiesWithValuesTemp && properties) {
      for (let property of properties) {
        this.propertiesWithValues[property.name] = undefined;
      }
    } else {
      this.propertiesWithValues = propertiesWithValuesTemp!;
    }
  }

  ngOnInit(): void {
    this.seedValues();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedPropertiesWithValues']) {
      this.seedValues();
    }
  }
}
