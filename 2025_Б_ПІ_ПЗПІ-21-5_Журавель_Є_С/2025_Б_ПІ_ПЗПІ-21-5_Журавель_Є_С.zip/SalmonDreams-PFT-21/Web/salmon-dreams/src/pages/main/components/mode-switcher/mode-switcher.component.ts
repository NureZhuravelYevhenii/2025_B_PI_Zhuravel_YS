import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ButtonModule } from 'primeng/button';

@Component({
    selector: 'app-mode-switcher',
    imports: [ButtonModule, RouterModule],
    templateUrl: './mode-switcher.component.html',
    styleUrl: './mode-switcher.component.scss'
})
export class ModeSwitcherComponent {

}
