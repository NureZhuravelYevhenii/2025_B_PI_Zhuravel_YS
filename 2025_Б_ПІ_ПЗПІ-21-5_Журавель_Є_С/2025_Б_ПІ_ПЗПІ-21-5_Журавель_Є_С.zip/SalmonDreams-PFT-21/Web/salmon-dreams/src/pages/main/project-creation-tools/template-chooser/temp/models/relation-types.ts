export enum RelationTypes {
  ManyToMany = 'ManyToMany',
  OneToMany = 'OneToMany',
  OneToOne = 'OneToOne',
}
