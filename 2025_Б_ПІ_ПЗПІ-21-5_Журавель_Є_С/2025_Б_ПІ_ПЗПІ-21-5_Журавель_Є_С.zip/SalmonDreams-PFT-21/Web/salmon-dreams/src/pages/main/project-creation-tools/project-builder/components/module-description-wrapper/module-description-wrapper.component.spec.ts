import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModuleDescriptionWrapperComponent } from './module-description-wrapper.component';

describe('ModuleDescriptionWrapperComponent', () => {
  let component: ModuleDescriptionWrapperComponent;
  let fixture: ComponentFixture<ModuleDescriptionWrapperComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModuleDescriptionWrapperComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModuleDescriptionWrapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
