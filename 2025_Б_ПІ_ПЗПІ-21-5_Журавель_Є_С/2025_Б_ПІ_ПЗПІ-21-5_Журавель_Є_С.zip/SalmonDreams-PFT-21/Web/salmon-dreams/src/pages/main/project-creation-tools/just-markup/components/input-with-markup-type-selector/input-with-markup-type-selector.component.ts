import { NgStyle } from '@angular/common';
import { Component, input, output } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { TextAreaComponent } from '../../../../../../shared/text-area/text-area.component';
import { allowedMarkupTypes } from '../../../../../../constants/allowed-markup-types';

@Component({
    selector: 'input-with-markup-type-selector',
    imports: [ReactiveFormsModule, NgStyle, DropdownModule, TextAreaComponent],
    templateUrl: './input-with-markup-type-selector.component.html',
    styleUrl: './input-with-markup-type-selector.component.scss'
})
export class InputWithMarkupTypeSelectorComponent {
  stylesDict = input<{ [key: string]: string }>();
  customClass = input<string>();
  change = output<Event>();
  changeMarkupType = output<string>();
  markupTypes = allowedMarkupTypes;
}
