import { Component, input, OnDestroy, output } from '@angular/core';
import { EntityWithId } from '../../models/entity-with-id';
import { Entity } from '../../models/entity';
import { ButtonModule } from 'primeng/button';
import {
  DialogService,
  DynamicDialogModule,
  DynamicDialogRef,
} from 'primeng/dynamicdialog';
import { EntityComponent } from '../entity/entity.component';

@Component({
  selector: 'app-entities',
  imports: [ButtonModule, DynamicDialogModule],
  templateUrl: './entities.component.html',
  styleUrl: './entities.component.scss',
  providers: [DialogService],
})
export class EntitiesComponent implements OnDestroy {
  dialogRef: DynamicDialogRef | undefined;

  onEntitiesChanged = output<{ [id: number]: EntityWithId }>();

  isAuthorizationEnabled = input<boolean>(false);

  entitiesCounter = 0;
  entities: { [id: number]: EntityWithId } = {};
  entitiesAsArray: EntityWithId[] = [];

  selectedEntity?: EntityWithId;

  constructor(private dialogService: DialogService) {}

  addEntity() {
    const id = ++this.entitiesCounter;

    const newEntity: EntityWithId = {
      name: '',
      properties: [],
      id,
      isIdentityEntity: false,
    };

    this.entities[id] = newEntity;
    this.entitiesAsArray = Object.values(this.entities);

    this.selectEntity(id);
    this.onEntitiesChanged.emit(this.entities);
  }

  removeEntity(id: number) {
    delete this.entities[id];
    this.entitiesAsArray = Object.values(this.entities);
    this.onEntitiesChanged.emit(this.entities);
  }

  selectEntity(id: number) {
    this.selectedEntity = this.entities[id];
    this.dialogRef = this.dialogService.open(EntityComponent, {
      header: 'Entity',
      data: {
        onEntityChanged: this.entityChanged.bind(this),
        entity: this.selectedEntity,
        isAuthorizationEnabled: this.isAuthorizationEnabled,
      },
    });
  }

  unselectEntity() {
    this.selectedEntity = undefined;
    if (this.dialogRef) {
      this.dialogRef.close();
    }
  }

  entityChanged(entity: Entity) {
    if (this.selectedEntity) {
      this.selectedEntity.name = entity.name;
      this.selectedEntity.properties = entity.properties;
      this.selectedEntity.isIdentityEntity = entity.isIdentityEntity;
      this.onEntitiesChanged.emit(this.entities);
    }
  }

  ngOnDestroy(): void {
    this.dialogRef?.close();
  }
}
