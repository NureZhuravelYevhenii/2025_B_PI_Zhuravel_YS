import { Component, input, OnInit, output } from '@angular/core';
import { ColorService } from '../../../../../../services/color/color.service';
import { ModuleWithId } from '../../../../../../models/modules/module-id';

@Component({
    selector: 'app-module',
    imports: [],
    templateUrl: './module.component.html',
    styleUrl: './module.component.scss'
})
export class ModuleComponent implements OnInit {
  module = input.required<ModuleWithId>();

  moduleSelected = output<ModuleWithId>();

  backgroundColor: string = '';
  borderColor: string = '';

  constructor(private colorService: ColorService) {}

  ngOnInit(): void {
    const colorPalette = this.colorService.getColorPalette(this.module()?.name);
    this.backgroundColor = colorPalette.background;
    this.borderColor = colorPalette.border;
  }
}
