import { Component, OnDestroy, OnInit, output } from '@angular/core';
import { ModulePresenterComponent } from '../module-presenter/module-presenter.component';
import { ButtonModule } from 'primeng/button';
import { MarkupService } from '../../../../../../services/markup/markup.service';
import { ModuleWithId } from '../../../../../../models/modules/module-id';
import { PropertiesComponent } from '../properties/properties.component';

@Component({
    selector: 'app-module-description-wrapper',
    imports: [ModulePresenterComponent, ButtonModule, PropertiesComponent],
    templateUrl: './module-description-wrapper.component.html',
    styleUrl: './module-description-wrapper.component.scss'
})
export class ModuleDescriptionWrapperComponent implements OnInit, OnDestroy {
  module?: ModuleWithId;

  contentExistanceFlag = output<boolean>();

  constructor(private markupService: MarkupService) {}

  switchModuleHandler(module: ModuleWithId) {
    this.module = module;
  }

  goBackHandler() {
    if (this.module) {
      this.module = this.markupService.getParentModule(this.module.id);
    }
  }

  deleteHandler() {
    if (this.module) {
      const oldId = this.module.id;
      this.module = this.markupService.getParentModule(this.module.id);
      this.markupService.deleteModule(oldId);
    }
  }

  propertiesChangedHandler(properties: any) {
    if (this.module) {
      this.markupService.setProperties(this.module.id, properties);
    }
  }

  getProperties() {
    if (this.module) {
      return this.markupService.getProperties(this.module.id);
    }
    return {};
  }

  ngOnInit(): void {
    this.markupService.readyToGenerateFlagChangedEvent.push((newFlag) =>
      this.contentExistanceFlag.emit(newFlag)
    );
  }

  ngOnDestroy(): void {
    this.markupService.clean();
  }
}
