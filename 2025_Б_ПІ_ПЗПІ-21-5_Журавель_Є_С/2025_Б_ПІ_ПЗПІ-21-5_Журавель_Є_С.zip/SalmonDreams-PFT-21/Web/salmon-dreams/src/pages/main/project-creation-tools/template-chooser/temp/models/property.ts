import { PropertyTypes } from './property-types';

export interface Property {
  name: string;
  type: PropertyTypes;
}
