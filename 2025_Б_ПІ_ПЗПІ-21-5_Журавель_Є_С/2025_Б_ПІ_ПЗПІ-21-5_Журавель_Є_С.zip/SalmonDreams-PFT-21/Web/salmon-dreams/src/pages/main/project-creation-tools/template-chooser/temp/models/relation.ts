export interface Relation{
    primaryEntityId: number;
    secondaryEntityId: number;
    relationType: string;
}