import {
  Component,
  input,
  OnChanges,
  output,
  SimpleChanges,
} from '@angular/core';
import { ModuleListComponent } from './components/module-list/module-list.component';
import { Module } from '../../../../../../models/modules/module';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-empty-module',
    imports: [ModuleListComponent, CommonModule],
    templateUrl: './empty-module.component.html',
    styleUrl: './empty-module.component.scss'
})
export class EmptyModuleComponent implements OnChanges {
  showListOfModules = false;

  module = input<Module>();
  entityType = input<string>();

  moduleSelected = output<Module>();

  clickHandler(event: Event) {
    event.stopPropagation();
    this.showListOfModules = true;
  }

  moduleSelectedHandler(module: Module) {
    this.moduleSelected.emit(module);
    this.showListOfModules = false;
  }

  mouseLeaveHandler() {
    this.showListOfModules = false;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.showListOfModules = false;
  }
}
