import { Component, input, OnInit, output } from '@angular/core';
import { Module } from '../../../../../../../../models/modules/module';
import { ModuleService } from '../../../../../../../../services/module/module.service';
import { ModuleComponent } from '../module/module.component';
import { EntityType } from '../../../../constants/entity-types';

@Component({
    selector: 'app-module-list',
    imports: [ModuleComponent],
    templateUrl: './module-list.component.html',
    styleUrl: './module-list.component.scss'
})
export class ModuleListComponent implements OnInit {
  entityType = input<string>();
  module = input<Module>();

  moduleSelected = output<Module>();

  modules: Module[] = [];

  constructor(private moduleService: ModuleService) {}

  ngOnInit(): void {
    switch (this.entityType()) {
      case EntityType.Module:
        this.moduleService
          .getModules()
          .then((modules) => (this.modules = modules));
        break;
      case EntityType.SubModule:
        this.moduleService
          .getSubModules()
          .then((modules) => (this.modules = modules));
        break;
    }
  }

  clickHandler(event: Event) {
    event.stopPropagation();
  }
}
