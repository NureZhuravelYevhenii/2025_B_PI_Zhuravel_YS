import {
  Component,
  input,
  OnChanges,
  OnDestroy,
  output,
  SimpleChanges,
} from '@angular/core';
import { RelationWithId } from '../../models/relation-with-id';
import { Relation } from '../../models/relation';
import { RelationTypes } from '../../models/relation-types';
import { RelationWithNames } from '../../models/relation-with-names';
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { RelationComponent } from '../relation/relation.component';
import { EntityWithId } from '../../models/entity-with-id';

@Component({
  selector: 'app-relations',
  imports: [DialogModule, ButtonModule],
  templateUrl: './relations.component.html',
  styleUrl: './relations.component.scss',
  providers: [DialogService],
})
export class RelationsComponent implements OnChanges, OnDestroy {
  dialogRef: DynamicDialogRef | undefined;

  providedEntitiesAsDictionary = input<{ [id: number]: EntityWithId }>();

  onRelationsChanged = output<{ [id: number]: RelationWithId }>();

  relationsCounter = 0;
  relations: { [id: number]: RelationWithId } = {};
  relationsAsArray: RelationWithNames[] = [];

  selectedRelation?: RelationWithId;

  constructor(private dialogService: DialogService) {}

  addRelation() {
    const id = ++this.relationsCounter;

    const newRelation: RelationWithId = {
      id,
      primaryEntityId: 0,
      secondaryEntityId: 0,
      relationType: RelationTypes.OneToOne,
    };

    this.relations[id] = newRelation;
    this.selectRelation(id);
    this.adjustRelationsWithNames();
    this.onRelationsChanged.emit(this.relations);
  }

  removeRelation(id: number) {
    delete this.relations[id];
    this.adjustRelationsWithNames();
    this.onRelationsChanged.emit(this.relations);
  }

  selectRelation(id: number) {
    this.selectedRelation = this.relations[id];
    this.dialogRef = this.dialogService.open(RelationComponent, {
      header: 'Relation',
      data: {
        relation: this.selectedRelation,
        providedEntities: this.providedEntitiesAsDictionary() ?? {},
        onRelationChanged: this.relationChanged.bind(this),
      },
      closable: false,
    });
  }

  unselectRelation() {
    this.selectedRelation = undefined;
    this.dialogRef?.close();
  }

  relationChanged(relation: Relation) {
    if (this.selectedRelation) {
      this.selectedRelation.primaryEntityId = relation.primaryEntityId;
      this.selectedRelation.secondaryEntityId = relation.secondaryEntityId;
      this.selectedRelation.relationType = relation.relationType;
      this.adjustRelationsWithNames();
      this.onRelationsChanged.emit(this.relations);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedEntitiesAsDictionary']) {
      this.adjustRelationsWithNames();
    }
  }

  adjustRelationsWithNames() {
    const entitiesAsDictionary = this.providedEntitiesAsDictionary();

    if (entitiesAsDictionary) {
      this.relationsAsArray = Object.values(
        this.relations
      ).map<RelationWithNames>((relation) => ({
        ...relation,
        primaryEntityName: relation.primaryEntityId
          ? entitiesAsDictionary[relation.primaryEntityId].name
          : '',
        secondaryEntityName: relation.secondaryEntityId
          ? entitiesAsDictionary[relation.secondaryEntityId].name
          : '',
      }));
    }
  }

  ngOnDestroy(): void {
    this.dialogRef?.close();
  }
}
