import { Component, input, output } from '@angular/core';
import { Module } from '../../../../../../../../models/modules/module';

@Component({
    selector: 'app-module-list-entity',
    imports: [],
    templateUrl: './module.component.html',
    styleUrl: './module.component.scss'
})
export class ModuleComponent {
  module = input.required<Module>();

  clicked = output<Module>();

  clickHandler(event: Event) {
    event.stopPropagation();
    this.clicked.emit(this.module());
  }
}
