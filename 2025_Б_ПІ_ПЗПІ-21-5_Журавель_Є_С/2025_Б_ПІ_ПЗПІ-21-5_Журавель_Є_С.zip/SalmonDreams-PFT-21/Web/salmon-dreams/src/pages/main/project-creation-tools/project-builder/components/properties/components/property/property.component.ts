import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { Property } from '../../../../../../../../models/modules/property';
import { ReactiveFormsModule } from '@angular/forms';
import { NumberInputComponent } from '../../../../../../../../shared/inputs/number-input/number-input.component';
import { NumberArrayInputComponent } from '../../../../../../../../shared/inputs/number-array-input/number-array-input.component';
import { StringInputComponent } from '../../../../../../../../shared/inputs/string-input/string-input.component';
import { StringArrayInputComponent } from '../../../../../../../../shared/inputs/string-array-input/string-array-input.component';
import { ObjectInputComponent } from '../../../../../../../../shared/inputs/object-input/object-input.component';
import { EnumComponent } from '../../../../../../../../shared/inputs/enum-input/enum-input.component';

@Component({
    selector: 'app-property',
    imports: [
        ReactiveFormsModule,
        NumberInputComponent,
        NumberArrayInputComponent,
        StringInputComponent,
        StringArrayInputComponent,
        ObjectInputComponent,
        EnumComponent,
    ],
    templateUrl: './property.component.html',
    styleUrl: './property.component.scss'
})
export class PropertyComponent implements OnChanges, OnInit {
  property = input<Property>();
  propertyValue = input<any>();

  valueChanged = output<any>();

  value: any;

  valueChangedHandler(newValue: any) {
    this.value = newValue;
    this.valueChanged.emit(newValue);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['propertyValue']) {
      this.value = this.propertyValue();
    }
  }

  ngOnInit(): void {
    this.value = this.propertyValue();
  }
}
