export enum EntityType {
  Module = 'modules',
  SubModule = 'sub-modules',
}
