import { Property } from "./property";

export interface PropertyWithId extends Property{
    id: number;
}