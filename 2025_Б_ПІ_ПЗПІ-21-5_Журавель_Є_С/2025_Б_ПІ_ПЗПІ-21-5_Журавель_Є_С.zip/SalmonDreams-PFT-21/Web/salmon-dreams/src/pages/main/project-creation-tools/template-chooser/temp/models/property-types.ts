export enum PropertyTypes {
  Int = 'Int',
  Long = 'Long',
  Decimal = 'Decimal',
  Bool = 'Bool',
  String = 'String',
  DateTime = 'DateTime',
}
