import { FileSelectEvent, FileUploadModule } from 'primeng/fileupload';
import { FormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { ButtonModule } from 'primeng/button';
import { Component } from '@angular/core';
import { ProjectGenerationService } from '../../../../services/project-generation/project-generation.service';
import { InputWithMarkupTypeSelectorComponent } from './components/input-with-markup-type-selector/input-with-markup-type-selector.component';

@Component({
    selector: 'main-page',
    templateUrl: 'just-markup-tool.template.html',
    styleUrl: 'just-markup-tool.styles.scss',
    imports: [
        ButtonModule,
        DropdownModule,
        FormsModule,
        FileUploadModule,
        InputWithMarkupTypeSelectorComponent,
    ]
})
export class JustMarkupToolComponent {
  isGeneratingAvalable: boolean = false;
  file?: File;
  text?: string;
  status?: string;
  markupType?: string;

  constructor(private projectGenerationService: ProjectGenerationService) {}

  onFileChanged(event: FileSelectEvent) {
    const files = event.currentFiles;
    this.file = files !== null ? files[0] : undefined;
    this.isGeneratingAvalable = this.file !== undefined;
  }

  onFileRemove() {
    this.file = undefined;
    this.isGeneratingAvalable = this.file !== undefined;
  }

  onTextChanged(event: Event) {
    const value = (event.target as HTMLInputElement).value;
    this.text = value.trim();
    this.isGeneratingAvalable = this.text.length !== 0;
  }

  onMarkupTypeChange(markupType: string) {
    this.markupType = markupType;
  }

  submit() {
    if (this.text) {
      this.projectGenerationService
        .generateArchiveForText(this.text, this.markupType)
        .subscribe((blob) => {
          const link = URL.createObjectURL(blob);
          const linkObj = document.createElement('a');
          linkObj.href = link;
          linkObj.download = 'project.zip';
          linkObj.click();
          linkObj.remove();
        });
    }
    if (this.file) {
      this.projectGenerationService
        .generateArchiveForFile(this.file, this.markupType)
        .subscribe((blob) => {
          const link = URL.createObjectURL(blob);
          const linkObj = document.createElement('a');
          linkObj.href = link;
          linkObj.download = 'project.zip';
          linkObj.click();
          linkObj.remove();
        });
    }
  }
}
