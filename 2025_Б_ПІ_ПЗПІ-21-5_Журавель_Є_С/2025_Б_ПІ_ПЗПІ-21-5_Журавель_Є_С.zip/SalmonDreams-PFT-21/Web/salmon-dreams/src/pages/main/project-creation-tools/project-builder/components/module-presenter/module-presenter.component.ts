import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { EmptyModuleComponent } from '../empty-module/empty-module.component';
import { ModuleComponent } from '../module/module.component';
import { Module } from '../../../../../../models/modules/module';
import { ModuleWithId } from '../../../../../../models/modules/module-id';
import { MarkupService } from '../../../../../../services/markup/markup.service';
import { EntityType } from '../../constants/entity-types';

@Component({
    selector: 'app-module-presenter',
    imports: [EmptyModuleComponent, ModuleComponent],
    templateUrl: './module-presenter.component.html',
    styleUrl: './module-presenter.component.scss'
})
export class ModulePresenterComponent implements OnChanges, OnInit {
  modules: ModuleWithId[] = [];
  entityType: string = '';

  module = input<ModuleWithId>();

  moduleSelected = output<ModuleWithId>();

  constructor(private markupService: MarkupService) {}

  moduleAddedHandler(module: Module) {
    const id = this.markupService.registerModule(module, this.module()?.id);
    this.modules.push({ ...module, id });
  }

  switchModuleHandler(module: ModuleWithId) {
    this.moduleSelected.emit(module);
  }

  ngOnChanges(changes: SimpleChanges): void {
    const moduleChanges = changes['module'];

    const module = this.module();
    if (moduleChanges.currentValue != moduleChanges.previousValue) {
      this.entityType = this.module()
        ? EntityType.SubModule
        : EntityType.Module;

      if (module) {
        const newModule = this.markupService.getModule(module.id);
        this.modules = newModule.modulesWithId.map<ModuleWithId>((m) => {
          return { ...m.module, id: m.id };
        });
      } else {
        this.modules = this.markupService.getParentModules();
      }
    }
  }

  ngOnInit(): void {
    this.entityType = this.module() ? EntityType.SubModule : EntityType.Module;
  }
}
