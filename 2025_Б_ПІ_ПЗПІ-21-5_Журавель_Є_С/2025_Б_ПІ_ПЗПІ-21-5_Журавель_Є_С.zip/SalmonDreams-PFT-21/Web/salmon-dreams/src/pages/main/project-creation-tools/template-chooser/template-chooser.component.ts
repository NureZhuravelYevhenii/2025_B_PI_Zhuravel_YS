import { Component } from '@angular/core';
import { MarkupService } from '../../../../services/markup/markup.service';
import { ProjectGenerationService } from '../../../../services/project-generation/project-generation.service';
import { EntitiesComponent } from './temp/components/entities/entities.component';
import { RelationsComponent } from './temp/components/relations/relations.component';
import { ButtonModule } from 'primeng/button';
import { EntityWithId } from './temp/models/entity-with-id';
import { RelationWithId } from './temp/models/relation-with-id';
import { Module } from '../../../../models/modules/module';
import { StringInputComponent } from '../../../../shared/inputs/string-input/string-input.component';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-template-chooser',
  imports: [
    EntitiesComponent,
    RelationsComponent,
    ButtonModule,
    StringInputComponent,
    CheckboxModule,
    FormsModule,
  ],
  templateUrl: './template-chooser.component.html',
  styleUrl: './template-chooser.component.scss',
})
export class TemplateChooserComponent {
  isAuthorizationEnabled = false;

  entities: { [id: number]: EntityWithId } = {};
  entitiesCount: number = 0;
  relations: { [id: number]: RelationWithId } = {};

  projectName: string = '';

  constructor(
    private markupService: MarkupService,
    private projectGenerationService: ProjectGenerationService
  ) {}

  generateProject() {
    this.createModule();
    this.projectGenerationService
      .generateArchiveForText(this.markupService.createMarkupString(), 'json')
      .subscribe((blob) => {
        const link = URL.createObjectURL(blob);
        const linkObj = document.createElement('a');
        linkObj.href = link;
        linkObj.download = 'project.zip';
        linkObj.click();
        linkObj.remove();
      });
    this.markupService.clean();
  }

  createModule() {
    const dotNetId = this.markupService.registerModule({
      name: 'DotNet',
      properties: [],
      accaptableContents: [],
      producedContents: [],
    });
    this.markupService.setProperties(dotNetId, {
      projectName: this.projectName,
    });

    const aspNetId = this.markupService.registerModule(
      {
        name: 'AspNet',
        properties: [],
        accaptableContents: [],
        producedContents: [],
      },
      dotNetId
    );
    const automapperRegistrationId = this.markupService.registerModule(
      {
        name: 'AutomapperRegistration',
        properties: [],
        accaptableContents: [],
        producedContents: [],
      },
      aspNetId
    );
    let crudControllersParentId = automapperRegistrationId;
    if (this.isAuthorizationEnabled) {
      const jwtControllersId = this.markupService.registerModule(
        {
          name: 'JwtControllers',
          properties: [],
          accaptableContents: [],
          producedContents: [],
        },
        automapperRegistrationId
      );
      crudControllersParentId = jwtControllersId;
    }
    const crudControllersId = this.markupService.registerModule(
      {
        name: 'CrudControllers',
        properties: [],
        accaptableContents: [],
        producedContents: [],
      },
      crudControllersParentId
    );
    let servicesParentId = crudControllersId;
    if (this.isAuthorizationEnabled) {
      const jwtIdentityServicesId = this.markupService.registerModule(
        {
          name: 'JwtIdentityServices',
          properties: [],
          accaptableContents: [],
          producedContents: [],
        },
        crudControllersId
      );
      servicesParentId = jwtIdentityServicesId;
    }
    const servicesId = this.markupService.registerModule(
      {
        name: 'Services',
        properties: [],
        accaptableContents: [],
        producedContents: [],
      },
      servicesParentId
    );
    const efCoreDataAccessId = this.markupService.registerModule(
      {
        name: 'EfCoreDataAccess',
        properties: [],
        accaptableContents: [],
        producedContents: [],
      },
      servicesId
    );

    for (const relationId in this.relations) {
      const relation = this.relations[relationId];
      const relationModuleId = this.markupService.registerModule(
        {
          name: 'Relation',
          properties: [],
          accaptableContents: [],
          producedContents: [],
        },
        efCoreDataAccessId
      );
      this.markupService.setProperties(relationModuleId, {
        PrimaryEntity: relation.primaryEntityId
          ? this.entities[relation.primaryEntityId].name
          : '',
        SecondaryEntity: relation.secondaryEntityId
          ? this.entities[relation.secondaryEntityId].name
          : '',
        RelationType: relation.relationType,
      });
    }

    for (const entityId in this.entities) {
      const entity = this.entities[entityId];
      let parentId = efCoreDataAccessId;
      if (this.isAuthorizationEnabled && entity.isIdentityEntity) {
        const jwtIdentityId = this.markupService.registerModule(
          {
            name: 'JwtIdentityEntity',
            properties: [],
            accaptableContents: [],
            producedContents: [],
          },
          efCoreDataAccessId
        );
        const identityId = this.markupService.registerModule(
          {
            name: 'IdentityEntity',
            properties: [],
            accaptableContents: [],
            producedContents: [],
          },
          jwtIdentityId
        );
        this.markupService.setProperties(identityId, {
          loginProperty: 'Login',
        });
        parentId = identityId;
      }

      const entityModuleId = this.markupService.registerModule(
        {
          name: 'Entity',
          properties: [],
          accaptableContents: [],
          producedContents: [],
        },
        parentId
      );
      this.markupService.setProperties(entityModuleId, { name: entity.name });

      for (const property of entity.properties) {
        const propertyId = this.markupService.registerModule(
          {
            name: 'Property',
            properties: [],
            accaptableContents: [],
            producedContents: [],
          },
          entityModuleId
        );
        this.markupService.setProperties(propertyId, {
          name: property.name,
          type: property.type,
        });
      }
    }
  }

  entitiesChanged(entities: { [id: number]: EntityWithId }) {
    this.entities = entities;
    this.entitiesCount = Object.keys(this.entities).length;
  }

  relationsChanged(relations: { [id: number]: RelationWithId }) {
    this.relations = relations;
  }

  projectNameChanged(projectName: string) {
    this.projectName = projectName;
  }

  getEmptyModule(moduleName: string): Module {
    return {
      name: moduleName,
      accaptableContents: [],
      producedContents: [],
      properties: [],
    };
  }
}
