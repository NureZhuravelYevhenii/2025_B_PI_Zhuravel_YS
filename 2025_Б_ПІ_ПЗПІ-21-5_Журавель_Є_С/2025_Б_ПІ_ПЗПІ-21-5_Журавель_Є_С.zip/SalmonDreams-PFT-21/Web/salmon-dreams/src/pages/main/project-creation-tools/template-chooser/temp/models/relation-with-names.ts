import { RelationWithId } from './relation-with-id';

export interface RelationWithNames extends RelationWithId {
  primaryEntityName: string;
  secondaryEntityName: string;
}
