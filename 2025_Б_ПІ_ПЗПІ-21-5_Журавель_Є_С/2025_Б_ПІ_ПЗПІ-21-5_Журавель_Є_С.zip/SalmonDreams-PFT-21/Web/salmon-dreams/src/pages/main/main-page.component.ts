import { Component } from '@angular/core';
import { CentrilizedComponent } from '../../shared/centrilized-component/centrilized.component';
import { RouterModule } from '@angular/router';
import { ModeSwitcherComponent } from "./components/mode-switcher/mode-switcher.component";

@Component({
    selector: 'main-page',
    templateUrl: 'main-page.template.html',
    styleUrl: 'main-page.styles.scss',
    imports: [RouterModule, CentrilizedComponent, ModeSwitcherComponent]
})
export class MainPage {}
