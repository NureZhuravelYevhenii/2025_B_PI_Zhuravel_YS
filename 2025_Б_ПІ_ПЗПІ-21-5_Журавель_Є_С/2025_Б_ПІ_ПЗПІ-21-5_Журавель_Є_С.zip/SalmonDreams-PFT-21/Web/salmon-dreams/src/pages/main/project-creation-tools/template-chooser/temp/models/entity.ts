import { Property } from './property';

export interface Entity {
  name: string;
  properties: Property[];
  isIdentityEntity: boolean;
}
