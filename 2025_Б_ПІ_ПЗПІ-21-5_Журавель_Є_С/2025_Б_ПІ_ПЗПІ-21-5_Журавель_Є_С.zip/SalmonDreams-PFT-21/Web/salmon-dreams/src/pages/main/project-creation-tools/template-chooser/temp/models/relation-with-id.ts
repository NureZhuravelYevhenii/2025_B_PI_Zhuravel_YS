import { Relation } from './relation';

export interface RelationWithId extends Relation {
  id: number;
}
