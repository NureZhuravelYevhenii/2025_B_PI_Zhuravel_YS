import { Component } from '@angular/core';
import { ModuleDescriptionWrapperComponent } from './components/module-description-wrapper/module-description-wrapper.component';
import { ButtonModule } from 'primeng/button';
import { MarkupService } from '../../../../services/markup/markup.service';
import { ProjectGenerationService } from '../../../../services/project-generation/project-generation.service';

@Component({
    selector: 'app-project-builder',
    imports: [ModuleDescriptionWrapperComponent, ButtonModule],
    templateUrl: './project-builder.component.html',
    styleUrl: './project-builder.component.scss'
})
export class ProjectBuilderComponent {
  isGenerateButtonActive = false;

  constructor(
    private markupService: MarkupService,
    private projectGenerationService: ProjectGenerationService
  ) {}

  isGenerateButtonActiveChangingHandler(newFlag: boolean) {
    this.isGenerateButtonActive = newFlag;
  }

  generateHandler() {
    this.projectGenerationService
      .generateArchiveForText(this.markupService.createMarkupString(), 'json')
      .subscribe((blob) => {
        const link = URL.createObjectURL(blob);
        const linkObj = document.createElement('a');
        linkObj.href = link;
        linkObj.download = 'project.zip';
        linkObj.click();
        linkObj.remove();
      });
  }
}
