import {
  Component,
  input,
  OnChanges,
  output,
  SimpleChanges,
} from '@angular/core';
import { StringInputComponent } from '../../../../../../../shared/inputs/string-input/string-input.component';
import { EnumComponent } from '../../../../../../../shared/inputs/enum-input/enum-input.component';
import { ButtonModule } from 'primeng/button';
import { PropertyWithId } from '../../models/property-with-id';
import { Entity } from '../../models/entity';
import { PropertyTypes } from '../../models/property-types';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { FormsModule } from '@angular/forms';
import { CheckboxModule } from 'primeng/checkbox';

@Component({
  selector: 'app-entity',
  imports: [
    StringInputComponent,
    EnumComponent,
    ButtonModule,
    FormsModule,
    CheckboxModule,
  ],
  templateUrl: './entity.component.html',
  styleUrl: './entity.component.scss',
})
export class EntityComponent {
  onEntityChanged: (entity: Entity) => void;

  propertyTypesEnumValues = Object.keys(PropertyTypes);

  propertiesCounter: number = 0;
  properties: {
    [id: number]: PropertyWithId;
  } = {};
  propertiesAsArray: PropertyWithId[] = [];
  name: string = '';
  isAuthorizationEnabled: boolean = false;
  isIdentityEntity: boolean = false;

  constructor(
    config: DynamicDialogConfig,
    private ref: DynamicDialogRef<Entity>
  ) {
    const stronglyTypedConfig = config.data as {
      entity: Entity;
      onEntityChanged: (entity: Entity) => void;
      isAuthorizationEnabled: boolean;
    };
    this.name = stronglyTypedConfig.entity.name;
    this.isIdentityEntity = stronglyTypedConfig.entity.isIdentityEntity;
    this.isAuthorizationEnabled = stronglyTypedConfig.isAuthorizationEnabled;

    this.properties = {};
    for (let property of stronglyTypedConfig.entity.properties) {
      const id = ++this.propertiesCounter;
      this.properties[id] = { ...property, id };
    }
    this.adjustPropertiesAsArray();
    this.onEntityChanged = stronglyTypedConfig.onEntityChanged;
  }

  addProperty() {
    const id = ++this.propertiesCounter;
    this.properties[id] = {
      id,
      name: '',
      type: PropertyTypes.Int,
    };

    this.adjustPropertiesAsArray();
    this.onEntityChanged({
      name: this.name,
      properties: this.propertiesAsArray,
      isIdentityEntity: this.isIdentityEntity,
    });
  }

  changePropertyName(id: number, newName: string) {
    this.properties[id] = {
      ...this.properties[id],
      name: newName,
    };

    this.adjustPropertiesAsArray();
    this.onEntityChanged({
      name: this.name,
      properties: this.propertiesAsArray,
      isIdentityEntity: this.isIdentityEntity,
    });
  }

  changePropertyType(id: number, newType: string) {
    this.properties[id] = {
      ...this.properties[id],
      type: PropertyTypes[newType as keyof typeof PropertyTypes],
    };

    this.adjustPropertiesAsArray();
    this.onEntityChanged({
      name: this.name,
      properties: this.propertiesAsArray,
      isIdentityEntity: this.isIdentityEntity,
    });
  }

  changeName(name: string) {
    this.name = name;

    this.onEntityChanged({
      name: this.name,
      properties: this.propertiesAsArray,
      isIdentityEntity: this.isIdentityEntity,
    });
  }

  changeIdentityEntityCheckbox() {
    this.onEntityChanged({
      name: this.name,
      properties: this.propertiesAsArray,
      isIdentityEntity: this.isIdentityEntity,
    });
  }

  deleteProperty(id: number) {
    delete this.properties[id];
    this.adjustPropertiesAsArray();
    this.onEntityChanged({
      name: this.name,
      properties: this.propertiesAsArray,
      isIdentityEntity: this.isIdentityEntity,
    });
  }

  close() {
    this.ref.close();
  }

  adjustPropertiesAsArray() {
    this.propertiesAsArray = Object.values(this.properties);
  }
}
