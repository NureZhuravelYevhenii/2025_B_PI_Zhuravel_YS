import { Entity } from './entity';

export interface EntityWithId extends Entity {
  id: number;
}
