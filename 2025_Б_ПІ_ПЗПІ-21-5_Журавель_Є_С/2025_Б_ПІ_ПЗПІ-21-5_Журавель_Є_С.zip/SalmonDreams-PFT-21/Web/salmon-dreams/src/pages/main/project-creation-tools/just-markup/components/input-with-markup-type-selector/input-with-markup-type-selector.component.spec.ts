import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputWithMarkupTypeSelectorComponent } from './input-with-markup-type-selector.component';

describe('InputWithMarkupTypeSelectorComponent', () => {
  let component: InputWithMarkupTypeSelectorComponent;
  let fixture: ComponentFixture<InputWithMarkupTypeSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InputWithMarkupTypeSelectorComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InputWithMarkupTypeSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
