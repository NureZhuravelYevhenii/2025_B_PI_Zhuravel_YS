import { Component } from '@angular/core';
import { CentrilizedComponent } from '../../shared/centrilized-component/centrilized.component';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { UserService } from '../../services/user/user.service';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputTextModule } from 'primeng/inputtext';
import { Router, RouterModule } from '@angular/router';

@Component({
    selector: 'app-sign-in',
    imports: [
        CentrilizedComponent,
        ReactiveFormsModule,
        ButtonModule,
        FloatLabelModule,
        InputTextModule,
        RouterModule,
    ],
    templateUrl: './sign-in.component.html',
    styleUrl: './sign-in.component.scss'
})
export class SignInComponent {
  formGroup = new FormGroup({
    login: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required]),
    password: new FormControl('', [Validators.required]),
    approvePassword: new FormControl('', [Validators.required]),
  });

  constructor(private userService: UserService, private router: Router) {}

  sendRegisterRequest() {
    if (this.formGroup.valid) {
      this.userService
        .register({
          login: this.formGroup.value.login!,
          email: this.formGroup.value.email!,
          password: this.formGroup.value.password!,
          approvePassword: this.formGroup.value.approvePassword!,
        })
        .subscribe(() => {
          this.router.navigate(['/']);
        });
    }
  }
}
