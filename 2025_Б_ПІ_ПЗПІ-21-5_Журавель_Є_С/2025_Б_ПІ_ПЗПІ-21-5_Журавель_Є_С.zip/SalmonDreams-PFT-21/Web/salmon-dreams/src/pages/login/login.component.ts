import { Component } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { UserService } from '../../services/user/user.service';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { CentrilizedComponent } from '../../shared/centrilized-component/centrilized.component';
import { FloatLabelModule } from 'primeng/floatlabel';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';

@Component({
    selector: 'app-login',
    imports: [
        FormsModule,
        ButtonModule,
        InputTextModule,
        ReactiveFormsModule,
        CentrilizedComponent,
        FloatLabelModule,
        RouterModule,
    ],
    templateUrl: './login.component.html',
    styleUrl: './login.component.scss'
})
export class LoginComponent {
  formGroup = new FormGroup({
    login: new FormControl(),
    password: new FormControl(),
  });

  constructor(private userService: UserService, private router: Router) {}

  sendLoginRequest() {
    if (this.formGroup.value.login && this.formGroup.value.password) {
      this.userService?.login({
          login: this.formGroup.value.login,
          password: this.formGroup.value.password,
        })
        ?.subscribe(() => {
          this.router.navigate(['/']);
        });
    }
  }
}
