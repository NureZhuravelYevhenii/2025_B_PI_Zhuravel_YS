import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { StringInputComponent } from '../string-input/string-input.component';
import { ButtonModule } from 'primeng/button';

@Component({
    selector: 'app-string-array-input',
    imports: [StringInputComponent, ButtonModule],
    templateUrl: './string-array-input.component.html',
    styleUrl: './string-array-input.component.scss'
})
export class StringArrayInputComponent implements OnInit, OnChanges {
  entities: string[] = [];

  providedEntities = input<any>();

  entitiesChanged = output<string[]>();

  addNewOne() {
    this.entities.push('');
  }

  deleteEntity(index: number) {
    this.entities.splice(index, 1);
  }

  entityChanged(index: number, newText: string) {
    this.entities[index] = newText;
    this.entitiesChanged.emit(this.entities);
  }

  ngOnInit(): void {
    this.entities = this.providedEntities() ?? [];
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedEntities']) {
      this.entities = this.providedEntities() ?? [];
    }
  }
}
