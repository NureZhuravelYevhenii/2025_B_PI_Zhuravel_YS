import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';

@Component({
    selector: 'app-string-input',
    imports: [InputTextModule, FormsModule],
    templateUrl: './string-input.component.html',
    styleUrl: './string-input.component.scss'
})
export class StringInputComponent implements OnInit, OnChanges {
  someText: string = '';

  providedText = input<string>();

  textChanged = output<string>();

  textChangedHandler() {
    this.textChanged.emit(this.someText);
  }

  ngOnInit(): void {
    this.someText = this.providedText() ?? '';
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedText']) {
      this.someText = this.providedText() ?? '';
    }
  }
}
