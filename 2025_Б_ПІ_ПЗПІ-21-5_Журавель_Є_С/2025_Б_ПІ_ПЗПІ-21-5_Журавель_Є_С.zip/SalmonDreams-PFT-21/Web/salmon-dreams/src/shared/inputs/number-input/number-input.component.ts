import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputNumberModule } from 'primeng/inputnumber';

@Component({
    selector: 'app-number-input',
    imports: [
        ReactiveFormsModule,
        FormsModule,
        FloatLabelModule,
        InputNumberModule,
    ],
    templateUrl: './number-input.component.html',
    styleUrl: './number-input.component.scss'
})
export class NumberInputComponent implements OnChanges {
  internalNumber: number = 0;

  providedNumber = input<number>(0);

  valueChanged = output<number>();

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedNumber']) {
      this.internalNumber = this.providedNumber();
    }
  }

  numberChanged() {
    this.valueChanged.emit(this.internalNumber ?? 0);
  }
}
