import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { NumberInputComponent } from '../number-input/number-input.component';

@Component({
    selector: 'app-number-array-input',
    imports: [ButtonModule, NumberInputComponent],
    templateUrl: './number-array-input.component.html',
    styleUrl: './number-array-input.component.scss'
})
export class NumberArrayInputComponent implements OnInit, OnChanges {
  entities: number[] = [];

  providedEntities = input<number[]>();

  entitiesChanged = output<number[]>();

  addNewOne() {
    this.entities.push(0);
  }

  deleteEntity(index: number) {
    this.entities.splice(index, 1);
  }

  entityChanged(index: number, newNumber: number) {
    this.entities[index] = newNumber;
    this.entitiesChanged.emit(this.entities);
  }

  ngOnInit(): void {
    this.entities = this.providedEntities() ?? [];
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedEntities']) {
      this.entities = this.providedEntities() ?? [];
    }
  }
}
