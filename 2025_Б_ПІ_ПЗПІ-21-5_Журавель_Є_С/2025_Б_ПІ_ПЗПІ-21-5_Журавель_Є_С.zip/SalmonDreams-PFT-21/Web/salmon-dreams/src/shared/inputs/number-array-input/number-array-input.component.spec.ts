import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberArrayInputComponent } from './number-array-input.component';

describe('NumberArrayInputComponent', () => {
  let component: NumberArrayInputComponent;
  let fixture: ComponentFixture<NumberArrayInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [NumberArrayInputComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NumberArrayInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
