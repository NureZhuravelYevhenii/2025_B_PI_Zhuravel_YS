import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AutoCompleteModule } from 'primeng/autocomplete';

@Component({
    selector: 'app-enum-input',
    imports: [AutoCompleteModule, FormsModule],
    templateUrl: './enum-input.component.html',
    styleUrl: './enum-input.component.scss'
})
export class EnumComponent implements OnInit, OnChanges {
  value: string = '';
  suggestions: string[] = [];

  enumValues = input<string[]>();
  providedValue = input<string>();

  valueChanged = output<any>();

  search() {
    this.suggestions = [...(this.enumValues() ?? [])];
  }

  valueChangedHandler() {
    this.valueChanged.emit(this.value);
  }

  ngOnInit(): void {
    this.value = this.providedValue() ?? '';
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedValue']) {
      this.value = this.providedValue() ?? '';
    }
  }
}
