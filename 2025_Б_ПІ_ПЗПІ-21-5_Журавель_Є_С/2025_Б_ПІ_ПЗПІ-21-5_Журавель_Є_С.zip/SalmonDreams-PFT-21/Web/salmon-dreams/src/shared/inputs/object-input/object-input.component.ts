import {
  Component,
  input,
  OnChanges,
  OnInit,
  output,
  SimpleChanges,
} from '@angular/core';
import { PropertyComponent } from '../../../pages/main/project-creation-tools/project-builder/components/properties/components/property/property.component';
import { Property } from '../../../models/modules/property';
import { StringInputComponent } from '../string-input/string-input.component';
import { StringArrayInputComponent } from '../string-array-input/string-array-input.component';
import { NumberInputComponent } from '../number-input/number-input.component';
import { NumberArrayInputComponent } from '../number-array-input/number-array-input.component';

@Component({
    selector: 'app-object-input',
    imports: [
        StringInputComponent,
        StringArrayInputComponent,
        NumberInputComponent,
        NumberArrayInputComponent,
    ],
    templateUrl: './object-input.component.html',
    styleUrl: './object-input.component.scss'
})
export class ObjectInputComponent implements OnInit, OnChanges {
  propertiesWithValues: { [name: string]: any } = {};

  properties = input<Property[]>();
  providedPropertiesWithValues = input<{ [name: string]: any }>();

  propertiesChanged = output<any>();

  changeValueHandler(name: string, value: any) {
    this.propertiesWithValues[name] = value;
    this.propertiesChanged.emit(this.propertiesWithValues);
  }

  ngOnInit(): void {
    const properties = this.properties();
    if (properties) {
      for (let property of properties) {
        this.propertiesWithValues[property.name] = undefined;
      }
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['providedPropertiesWithValues']) {
      this.propertiesWithValues = this.providedPropertiesWithValues() ?? {};
    }
  }
}
