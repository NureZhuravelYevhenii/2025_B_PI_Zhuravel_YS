import { NgStyle } from '@angular/common';
import { Component, input, output } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';

@Component({
    selector: 'custom-text-area',
    imports: [ReactiveFormsModule, NgStyle],
    template: '<textarea [ngStyle]="stylesDict" (input)="change.emit($event)"></textarea>',
    styleUrl: './text-area.component.scss'
})
export class TextAreaComponent {
  stylesDict = input<{ [key: string]: string }>();
  change = output<Event>();
}
