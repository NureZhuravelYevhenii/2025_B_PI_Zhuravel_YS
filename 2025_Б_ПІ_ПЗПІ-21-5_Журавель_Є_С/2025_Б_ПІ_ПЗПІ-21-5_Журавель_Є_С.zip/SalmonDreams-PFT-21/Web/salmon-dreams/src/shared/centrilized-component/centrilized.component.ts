import { Component } from '@angular/core';

@Component({
    selector: 'centrilized-component',
    imports: [],
    templateUrl: './centrilized.component.html',
    styleUrl: './centrilized.component.scss'
})
export class CentrilizedComponent {}
