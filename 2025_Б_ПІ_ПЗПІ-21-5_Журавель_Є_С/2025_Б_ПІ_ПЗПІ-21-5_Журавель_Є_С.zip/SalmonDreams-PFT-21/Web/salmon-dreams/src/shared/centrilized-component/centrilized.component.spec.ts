import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CentrilizedComponent } from './centrilized.component';

describe('CentrilizedComponent', () => {
  let component: CentrilizedComponent;
  let fixture: ComponentFixture<CentrilizedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CentrilizedComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CentrilizedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
