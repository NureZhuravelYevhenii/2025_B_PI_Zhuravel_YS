import {
  afterNextRender,
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnChanges,
  OnInit,
  SimpleChanges,
} from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { UserService } from '../../services/user/user.service';
import { Router, RouterLink } from '@angular/router';
import { UserDto } from '../../models/user/user-dto';
import { TokenService } from '../../services/token/token.service';

@Component({
  selector: 'auth-container',
  templateUrl: './auth-container.component.html',
  styleUrl: './auth-container.component.scss',
  imports: [ButtonModule, RouterLink],
})
export class AuthContainerComponent implements OnInit {
  isAuthenticated: boolean = false;
  user?: UserDto;

  constructor(
    private userService: UserService,
    private tokenService: TokenService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isAuthenticated = this.userService.isAuthenticated();

    if (this.isAuthenticated) {
      this.userService.getUser().subscribe((value) => {
        this.user = value;
      });
    }

    this.userService.authenticated.subscribe(() => {
      this.isAuthenticated = this.userService.isAuthenticated();
      if (this.isAuthenticated) {
        this.userService.getUser().subscribe((value) => {
          this.user = value;
        });
      }
    });
  }

  unauthorize() {
    this.tokenService.clearToken();
    this.userService.authenticated.emit();
    this.router.navigate(['/login']);
  }
}
