export const allowedMarkupTypes = ['yaml', 'json'];
