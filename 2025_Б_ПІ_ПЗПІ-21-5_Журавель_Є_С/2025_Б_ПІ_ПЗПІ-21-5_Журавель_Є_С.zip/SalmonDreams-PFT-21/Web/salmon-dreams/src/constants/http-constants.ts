export const AuthorizationToken = 'auth-token';
