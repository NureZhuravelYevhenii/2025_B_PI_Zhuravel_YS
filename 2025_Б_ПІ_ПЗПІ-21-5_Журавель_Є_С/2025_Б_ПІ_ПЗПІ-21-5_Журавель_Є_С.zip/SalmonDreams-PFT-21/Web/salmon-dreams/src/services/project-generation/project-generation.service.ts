import { Injectable } from '@angular/core';
import { BaseService } from '../base-service';
import { HttpClient } from '@angular/common/http';
import { MarkupService } from '../markup/markup.service';

@Injectable({
  providedIn: 'root',
})
export class ProjectGenerationService extends BaseService {
  constructor(httpClient: HttpClient, markupService: MarkupService) {
    super(httpClient);
  }

  generateArchiveForText(input: string, markupType?: string) {
    return this.getPostFileObservable('project-generator/text/archive', {
      text: input,
      markupType,
    });
  }

  generateArchiveForFile(file: File, markupType?: string) {
    let formData = new FormData();
    formData.append('File', file);

    if (markupType) {
      formData.append('MarkupType', markupType);
    }

    return this.getPostFileObservable(
      'project-generator/text/archive',
      formData
    );
  }
}
