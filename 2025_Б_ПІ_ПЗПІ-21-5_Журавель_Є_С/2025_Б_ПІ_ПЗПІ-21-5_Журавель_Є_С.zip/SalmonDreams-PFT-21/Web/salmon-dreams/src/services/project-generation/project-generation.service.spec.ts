import { TestBed } from '@angular/core/testing';

import { ProjectGenerationService } from './project-generation.service';
import { provideHttpClient } from '@angular/common/http';
import { provideHttpClientTesting } from '@angular/common/http/testing';

describe('ProjectGenerationService', () => {
  let service: ProjectGenerationService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        provideHttpClient(),
        provideHttpClientTesting(),
      ]
    });
    service = TestBed.inject(ProjectGenerationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
