import { Injectable } from '@angular/core';
import colors from './colors.json';

@Injectable({
  providedIn: 'root',
})
export class ColorService {
  getColorPalette(text: string) {
    let utf8Encode = new TextEncoder();
    const colorIndex = utf8Encode.encode(text).reduce((pv, cv) => pv + cv, 0);

    return colors[colorIndex % colors.length];
  }
}
