import { Injectable } from '@angular/core';
import { SimplifiedModuleId } from '../../models/modules/simplified-module-id';
import { Module } from '../../models/modules/module';
import { ModuleWithId } from '../../models/modules/module-id';
import { ResponseModule } from '../../models/modules/response-module';
import { SimplifiedModule } from '../../models/modules/simplified-module';

@Injectable({
  providedIn: 'root',
})
export class MarkupService {
  private idRelation: { [id: number]: Set<number> } = {};
  private idModuleRelation: { [id: number]: SimplifiedModuleId } = {};

  readonly readyToGenerateFlagChangedEvent: ((newFlag: boolean) => void)[] = [];

  constructor() {}

  createMarkupString() {
    let parentIds = Object.keys(this.idRelation);

    const resultModules: SimplifiedModuleId[] = [];

    if (!parentIds.length) {
      for (let moduleId of Object.keys(this.idModuleRelation)) {
        const module = this.idModuleRelation[+moduleId];
        resultModules.push(module);
      }
      return JSON.stringify(this.convertModules(resultModules));
    }

    for (let parentId of parentIds) {
      if (this.isChild(+parentId)) {
        continue;
      }

      const parentModule = this.idModuleRelation[+parentId];

      const pushToModules: SimplifiedModuleId[] = [];
      let currentModule: SimplifiedModuleId | undefined = parentModule;
      while (currentModule) {
        let values = this.idRelation[currentModule.id]?.values();
        if (values) {
          const childModules = [];
          for (let i of values) {
            const module = this.idModuleRelation[i];
            childModules.push(module);
          }
          currentModule.modules = childModules;
          pushToModules.push(...childModules);
        }
        currentModule = pushToModules.pop();
      }

      resultModules.push(parentModule);
    }

    return JSON.stringify(this.convertModules(resultModules));
  }

  registerModule(module: Module, parentId?: number) {
    const id = Object.keys(this.idModuleRelation).length + 1;
    const simplifiedModuleWithId: SimplifiedModuleId = {
      module,
      modules: [],
      modulesWithId: [],
      properties: {},
      id,
    };
    this.idModuleRelation[id] = simplifiedModuleWithId;

    if (parentId) {
      if (!this.idRelation[parentId])
        this.idRelation[parentId] = new Set<number>();
      this.idRelation[parentId].add(id);
    } else {
      this.idRelation[id] = new Set<number>();
    }

    this.readyToGenerateFlagChanged(true);

    return id;
  }

  getModule(id: number) {
    const module = this.idModuleRelation[id];

    const childModules = [];
    const childSet = this.idRelation[id];
    if (!childSet) {
      return module;
    }
    for (let i of childSet.entries()) {
      childModules.push(this.idModuleRelation[i[0]]);
    }
    module.modulesWithId = childModules;
    return module;
  }

  getParentModules() {
    const modules: ModuleWithId[] = [];
    let idRelationKeys = Object.keys(this.idRelation);

    if (!idRelationKeys.length) {
      idRelationKeys = Object.keys(this.idModuleRelation);
    }

    for (let id of idRelationKeys) {
      if (this.isChild(+id)) {
        continue;
      }

      const module = this.idModuleRelation[+id];
      modules.push({ ...module.module, id: module.id });
    }
    return modules;
  }

  getParentModule(id: number) {
    for (let parentId of Object.keys(this.idRelation)) {
      if (this.idRelation[+parentId].has(id)) {
        const module = this.idModuleRelation[+parentId];
        return { ...module.module, id: module.id };
      }
    }
    return undefined;
  }

  deleteModule(id: number) {
    let newIdRelation: { [id: number]: Set<number> } = {};

    if (Object.keys(this.idRelation).includes(id.toString())) {
      const setOfModulesToDelete = this.idRelation[id];
      for (let childId of setOfModulesToDelete) {
        this.deleteModule(childId);
      }

      for (let i of Object.keys(this.idRelation)) {
        if (+i != id) {
          const setOfNumbers = this.idRelation[+i];
          setOfNumbers.delete(id);
          newIdRelation[+i] = setOfNumbers;
        }
      }
    } else {
      for (let parentId of Object.keys(this.idRelation)) {
        const childs = this.idRelation[+parentId];
        if (childs.has(id)) {
          childs.delete(id);
        }
      }
      newIdRelation = this.idRelation;
    }

    const newIdModuleRelation: { [id: number]: SimplifiedModuleId } = {};
    for (let i of Object.keys(this.idModuleRelation)) {
      if (+i != id) {
        newIdModuleRelation[+i] = this.idModuleRelation[+i];
      }
    }

    this.idModuleRelation = newIdModuleRelation;
    this.idRelation = newIdRelation;

    this.readyToGenerateFlagChanged(
      Object.keys(this.idModuleRelation).length > 0
    );
  }

  setProperties(id: number, properties: any) {
    const module = this.idModuleRelation[id];
    if (module) {
      module.properties = properties;
    }
  }

  getProperties(id: number) {
    const module = this.idModuleRelation[id];
    return module?.properties ?? {};
  }

  clean() {
    this.idModuleRelation = {};
    this.idRelation = {};
    this.readyToGenerateFlagChangedEvent.splice(
      0,
      this.readyToGenerateFlagChangedEvent.length
    );
    this.readyToGenerateFlagChanged(false);
  }

  private isChild(id: number) {
    for (let parentId of Object.keys(this.idRelation)) {
      if (this.idRelation[+parentId].has(id)) {
        return true;
      }
    }
    return false;
  }

  private readyToGenerateFlagChanged(newFlag: boolean) {
    this.readyToGenerateFlagChangedEvent.forEach((callback) =>
      callback(newFlag)
    );
  }

  private convertModules(modulesToConvert: SimplifiedModule[]) {
    const result: ResponseModule[] = [];

    for (let module of modulesToConvert) {
      result.push({
        modules: this.convertModules(module.modules),
        name: module.module.name,
        properties: module.properties,
      });
    }

    return result;
  }
}
