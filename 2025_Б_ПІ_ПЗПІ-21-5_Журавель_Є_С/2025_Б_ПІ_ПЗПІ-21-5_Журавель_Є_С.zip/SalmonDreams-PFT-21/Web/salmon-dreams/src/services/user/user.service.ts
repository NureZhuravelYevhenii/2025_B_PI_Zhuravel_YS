import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { UserLogin } from '../../models/user/user-login';
import { BaseService } from '../base-service';
import { UserRegistration } from '../../models/user/user-registration';
import { tap } from 'rxjs';
import { AccessToken } from '../../models/auth/access-token';
import { UserDto } from '../../models/user/user-dto';
import { TokenService } from '../token/token.service';

@Injectable({
  providedIn: 'root',
})
export class UserService extends BaseService {
  authenticated = new EventEmitter();

  constructor(httpClient: HttpClient, private tokenService: TokenService) {
    super(httpClient);
  }

  login(userLogin: UserLogin) {
    return this.getPostObservable('users/login', userLogin).pipe(
      tap((body) => {
        const authorizationToken = (body as AccessToken).accessToken;
        if (authorizationToken) {
          this.tokenService.setToken(authorizationToken);
          this.authenticated.emit();
        }
      })
    );
  }

  register(userRegistration: UserRegistration) {
    return this.getPostObservable('users/register', userRegistration).pipe(
      tap((body) => {
        const authorizationToken = (body as AccessToken).accessToken;
        if (authorizationToken) {
          this.tokenService.setToken(authorizationToken);
          this.authenticated.emit();
        }
      })
    );
  }

  refresh() {
    this.getPostObservable('users/refresh').pipe(
      tap((body) => {
        const authorizationToken = (body as AccessToken).accessToken;
        if (authorizationToken) {
          this.tokenService.setToken(authorizationToken);
          this.authenticated.emit();
        }
      })
    );
  }

  getUser(id?: number) {
    if (id) {
      return this.getGetObservable<UserDto>(`users/${id}`);
    }
    return this.getGetObservable<UserDto>(`users`);
  }

  deleteUser(id: number) {
    return this.getDeleteObservable(`users/${id}`);
  }

  isAuthenticated() {
    return this.tokenService.getToken() !== null;
  }
}
