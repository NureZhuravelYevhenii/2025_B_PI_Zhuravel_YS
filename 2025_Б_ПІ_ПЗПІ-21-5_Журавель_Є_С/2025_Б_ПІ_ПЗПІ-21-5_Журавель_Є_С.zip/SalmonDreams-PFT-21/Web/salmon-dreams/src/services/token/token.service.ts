import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { AuthorizationToken } from '../../constants/http-constants';

@Injectable({
  providedIn: 'root',
})
export class TokenService {
  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  private isBrowser(): boolean {
    return isPlatformBrowser(this.platformId);
  }

  setToken(token: string): void {
    if (this.isBrowser()) {
        console.log('agagaga')
      localStorage.setItem(AuthorizationToken, token);
    }
  }

  getToken(): string | null {
    return this.isBrowser() ? localStorage.getItem(AuthorizationToken) : null;
  }

  clearToken(): void {
    if (this.isBrowser()) {
      localStorage.removeItem(AuthorizationToken);
    }
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }
}
