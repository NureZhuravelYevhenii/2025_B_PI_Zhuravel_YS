import { HttpClient } from '@angular/common/http';
import { catchError, map } from 'rxjs';

export class BaseService {
  constructor(private httpClient: HttpClient) {}

  protected getGetObservable<TBody>(
    relativeUrl: string,
    params: { [param: string]: string } = {}
  ) {
    return this.httpClient.get<TBody>(relativeUrl, { params });
  }

  protected getGetFileObservable(
    relativeUrl: string,
    params: { [param: string]: string } = {}
  ) {
    return this.httpClient.get(relativeUrl, {
      ...params,
      responseType: 'blob',
    });
  }

  protected getPostObservable<TBody>(relativeUrl: string, data?: any) {
    return this.httpClient.post<TBody>(relativeUrl, data);
  }

  protected getPostFileObservable(relativePath: string, data?: any) {
    return this.httpClient.post(relativePath, data, {
      responseType: 'blob',
    });
  }

  protected getPutObservable<TBody>(relativeUrl: string, data?: any) {
    return this.httpClient.put<TBody>(relativeUrl, data);
  }

  protected getDeleteObservable<TBody>(relativeUrl: string, data?: any) {
    return this.httpClient.delete<TBody>(relativeUrl, data);
  }
}
