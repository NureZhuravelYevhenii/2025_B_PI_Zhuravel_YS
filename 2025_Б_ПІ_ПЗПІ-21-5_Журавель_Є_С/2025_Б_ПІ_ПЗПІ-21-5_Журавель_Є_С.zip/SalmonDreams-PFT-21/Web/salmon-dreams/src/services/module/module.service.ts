import { Injectable } from '@angular/core';
import { BaseService } from '../base-service';
import { HttpClient } from '@angular/common/http';
import { Module } from '../../models/modules/module';
import { Subject, takeUntil } from 'rxjs';
import { EntityType } from '../../pages/main/project-creation-tools/project-builder/constants/entity-types';

@Injectable({
  providedIn: 'root',
})
export class ModuleService extends BaseService {
  modules: { [key: string]: Module[] } = {};

  constructor(httpClient: HttpClient) {
    super(httpClient);
  }

  getModules(acceptableContent?: string[]) {
    return this.getFilteredModuleEntities(EntityType.Module, acceptableContent);
  }

  getSubModules(acceptableContent?: string[]) {
    return this.getFilteredModuleEntities(
      EntityType.SubModule,
      acceptableContent
    );
  }

  private async getFilteredModuleEntities(
    entityKey: string,
    acceptableContent?: string[]
  ) {
    const retrievedModules = await this.getModuleEntities(entityKey);
    if (!(acceptableContent && acceptableContent.length))
      return retrievedModules;

    const goodModules: Module[] = [];
    for (let moduleDefinition of retrievedModules) {
      for (let content of moduleDefinition.producedContents) {
        if (acceptableContent.includes(content)) {
          goodModules.push(moduleDefinition);
          break;
        }
      }
    }

    return goodModules;
  }

  private getModuleEntities(key: string) {
    const resultPromise = new Promise<Module[]>((resolve, reject) => {
      if (this.modules[key] && this.modules[key].length) {
        resolve(this.modules[key]);
      }

      this.modules[key] = [];
      const subject = new Subject();
      this.getGetObservable<Module[]>(key)
        .pipe(takeUntil(subject))
        .subscribe({
          next: (modules) => {
            this.modules[key].push(...modules);
          },
          error: reject,
          complete: () => {
            subject.complete();
            resolve(this.modules[key]);
          },
        });
    });

    return resultPromise;
  }
}
