import {
  HttpEvent,
  HttpHandlerFn,
  HttpHeaders,
  HttpRequest,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthorizationToken } from '../constants/http-constants';
import { environment } from '../environments/environment';

export function authInteceptor(
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<HttpEvent<unknown>> {
  const newReq = req.clone({
    url: environment.api_url + '/' + req.url,
    headers: new HttpHeaders({
      ['Authorization']: `Bearer ${localStorage.getItem(AuthorizationToken)}`,
    }),
  });
  return next(newReq);
}
