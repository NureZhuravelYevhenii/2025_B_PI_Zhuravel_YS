export interface AccessToken {
  accessToken: string;
}
