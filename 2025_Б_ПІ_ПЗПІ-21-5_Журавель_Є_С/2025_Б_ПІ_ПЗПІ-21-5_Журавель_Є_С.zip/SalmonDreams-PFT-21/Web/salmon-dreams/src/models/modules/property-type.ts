export type PropertyType =
  | 'string'
  | 'number'
  | 'string-array'
  | 'number-array'
  | 'object'
  | 'enum';
