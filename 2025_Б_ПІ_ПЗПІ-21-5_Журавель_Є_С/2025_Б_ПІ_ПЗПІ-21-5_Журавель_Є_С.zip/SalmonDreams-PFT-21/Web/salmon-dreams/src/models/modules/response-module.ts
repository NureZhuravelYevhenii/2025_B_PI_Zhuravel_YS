export interface ResponseModule {
  name: string;
  properties: any;
  modules: ResponseModule[];
}
