import { Module } from './module';

export interface SimplifiedModule {
  module: Module;
  modules: SimplifiedModule[];
  properties: any;
}
