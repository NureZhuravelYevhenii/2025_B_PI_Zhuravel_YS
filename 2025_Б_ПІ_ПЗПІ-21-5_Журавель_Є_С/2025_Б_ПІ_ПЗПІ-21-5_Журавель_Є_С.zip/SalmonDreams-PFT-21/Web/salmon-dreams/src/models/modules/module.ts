import { Property } from './property';

export interface Module {
  name: string;
  properties: Property[];
  accaptableContents: string[];
  producedContents: string[];
}
