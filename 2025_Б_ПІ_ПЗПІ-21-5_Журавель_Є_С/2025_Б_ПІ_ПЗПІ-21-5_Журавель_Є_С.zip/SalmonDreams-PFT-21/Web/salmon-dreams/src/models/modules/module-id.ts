import { Module } from './module';

export interface ModuleWithId extends Module {
  id: number;
}
