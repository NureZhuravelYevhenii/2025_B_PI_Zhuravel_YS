import { PropertyType } from './property-type';

export interface Property {
  name: string;
  type: PropertyType;
  properties?: Property[];
  enumValues?: string[];
}
