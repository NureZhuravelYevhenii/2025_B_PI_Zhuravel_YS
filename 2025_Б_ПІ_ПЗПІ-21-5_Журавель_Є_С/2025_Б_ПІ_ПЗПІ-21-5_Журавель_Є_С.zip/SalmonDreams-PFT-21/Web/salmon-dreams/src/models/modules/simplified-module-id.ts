import { SimplifiedModule } from './simplified-module';

export interface SimplifiedModuleId extends SimplifiedModule {
  id: number;
  modulesWithId: SimplifiedModuleId[];
}
