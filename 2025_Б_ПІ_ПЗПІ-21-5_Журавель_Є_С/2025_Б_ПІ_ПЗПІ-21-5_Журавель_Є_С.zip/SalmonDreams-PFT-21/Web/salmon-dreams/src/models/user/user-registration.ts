export interface UserRegistration {
  login: string;
  email: string;
  password: string;
  approvePassword: string;
}
