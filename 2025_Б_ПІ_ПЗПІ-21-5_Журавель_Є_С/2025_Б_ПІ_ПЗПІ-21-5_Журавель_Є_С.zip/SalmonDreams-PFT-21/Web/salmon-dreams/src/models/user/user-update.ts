export interface UserUpdate {
  id: number;
  login: string;
  email: string;
  password: string;
  isAdmin: boolean;
}
