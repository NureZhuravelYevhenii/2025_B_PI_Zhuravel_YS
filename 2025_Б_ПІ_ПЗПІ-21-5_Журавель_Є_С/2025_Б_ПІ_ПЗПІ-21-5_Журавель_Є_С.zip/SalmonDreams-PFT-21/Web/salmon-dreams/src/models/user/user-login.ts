export interface UserLogin {
  login: string;
  password: string;
}
