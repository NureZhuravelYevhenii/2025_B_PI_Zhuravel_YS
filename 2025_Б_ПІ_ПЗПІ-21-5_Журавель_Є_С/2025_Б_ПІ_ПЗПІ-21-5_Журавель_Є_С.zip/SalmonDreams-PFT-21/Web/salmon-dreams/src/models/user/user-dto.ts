export interface UserDto {
  id: number;
  login: string;
  email: string;
  isAdmin: boolean;
}
