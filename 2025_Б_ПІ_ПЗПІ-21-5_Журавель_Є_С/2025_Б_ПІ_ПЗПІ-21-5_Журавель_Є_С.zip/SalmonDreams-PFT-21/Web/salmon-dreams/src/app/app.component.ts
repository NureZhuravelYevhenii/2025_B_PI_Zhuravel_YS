import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthContainerComponent } from '../shared/auth-container/auth-container.component';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-root',
    imports: [RouterOutlet, AuthContainerComponent, CommonModule],
    templateUrl: './app.component.html',
    styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'salmon-dreams';
  bubbles: number[] = Array(10).fill(0);
}
