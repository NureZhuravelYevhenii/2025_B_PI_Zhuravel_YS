import { Routes } from '@angular/router';
import { MainPage } from '../pages/main/main-page.component';
import { LoginComponent } from '../pages/login/login.component';
import { SignInComponent } from '../pages/sign-in/sign-in.component';
import { AuthRequired } from '../shared/guards/auth-required.guard';
import { JustMarkupToolComponent } from '../pages/main/project-creation-tools/just-markup/just-markup-tool.component';
import { ProjectBuilderComponent } from '../pages/main/project-creation-tools/project-builder/project-builder.component';
import { TemplateChooserComponent } from '../pages/main/project-creation-tools/template-chooser/template-chooser.component';

export const routes: Routes = [
  {
    component: MainPage,
    path: '',
    canActivate: [AuthRequired],
    children: [
      {
        path: '',
        redirectTo: 'project-builder',
        pathMatch: 'full',
      },
      {
        path: 'just-murkup-tool',
        component: JustMarkupToolComponent,
      },
      {
        path: 'project-builder',
        component: ProjectBuilderComponent,
      },
      {
        path: 'template-chooser',
        component: TemplateChooserComponent,
      },
    ],
  },
  {
    component: LoginComponent,
    path: 'login',
  },
  {
    component: SignInComponent,
    path: 'signin',
  },
];
