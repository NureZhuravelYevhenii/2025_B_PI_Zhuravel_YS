﻿using System.Reflection;

namespace GeneralHelpers;

public static class AssemblyExtensions
{
    public static Task<string> GetResource(this Assembly assembly, string resourceName)
    {
        var fullResourceName = assembly.GetManifestResourceNames().FirstOrDefault(name => name.EndsWith(resourceName))
            ?? throw new InvalidOperationException($"Unable to load resource with name {resourceName}.");
        var resource = assembly.GetManifestResourceStream(fullResourceName)
            ?? throw new InvalidOperationException($"Unable to stream resource with name {resourceName}.");
        return new StreamReader(resource).ReadToEndAsync();
    }
}
