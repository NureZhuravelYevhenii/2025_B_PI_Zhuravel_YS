﻿using FluentAssertions;
using SharpCodeGenerator;
using SharpCodeGenerator.Entities;
using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGeneratorTests;
public class StringCodeGeneratorTests
{
    private readonly StringCodeGenerator _generator = new(4);

    [Fact]
    public void Constructor_ShouldThrow_WhenTabSpacesIsZeroOrLess()
    {
        // Arrange
        Action act = () => new StringCodeGenerator(0);

        // Act & Assert
        act.Should().Throw<ArgumentOutOfRangeException>()
            .WithMessage("*Tab spaces must be greater than 0.*");
    }

    [Fact]
    public async Task GenerateUsingAsync_ShouldReturnCorrectCode()
    {
        // Arrange
        var usingDirective = new Using { Name = "System.Text" };

        // Act
        var result = await _generator.GenerateUsingAsync(usingDirective);

        // Assert
        result.Should().Be("using System.Text;");
    }

    [Fact]
    public async Task GenerateStaticUsingAsync_ShouldReturnCorrectCode()
    {
        // Arrange
        var staticUsing = new StaticUsing
        {
            NewTypeName = "ConsoleAlias",
            OldTypeName = "System.Console"
        };

        // Act
        var result = await _generator.GenerateStaticUsingAsync(staticUsing);

        // Assert
        result.Should().Be("using static ConsoleAlias = System.Console;");
    }

    [Fact]
    public async Task GenerateParameterAsync_ShouldReturnCorrectCode()
    {
        // Arrange
        var parameter = new Parameter
        {
            Name = "count",
            TypeAsString = "int",
            Value = "5",
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>()
        };

        // Act
        var result = await _generator.GenerateParameterAsync(parameter);

        // Assert
        result.Should().Be("int count = 5");
    }

    [Fact]
    public async Task GenerateAttributeAsync_ShouldReturnSimpleAttribute_WhenNoLevelOrParameters()
    {
        // Arrange
        var attribute = new SharpCodeGenerator.Entities.Attribute
        {
            Type = typeof(ObsoleteAttribute),
            Parameters = new List<string>()
        };

        // Act
        var result = await _generator.GenerateAttributeAsync(attribute);

        // Assert
        result.Should().Be("[Obsolete]");
    }

    [Fact]
    public async Task GenerateAttributeAsync_ShouldReturnAttributeWithParametersAndLevel()
    {
        // Arrange
        var attribute = new SharpCodeGenerator.Entities.Attribute
        {
            Level = AttributeLevel.Assembly,
            Type = typeof(ObsoleteAttribute),
            Parameters = new List<string> { "\"message\"", "true" }
        };

        // Act
        var result = await _generator.GenerateAttributeAsync(attribute);

        // Assert
        result.Should().Be("[assembly: Obsolete(\"message\",true)]");
    }

    [Fact]
    public async Task GeneratePropertyAsync_ShouldReturnAutoProperty_WhenNoGetterOrSetter()
    {
        // Arrange
        var property = new Property
        {
            Name = "Id",
            TypeAsString = "int",
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>()
        };

        // Act
        var result = await _generator.GeneratePropertyAsync(property);

        // Assert
        result.Should().Contain("int Id { get; set; }");
    }

    [Fact]
    public async Task GenerateFileAsync_ShouldGenerateFileWithNamespace()
    {
        // Arrange
        var file = new SharpCodeGenerator.Entities.File
        {
            NamespaceName = "MyNamespace",
            Usings = new List<Using> { new Using { Name = "System" } },
            StaticUsings = new List<StaticUsing>(),
            Classes = new List<Class>(),
            Interfaces = new List<Interface>()
        };

        // Act
        var result = await _generator.GenerateFileAsync(file);

        // Assert
        result.Should().Contain("namespace MyNamespace;");
        result.Should().Contain("using System;");
    }

    [Fact]
    public async Task GenerateClassAsync_ShouldGenerateEmptyClassDefinition()
    {
        // Arrange
        var classDef = new Class
        {
            Name = "Person",
            AccessModifier = AccessModifier.Public,
            ClassModifiers = new List<ClassModifier>(),
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>(),
            Properties = new List<Property>(),
            Fields = new List<Field>(),
            Events = new List<Event>(),
            Methods = new List<Method>(),
            InheritedInterfaces = new List<Type>(),
        };

        // Act
        var result = await _generator.GenerateClassAsync(classDef);

        // Assert
        result.Should().Contain("public class Person");
        result.Should().Contain("{");
    }

    [Fact]
    public async Task GenerateInterfaceAsync_ShouldGenerateEmptyInterfaceDefinition()
    {
        // Arrange
        var interfaceDef = new Interface
        {
            Name = "IMyService",
            AccessModifier = AccessModifier.Public,
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>(),
            Properties = new List<Property>(),
            Events = new List<Event>(),
            Methods = new List<Method>(),
            InheritedInterfaces = new List<Type>()
        };

        // Act
        var result = await _generator.GenerateInterfaceAsync(interfaceDef);

        // Assert
        result.Should().Contain("public interface IMyService");
    }

    [Fact]
    public async Task GenerateMethodAsync_ShouldGenerateMethodWithContent()
    {
        // Arrange
        var method = new Method
        {
            Name = "SayHello",
            AccessModifier = AccessModifier.Public,
            MethodModifiers = new List<MethodModifier>(),
            ReturnType = typeof(void),
            Content = "Console.WriteLine(\"Hello\");",
            Parameters = new List<Parameter>(),
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>()
        };

        // Act
        var result = await _generator.GenerateMethodAsync(method);

        // Assert
        result.Should().Contain("public void SayHello()");
        result.Should().Contain("Console.WriteLine(\"Hello\");");
    }

    [Fact]
    public async Task GenerateMethodAsync_ShouldEndWithSemicolon_WhenIsInterface()
    {
        // Arrange
        var method = new Method
        {
            Name = "DoWork",
            AccessModifier = AccessModifier.Public,
            MethodModifiers = new List<MethodModifier>(),
            ReturnType = typeof(void),
            Content = null,
            Parameters = new List<Parameter>(),
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>()
        };

        // Act
        var result = await _generator.GenerateMethodAsync(method, isInterface: true);

        // Assert
        result.Should().EndWith(";");
    }

    [Fact]
    public async Task GenerateFieldAsync_ShouldGenerateCorrectField()
    {
        // Arrange
        var field = new Field
        {
            Name = "age",
            Type = typeof(int),
            Value = "30",
            AccessModifier = AccessModifier.Private,
            IsStatic = false,
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>()
        };

        // Act
        var result = await _generator.GenerateFieldAsync(field);

        // Assert
        result.Should().Contain("private int age = 30;");
    }

    [Fact]
    public async Task GenerateEventAsync_ShouldGenerateCorrectEvent()
    {
        // Arrange
        var @event = new Event
        {
            Name = "OnSomethingHappened",
            Type = typeof(EventHandler),
            AccessModifier = AccessModifier.Public,
            IsStatic = true,
            Attributes = new List<SharpCodeGenerator.Entities.Attribute>()
        };

        // Act
        var result = await _generator.GenerateEventAsync(@event);

        // Assert
        result.Should().Contain("public static EventHandler OnSomethingHappened;");
    }
}

