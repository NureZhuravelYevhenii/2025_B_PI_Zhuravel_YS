﻿using FluentAssertions;
using Relation;

namespace SubModuleHelpers.Tests;
public class RelationLoopDetectorTests
{
    [Fact]
    public void HasLoop_ShouldReturnFalse_WhenNoRelations()
    {
        // Arrange
        var relations = new List<RelationContent>();

        // Act
        var result = RelationLoopDetector.HasLoop(relations);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void HasLoop_ShouldReturnFalse_WhenNoCycleExists()
    {
        // Arrange
        var relations = new List<RelationContent>
        {
            CreateRelation("A", "B"),
            CreateRelation("B", "C"),
            CreateRelation("C", "D")
        };

        // Act
        var result = RelationLoopDetector.HasLoop(relations);

        // Assert
        result.Should().BeFalse();
    }

    [Fact]
    public void HasLoop_ShouldReturnTrue_WhenSimpleCycleExists()
    {
        // Arrange
        var relations = new List<RelationContent>
        {
            CreateRelation("A", "B"),
            CreateRelation("B", "C"),
            CreateRelation("C", "A")
        };

        // Act
        var result = RelationLoopDetector.HasLoop(relations);

        // Assert
        result.Should().BeTrue();
    }

    [Fact]
    public void HasLoop_ShouldReturnTrue_WhenMultipleCyclesExist()
    {
        // Arrange
        var relations = new List<RelationContent>
        {
            CreateRelation("A", "B"),
            CreateRelation("B", "C"),
            CreateRelation("C", "A"), // Cycle 1

            CreateRelation("D", "E"),
            CreateRelation("E", "D")  // Cycle 2
        };

        // Act
        var result = RelationLoopDetector.HasLoop(relations);

        // Assert
        result.Should().BeTrue();
    }

    [Fact]
    public void HasLoop_ShouldReturnTrue_WhenSelfReferenceExists()
    {
        // Arrange
        var relations = new List<RelationContent>
        {
            CreateRelation("A", "A")
        };

        // Act
        var result = RelationLoopDetector.HasLoop(relations);

        // Assert
        result.Should().BeTrue();
    }

    [Fact]
    public void HasLoop_ShouldHandleDisconnectedGraphs()
    {
        // Arrange
        var relations = new List<RelationContent>
        {
            CreateRelation("A", "B"),
            CreateRelation("C", "D"),
            CreateRelation("E", "F"),
            CreateRelation("F", "G"),
            CreateRelation("G", "E") // Only one component has a cycle
        };

        // Act
        var result = RelationLoopDetector.HasLoop(relations);

        // Assert
        result.Should().BeTrue();
    }

    private RelationContent CreateRelation(string baseEntity, string secondaryEntity, RelationType type = RelationType.OneToMany)
    {
        return new RelationContent
        {
            BaseEntity = baseEntity,
            SecondaryEntity = secondaryEntity,
            RelationType = type
        };
    }
}
