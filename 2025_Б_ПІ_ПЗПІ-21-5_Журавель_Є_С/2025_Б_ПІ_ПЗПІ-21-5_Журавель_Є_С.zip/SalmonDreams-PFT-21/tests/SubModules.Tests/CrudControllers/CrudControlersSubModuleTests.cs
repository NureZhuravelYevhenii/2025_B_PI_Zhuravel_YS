﻿using AspNet.Contents;
using MainAbstractions.Modules.Content;
using Entity;
using FluentAssertions;
using System.Reflection;
using CrudControllers;

namespace SubModules.Tests.CrudControllers;
public class CrudControllersSubModuleTests
{
    [Fact]
    public void EntityContentHandler_ShouldAddEntityController_WhenEntityContentIsHandled()
    {
        // Arrange
        var entityContent = new EntityContent
        {
            Name = "User"
        };

        var subModule = new CrudControllersSubModule();
        var contents = new List<IContent>();
        
        // Act
        var handlerMethod = typeof(CrudControllersSubModule)
            .GetMethod("EntityContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);

        handlerMethod!.Invoke(subModule, new object[] { entityContent, contents });

        // Assert
        var controllerContent = contents.OfType<ControllerContent>().FirstOrDefault();
        controllerContent.Should().NotBeNull();
        controllerContent!.Name.Should().Be("Users");
        controllerContent.Content.Should().Contain("User");
    }
}
