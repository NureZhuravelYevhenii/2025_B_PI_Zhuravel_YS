﻿using AspNet.Builders;
using DotNetModule.Entities;
using FluentAssertions;

namespace SubModules.Tests.AspNet;
public class ServiceRegistrationBuilderTests
{
    private readonly ServiceRegistrationBuilder _builder;

    public ServiceRegistrationBuilderTests()
    {
        _builder = new ServiceRegistrationBuilder();
    }

    [Fact]
    public void WithUsings_ShouldAddUsingsToContent()
    {
        // Arrange
        var usings = new List<string> { "using MyNamespace;", "using AnotherNamespace;" };

        // Act
        _builder.WithUsings(usings);
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain("using MyNamespace;");
        result.Content.Should().Contain("using AnotherNamespace;");
    }

    [Fact]
    public void WithAutofac_ShouldAddAutofacConfigurationToContent()
    {
        // Act
        _builder.WithAutofac();
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain("builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());");
    }

    [Fact]
    public void WithLocalization_ShouldAddLocalizationConfigurationToContent()
    {
        // Act
        _builder.WithLocalization();
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain("builder.Services.AddLocalization();");
        result.Content.Should().Contain("builder.Services.Configure<RequestLocalizationOptions>(options =>");
    }

    [Fact]
    public void WithSwagger_ShouldAddSwaggerConfigurationToContent()
    {
        // Act
        _builder.WithSwagger();
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain("builder.Services.AddEndpointsApiExplorer();");
        result.Content.Should().Contain("builder.Services.AddSwaggerGen();");
    }

    [Fact]
    public void WithCors_ShouldAddCorsConfigurationToContent()
    {
        // Act
        _builder.WithCors();
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain("builder.Services.AddCors(option =>");
        result.Content.Should().Contain("option.AddPolicy(name: MyAllowSpecificOrigins, builder =>");
    }

    [Fact]
    public void WithServiceRegistration_ShouldAddCustomServiceRegistrationToContent()
    {
        // Arrange
        var serviceRegistration = "builder.Services.AddSingleton<IMyService, MyService>();";

        // Act
        _builder.WithServiceRegistration(serviceRegistration);
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain(serviceRegistration);
    }

    [Fact]
    public void Build_ShouldGenerateCorrectFileContentWithAllConfigurations()
    {
        // Arrange
        var dependencies = new List<Dependency>
        {
            new Dependency { Include = "MyDependency", Version = "1.0.0" }
        };

        _builder.WithUsings(new[] { "using MyNamespace;" })
            .WithAutofac()
            .WithLocalization()
            .WithSwagger()
            .WithCors()
            .WithServiceRegistration("builder.Services.AddSingleton<IMyService, MyService>();")
            .WithDependencies(dependencies);

        // Act
        var result = _builder.Build();

        // Assert
        result.Content.Should().Contain("using MyNamespace;");
        result.Content.Should().Contain("builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());");
        result.Content.Should().Contain("builder.Services.AddLocalization();");
        result.Content.Should().Contain("builder.Services.AddEndpointsApiExplorer();");
        result.Content.Should().Contain("builder.Services.AddCors(option =>");
        result.Content.Should().Contain("builder.Services.AddSingleton<IMyService, MyService>();");

        result.Dependencies.Should().ContainSingle()
            .Which.Should().BeEquivalentTo(new Dependency { Include = "MyDependency", Version = "1.0.0" });
    }

    [Fact]
    public void Build_ShouldGenerateFileContentWithCorrectLocation()
    {
        // Act
        var result = _builder.Build();

        // Assert
        result.Location.Should().Be("Web/Middleware/MiddlewareExtensions.cs");
    }
}
