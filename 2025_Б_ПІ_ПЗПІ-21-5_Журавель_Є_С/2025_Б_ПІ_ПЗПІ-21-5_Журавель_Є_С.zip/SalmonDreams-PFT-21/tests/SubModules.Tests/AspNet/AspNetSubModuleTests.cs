﻿using AspNet.Contents;
using AspNet;
using DotNetModule.Contents;
using DotNetModule.Entities;
using MainAbstractions.Modules.Content;
using System.Reflection;
using FluentAssertions;

namespace SubModules.Tests.AspNet;
public class AspNetSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldGenerateExpectedFiles()
    {
        // Arrange
        var subModule = new AspNetSubModule();

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.OfType<FileContent>().Should().Contain(x => x.Location == "Web/Startup.cs");
        result.OfType<FileContent>().Should().Contain(x => x.Location == "Web/appsettings.json");
        result.OfType<FileContent>().Should().Contain(x => x.Location == "Web/Properties/launchSettings.json");
        result.OfType<ProjectRelationContent>().Should().ContainSingle();
    }

    [Fact]
    public async Task StartupContentHandler_ShouldAddDependenciesAndUsingsAndMiddleware()
    {
        // Arrange
        var subModule = new AspNetSubModule();
        var content = new StartupContent
        {
            Dependencies = new[] { new Dependency { Include = "Test.Dependency", Version = "1.0.0" } },
            Usings = new[] { "using Test.Namespace;" },
            MiddlewareRegistration = "app.UseTest();"
        };

        // Act
        var method = typeof(AspNetSubModule).GetMethod("StartupContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        await (Task)method!.Invoke(subModule, new object[] { content, Enumerable.Empty<IContent>() })!;

        // Assert
        var files = (await subModule.ParseInCodeAsync()).ToList();
        var startup = files
            .OfType<FileContent>()
            .FirstOrDefault(x => x.Location == "Web/Startup.cs");

        startup.Should().NotBeNull();
        startup!.Content.Should().Contain("app.UseTest()");
        startup.Content.Should().Contain("using Test.Namespace;");
    }

    [Fact]
    public async Task ControllerContentHandler_ShouldGenerateControllerFile()
    {
        // Arrange
        var subModule = new AspNetSubModule();
        var contents = new List<IContent>();
        var controllerContent = new ControllerContent
        {
            Name = "Test",
            Content = "// test controller"
        };

        // Act
        var method = typeof(AspNetSubModule).GetMethod("ControllerContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        await (Task)method!.Invoke(subModule, new object[] { controllerContent, contents })!;

        // Assert
        var controllerFile = contents
            .OfType<FileContent>()
            .FirstOrDefault(x => x.Location == "Web/Controllers/TestController.cs");

        controllerFile.Should().NotBeNull();
        controllerFile!.Content.Should().Be("// test controller");
    }

    [Fact]
    public async Task AppSettingsContentHandler_ShouldGenerateCorrectAppSettingsJson()
    {
        // Arrange
        var subModule = new AspNetSubModule();
        var appSettingsContent = new AppSettingsContent
        {
            Title = "MySettings",
            Object = typeof(SampleAppSettings)
        };

        // Act
        var method = typeof(AspNetSubModule).GetMethod("AppSettingsContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        await (Task)method!.Invoke(subModule, new object[] { appSettingsContent, Enumerable.Empty<IContent>() })!;

        // Assert
        var result = (await subModule.ParseInCodeAsync()).ToList();
        var appSettingsFile = result
            .OfType<FileContent>()
            .FirstOrDefault(x => x.Location == "Web/appsettings.json");

        appSettingsFile.Should().NotBeNull();
        appSettingsFile!.Content.Should().Contain("\"MySettings\":");
        appSettingsFile.Content.Should().Contain("\"SomeProperty\":");
    }

    private class SampleAppSettings
    {
        public string SomeProperty { get; set; } = "default";
    }
}
