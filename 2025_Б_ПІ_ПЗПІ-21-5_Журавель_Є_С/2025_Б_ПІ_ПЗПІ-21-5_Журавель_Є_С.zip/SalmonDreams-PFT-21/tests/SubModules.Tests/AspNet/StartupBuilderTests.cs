﻿using AspNet.Builders;
using DotNetModule.Entities;
using FluentAssertions;

namespace SubModules.Tests.AspNet;
public class StartupBuilderTests
{
    [Fact]
    public void WithUsings_ShouldAddUsingsToContent()
    {
        // Arrange
        var builder = new StartupBuilder();
        var usings = new List<string> { "using MyNamespace;", "using AnotherNamespace;" };

        // Act
        builder.WithUsings(usings);
        var result = builder.Build();

        // Assert
        result.Content.Should().Contain("using MyNamespace;");
        result.Content.Should().Contain("using AnotherNamespace;");
    }

    [Fact]
    public void WithMiddleware_ShouldAddMiddlewareToContent()
    {
        // Arrange
        var builder = new StartupBuilder();
        var middleware = "app.UseMyCustomMiddleware();";

        // Act
        builder.WithMiddleware(middleware);
        var result = builder.Build();

        // Assert
        result.Content.Should().Contain("app.UseMyCustomMiddleware();");
    }

    [Fact]
    public void WithDependencies_ShouldAddDependenciesToFileContent()
    {
        // Arrange
        var builder = new StartupBuilder();
        var dependencies = new List<Dependency>
        {
            new Dependency { Include = "MyDependency", Version = "1.0.0" }
        };

        // Act
        builder.WithDependencies(dependencies);
        var result = builder.Build();

        // Assert
        result.Dependencies.Should().ContainSingle()
            .Which.Should().BeEquivalentTo(new Dependency { Include = "MyDependency", Version = "1.0.0" });
    }

    [Fact]
    public void Build_ShouldGenerateCorrectFileContentWithAllConfigurations()
    {
        // Arrange
        var builder = new StartupBuilder();
        var dependencies = new List<Dependency>
        {
            new Dependency { Include = "MyDependency", Version = "1.0.0" }
        };

        builder.WithUsings(new[] { "using MyNamespace;" })
            .WithMiddleware("app.UseMyCustomMiddleware();")
            .WithDependencies(dependencies);

        // Act
        var result = builder.Build();

        // Assert
        result.Content.Should().Contain("using MyNamespace;");
        result.Content.Should().Contain("app.UseMyCustomMiddleware();");
        result.Content.Should().Contain("app.MapControllers();");
        result.Content.Should().Contain("app.UseRouting();");
        result.Content.Should().Contain("app.UseHttpsRedirection();");
        result.Content.Should().Contain("app.UseCors(builder => builder.AllowAnyHeader().AllowAnyHeader().AllowAnyOrigin());");

        result.Dependencies.Should().ContainSingle()
            .Which.Should().BeEquivalentTo(new Dependency { Include = "MyDependency", Version = "1.0.0" });
    }

    [Fact]
    public void Build_ShouldGenerateFileContentWithCorrectLocation()
    {
        // Arrange
        var builder = new StartupBuilder();

        // Act
        var result = builder.Build();

        // Assert
        result.Location.Should().Be("Web/Startup.cs");
    }

    [Fact]
    public void Build_ShouldContainSwaggerConfigurationInDevelopmentEnvironment()
    {
        // Arrange
        var builder = new StartupBuilder();

        // Act
        builder.WithMiddleware("app.UseMyCustomMiddleware();");
        var result = builder.Build();

        // Assert
        result.Content.Should().Contain("if (app.Environment.IsDevelopment())");
        result.Content.Should().Contain("app.UseSwagger();");
        result.Content.Should().Contain("app.UseSwaggerUI();");
    }
}
