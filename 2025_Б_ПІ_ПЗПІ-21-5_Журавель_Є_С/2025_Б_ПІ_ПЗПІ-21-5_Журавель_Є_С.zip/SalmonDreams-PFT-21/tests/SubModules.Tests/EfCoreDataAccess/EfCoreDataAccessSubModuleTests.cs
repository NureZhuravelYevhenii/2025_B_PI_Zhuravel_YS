﻿using AspNet.Contents;
using DotNetModule.Contents;
using EfCoreDataAccess;
using Entity;
using FluentAssertions;
using MainAbstractions.Modules.Content;
using Property;
using System.Reflection;

namespace SubModules.Tests.EfCoreDataAccess;
public class EfCoreDataAccessSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldReturnExpectedFiles_WhenFilesAreGenerated()
    {
        // Arrange
        var subModule = new EfCoreDataAccessSubModule();

        var entityContent = new EntityContent
        {
            Name = "Product",
            Properties = new[]
            {
                new PropertyContent { Name = "Id", PropertyType = PropertyType.Int },
                new PropertyContent { Name = "Title", PropertyType = PropertyType.String }
            }
        };

        var contents = new List<IContent>();
        var handlerMethod = typeof(EfCoreDataAccessSubModule)
            .GetMethod("EntityContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);

        handlerMethod!.Invoke(subModule, new object[] { entityContent, contents });

        // Act
        var result = (await subModule.ParseInCodeAsync(CancellationToken.None)).ToList();

        // Assert
        result.OfType<AppSettingsContent>().Should().ContainSingle();
        result.OfType<ServiceRegistrationContent>().Should().ContainSingle();

        var files = result.OfType<FileContent>().ToList();
        files.Should().Contain(f => f.Location == "DAL/BaseDbContext.cs");
        files.Should().Contain(f => f.Location == "DAL/Entities/Product.cs");
        files.Should().Contain(f => f.Location == "DAL/Entities/BaseEntities/BaseEntity.cs");
        files.Should().Contain(f => f.Location == "DAL/Abstractions/IRepository.cs");
        files.Should().Contain(f => f.Location == "DAL/Abstractions/Repository.cs");
        files.Should().Contain(f => f.Location == "DAL/DesignTimeTypes/DesignTimeFactory.cs");
        files.Should().Contain(f => f.Location == "DAL/appsettings.json");
    }
}
