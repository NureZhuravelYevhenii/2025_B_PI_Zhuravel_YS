﻿using DotNetModule.Contents;
using Entity;
using EntityModel;
using FluentAssertions;
using MainAbstractions.Modules.Content;
using Property;
using Services;
using System.Reflection;

namespace SubModules.Tests.Services;
public class ServicesSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldReturnExpectedGeneratedContent_WhenCalled()
    {
        // Arrange
        var subModule = new ServicesSubModule();
        var entityContent = new EntityContent
        {
            Name = "User",
            Properties = new List<PropertyContent>
            {
                new PropertyContent { Name = "Username", PropertyType = PropertyType.String },
                new PropertyContent { Name = "Email", PropertyType = PropertyType.String }
            }
        };
        var model = new EntityModelContent
        {
            Name = "User",
            Properties = entityContent.Properties
        };

        var entityHandlerMethod = typeof(ServicesSubModule)
           .GetMethod("EntityContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        entityHandlerMethod?.Invoke(subModule, new object[] { entityContent, new List<IContent>() });

        var entityModelHandlerMethod = typeof(ServicesSubModule)
           .GetMethod("EntityContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        entityModelHandlerMethod?.Invoke(subModule, new object[] { entityContent, new List<IContent>() });

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        var fileContents = result.OfType<FileContent>().ToList();

        fileContents.Should().Contain(fc => fc.Location == "BLL/Services/BaseServices/BaseCrudService.cs");
        fileContents.Should().Contain(fc => fc.Location == "BLL/Abstractions/Services/BaseServices/ICrudService.cs");
        fileContents.Should().Contain(fc => fc.Location == "BLL/Entities/UserModels/UserModel.cs");
        fileContents.Should().Contain(fc => fc.Location == "BLL/Entities/UserModels/UserCreationModel.cs");
        fileContents.Should().Contain(fc => fc.Location == "BLL/Entities/UserModels/UserUpdateModel.cs");
        fileContents.Should().Contain(fc => fc.Location == "BLL/Entities/UserModels/UserIdModel.cs");
    }
}
