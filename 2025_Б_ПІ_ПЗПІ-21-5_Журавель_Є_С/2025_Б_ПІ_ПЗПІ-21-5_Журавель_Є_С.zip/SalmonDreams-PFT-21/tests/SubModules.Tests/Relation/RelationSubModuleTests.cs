﻿using FluentAssertions;
using Relation;

namespace SubModules.Tests.Relation;
public class RelationSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldAppendRelationContentToBaseContents()
    {
        // Arrange
        var properties = new RelationProperties
        {
            PrimaryEntity = "User",
            SecondaryEntity = "Order",
            RelationType = RelationType.OneToMany
        };

        var subModule = new RelationSubModule
        {
            Properties = properties
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(1);

        var relation = result.OfType<RelationContent>().FirstOrDefault();
        relation.Should().NotBeNull();
        relation!.BaseEntity.Should().Be("User");
        relation.SecondaryEntity.Should().Be("Order");
        relation.RelationType.Should().Be(RelationType.OneToMany);
    }

    [Fact]
    public async Task ParseInCodeAsync_ThrowsException_WhenPropertiesAreNull()
    {
        // Arrange
        var subModule = new RelationSubModule
        {
            Properties = null!
        };

        // Act & Assert
        await FluentActions.Invoking(() => subModule.ParseInCodeAsync())
            .Should().ThrowAsync<ArgumentNullException>();
    }
}
