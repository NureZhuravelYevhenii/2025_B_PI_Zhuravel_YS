﻿using Entity;
using EntityModel;
using FluentAssertions;
using MainAbstractions.Modules;
using MainAbstractions.Modules.Content;
using Moq;
using Property;

namespace SubModules.Tests.EntityModel;
public class EntityModelSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldProcessesEntityContent_WithMatchingProperties()
    {
        // Arrange
        var properties = new EntityModelProperties
        {
            Properties = new List<string> { "Id", "Name" }
        };

        var entityContent = new EntityContent
        {
            Name = "Customer",
            Properties = new List<PropertyContent>
            {
                new() { Name = "Id", PropertyType = PropertyType.Int },
                new() { Name = "Name", PropertyType = PropertyType.String },
                new() { Name = "Ignored", PropertyType = PropertyType.Bool }
            }
        };

        var mockSubModule = new Mock<ISubModule>();
        mockSubModule
            .Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { entityContent });

        var subModule = new EntityModelSubModule
        {
            Properties = properties,
            Modules = new[] { mockSubModule.Object }
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        var modelContent = result.OfType<EntityModelContent>().Should().ContainSingle().Subject;
        modelContent.Name.Should().Be("Customer");

        var props = modelContent.Properties.ToList();
        props.Should().HaveCount(2);
        props.Should().Contain(p => p.Name == "Id");
        props.Should().Contain(p => p.Name == "Name");
        props.Should().NotContain(p => p.Name == "Ignored");
    }
}
