﻿using FluentAssertions;
using Property;

namespace SubModules.Tests.Property;
public class PropertySubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldReturnPropertyContent_WhenPropertiesAreSet()
    {
        // Arrange
        var propertyProps = new PropertyProperties
        {
            Name = "  MyProperty",
            Type = PropertyType.String
        };

        var sut = new PropertySubModule
        {
            Properties = propertyProps
        };

        // Act
        var result = (await sut.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(1);

        var propertyContent = result.First() as PropertyContent;
        propertyContent.Should().NotBeNull();
        propertyContent!.Name.Should().Be("MyProperty");
        propertyContent.PropertyType.Should().Be(PropertyType.String);
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldReturnEmptyList_WhenPropertiesAreNull()
    {
        // Arrange
        var sut = new PropertySubModule
        {
            Properties = null!
        };

        // Act
        var result = await sut.ParseInCodeAsync();

        // Assert
        result.Should().BeEmpty();
    }
}

