﻿using Entity;
using FluentAssertions;
using JwtIdentityEntity;
using MainAbstractions.Modules;
using MainAbstractions.Modules.Content;
using Moq;
using Property;

namespace SubModules.Tests.JwtIdentityEntity;
public class JwtIdentityEnttitySubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldModifyEntityAndAddJwt_WhenClaimsPresent()
    {
        // Arrange
        var inputEntity = new EntityContent
        {
            Name = "Admin",
            Properties = new List<PropertyContent>
            {
                new() { Name = "Id", PropertyType = PropertyType.Int }
            }
        };

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
               .ReturnsAsync(new List<IContent> { inputEntity });

        var props = new JwtIdentityEntityProperties
        {
            ClaimsForAccessToken = new[] { "Id", "Role" },
            ClaimsForRefreshToken = new[] { "Email" }
        };

        var subModule = new JwtIdentityEnttitySubModule
        {
            Properties = props,
            Modules = new List<ISubModule>(){ mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(2);

        result[0].Should().BeOfType<EntityContent>()
              .Which.Properties.Should().Contain(p => p.Name == "RefreshToken");

        var jwtContent = result[1].Should().BeOfType<JwtIdentityEntityContent>().Subject;
        jwtContent.Name.Should().Be("Admin");
        jwtContent.AccessTokenClaimProperties.Should().Contain(c => c.Name == "Id")
                                               .And.Contain(c => c.Name == "Role");
        jwtContent.RefreshTokenClaimProperties.Should().ContainSingle(c => c.Name == "Email");
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldIgnoreNonEntityContent()
    {
        // Arrange
        var nonEntityContent = new Mock<IContent>().Object;

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
               .ReturnsAsync(new List<IContent> { nonEntityContent });

        var props = new JwtIdentityEntityProperties
        {
            ClaimsForAccessToken = new[] { "Id" }
        };

        var subModule = new JwtIdentityEnttitySubModule
        {
            Properties = props,
            Modules = new List<ISubModule>() { mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().ContainSingle()
              .Which.Should().BeSameAs(nonEntityContent);
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldHandleMultipleEntitiesWithJwt()
    {
        // Arrange
        var entity1 = new EntityContent { Name = "User", Properties = new List<PropertyContent>() };
        var entity2 = new EntityContent { Name = "Admin", Properties = new List<PropertyContent>() };

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
               .ReturnsAsync(new List<IContent> { entity1, entity2 });

        var props = new JwtIdentityEntityProperties
        {
            ClaimsForAccessToken = new[] { "Name" },
            ClaimsForRefreshToken = new[] { "Email" }
        };

        var subModule = new JwtIdentityEnttitySubModule
        {
            Properties = props,
            Modules = new List<ISubModule>() { mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(4);

        result.OfType<EntityContent>().Should().AllSatisfy(ec =>
        {
            ec.Properties.Should().Contain(p => p.Name == "RefreshToken");
        });

        result.OfType<JwtIdentityEntityContent>().Should().AllSatisfy(jwt =>
        {
            jwt.AccessTokenClaimProperties.Should().Contain(p => p.Name == "Name");
            jwt.RefreshTokenClaimProperties.Should().Contain(p => p.Name == "Email");
        });
    }
}
