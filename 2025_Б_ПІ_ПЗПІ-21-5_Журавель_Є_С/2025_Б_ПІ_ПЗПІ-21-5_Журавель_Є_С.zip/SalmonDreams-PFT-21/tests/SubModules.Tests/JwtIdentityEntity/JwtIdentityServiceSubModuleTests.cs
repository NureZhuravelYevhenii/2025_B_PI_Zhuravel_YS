﻿using AspNet.Contents;
using DotNetModule.Contents;
using JwtIdentityEntity;
using JwtIdentityEntityServices;
using MainAbstractions.Modules.Content;
using FluentAssertions;
using System.Reflection;

namespace SubModules.Tests.JwtIdentityEntity;
public class JwtIdentityServiceSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldIncludeJwtManagerFilesAndRegistration()
    {
        // Arrange
        var subModule = new JwtIdentityServiceSubModule();

        // Act
        var result = await subModule.ParseInCodeAsync();

        // Assert
        result.OfType<FileContent>()
            .Should().Contain(r => r.Location == "Common/Configurations/JwtConfiguration.cs");

        result.OfType<ServiceRegistrationContent>()
            .Should().Contain(r => r.ServiceRegistration.Contains("AddScoped<IJwtManager, JwtManager>"));
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldIncludeStartupContent()
    {
        // Arrange
        var subModule = new JwtIdentityServiceSubModule();

        // Act
        var result = await subModule.ParseInCodeAsync();

        // Assert
        var startupContent = result.Should().ContainSingle(r => r is StartupContent).Subject as StartupContent;
        startupContent!.MiddlewareRegistration.Should().Contain("app.UseAuthentication();");
        startupContent.MiddlewareRegistration.Should().Contain("app.UseAuthorization();");
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldIncludeJwtEntityContentHandler()
    {
        // Arrange
        var subModule = new JwtIdentityServiceSubModule();
        var jwtEntity = new JwtIdentityEntityContent { Name = "User" };
        var contents = new List<IContent>();

        // Act
        var handlerMethod = typeof(JwtIdentityServiceSubModule).GetMethod("JwtIdentityEntityContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        await (Task)handlerMethod!.Invoke(subModule, new object[] { jwtEntity, contents })!;

        // Assert
        contents.OfType<FileContent>()
          .Should().ContainSingle(c => c.Location == "BLL/Entities/Identity/LoginUserModel.cs");

        contents.OfType<FileContent>()
                .Should().Contain(c => c.Location == "BLL/Entities/Identity/RegisterUserModel.cs");

        contents.OfType<ServiceRegistrationContent>()
                .Should().Contain(c => c.ServiceRegistration.Contains("builder.Services.AddScoped<IJwtUserIdentityService"));
    }
}
