﻿using AspNet.Contents;
using DotNetModule.Contents;
using JwtControllers;
using JwtIdentityEntity;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules;
using Moq;
using FluentAssertions;

namespace SubModules.Tests.JwtIdentityEntity;
public class JwtControllersSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldReturnExpectedContents_WhenPropertiesAreValid()
    {
        // Arrange
        var jwtControllerContent = new ControllerContent
        {
            Name = "Identity/EntityJwtController.cs",
            Content = "Some controller content"
        };

        var tokenModelContent = new FileContent
        {
            Location = "Web/Entities/Jwt/Token.cs",
            Content = "Some token model content"
        };

        var jwtHttpConstantsContent = new FileContent
        {
            Location = "Common/Constants/JwtHttpConstants.cs",
            Content = "Some HTTP constants content"
        };

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { jwtControllerContent });

        var subModule = new JwtControllersSubModule
        {
            Modules = new List<ISubModule>() { mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(3);

        result[0].Should().BeOfType<ControllerContent>()
            .Which.Name.Should().Be("Identity/EntityJwtController.cs");

        result[1].Should().BeOfType<FileContent>()
            .Which.Location.Should().Be("Common/Constants/JwtHttpConstants.cs");

        result[2].Should().BeOfType<FileContent>()
            .Which.Location.Should().Be("Web/Entities/Jwt/Token.cs");
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldAddEntityController_WhenJwtIdentityEntityContentHandlerIsInvoked()
    {
        // Arrange
        var entityJwtContent = new JwtIdentityEntityContent
        {
            Name = "User"
        };

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { entityJwtContent });

        var subModule = new JwtControllersSubModule
        {
            Modules = new List<ISubModule>() { mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.OfType<ControllerContent>()
          .Should().Contain(x => x.Name.Contains("User"));

        result.OfType<JwtIdentityEntityContent>()
              .Should().Contain(x => x.Name == "User");
    }
}
