﻿using MainAbstractions.Modules.Content;
using Moq;
using MainAbstractions.Modules;
using Property;
using Entity;
using FluentAssertions;

namespace SubModules.Tests.Entity;
public class EntitySubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_AppendsEntityContent_WhenPropertiesAreSet()
    {
        // Arrange
        var entityProps = new EntityProperties
        {
            Name = "MyEntity"
        };

        var prop1 = new PropertyContent { Name = "Prop1" };
        var prop2 = new PropertyContent { Name = "Prop2" };

        var subModuleMock = new Mock<ISubModule>();
        subModuleMock
            .Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { prop1, prop2 });

        var entitySubModule = new EntitySubModule
        {
            Properties = entityProps,
            Modules = new[] { subModuleMock.Object }
        };

        // Act
        var result = (await entitySubModule.ParseInCodeAsync()).ToList();

        // Assert
        var entityContent = result.OfType<EntityContent>().FirstOrDefault();
        entityContent.Should().NotBeNull();
        entityContent!.Name.Should().Be("MyEntity");
        entityContent.Properties.Should().HaveCount(2);
        entityContent.Properties.Should().Contain(prop1);
        entityContent.Properties.Should().Contain(prop2);
    }

    [Fact]
    public async Task ParseInCodeAsync_ThrowsArgumentNullException_WhenPropertiesAreNull()
    {
        // Arrange
        var prop1 = new PropertyContent { Name = "Prop1" };

        var subModuleMock = new Mock<ISubModule>();
        subModuleMock
            .Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { prop1 });

        var sut = new EntitySubModule
        {
            Properties = null!,
            Modules = new[] { subModuleMock.Object }
        };

        // Act & Assert
        await FluentActions.Invoking(() => sut.ParseInCodeAsync())
            .Should()
            .ThrowAsync<ArgumentNullException>();
    }
}
