﻿using AspNet.Contents;
using AutomapperRegistration;
using FluentAssertions;
using MainAbstractions.Modules.Content;
using System.Reflection;

namespace SubModules.Tests.AutomapperRegistration;
public class AutomapperRegistrationSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldRegisterProfilesAndReturnServiceRegistrationContent()
    {
        // Arrange
        var subModule = new AutomapperRegistrationSubModule();
        var automapperContent = new AutomapperRegistrationContent
        {
            AutomapperAssemblies = new[] { "Project.App", "Project.Core" }
        };

        var handlerMethod = typeof(AutomapperRegistrationSubModule)
            .GetMethod("AutomapperContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        handlerMethod?.Invoke(subModule, new object[] { automapperContent, new List<IContent>() });

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(1);
        result[0].Should().BeOfType<ServiceRegistrationContent>();

        var registration = result[0].As<ServiceRegistrationContent>().ServiceRegistration;

        registration.Should().Contain("cfg.AddMaps(new[]");
        registration.Should().Contain("\"Project.App\"");
        registration.Should().Contain("\"Project.Core\"");
        registration.Should().Contain("builder.Services.AddSingleton(mapper);");
    }
}

