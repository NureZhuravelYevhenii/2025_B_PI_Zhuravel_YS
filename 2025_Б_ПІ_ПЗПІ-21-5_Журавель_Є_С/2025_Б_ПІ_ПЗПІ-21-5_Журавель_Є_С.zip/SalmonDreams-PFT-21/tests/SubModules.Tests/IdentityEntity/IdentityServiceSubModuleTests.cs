﻿using FluentAssertions;
using AspNet.Contents;
using DotNetModule.Contents;
using IdentityEntity;
using MainAbstractions.Modules.Content;
using IdentityServices;
using System.Reflection;

namespace SubModules.Tests.IdentityEntity;
public class IdentityServiceSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldIncludeHashHelper_WhenExecuted()
    {
        // Arrange
        var subModule = new IdentityServiceSubModule();

        // Act
        var resultList = await subModule.ParseInCodeAsync(CancellationToken.None);

        // Assert
        resultList.OfType<FileContent>().Should().ContainSingle(content => content.Location.EndsWith("HashHelper.cs"));
    }

    [Fact]
    public async Task IdentityEntityContentHandler_ShouldReturnAllExpectedContents_WhenExecuted()
    {
        // Arrange
        var subModule = new IdentityServiceSubModule();
        var contents = new List<IContent>();
        var identityEntity = new IdentityEntityContent { Name = "User" };

        // Act
        var handlerMethod = typeof(IdentityServiceSubModule).GetMethod("IdentityEntityContentHandler", BindingFlags.NonPublic | BindingFlags.Instance);
        await (Task)handlerMethod!.Invoke(subModule, new object[] { identityEntity, contents })!;

        // Assert
        contents.OfType<FileContent>().Should().ContainSingle(fc => fc.Location == "BLL/Entities/Identity/LoginUserModel.cs");
        contents.OfType<FileContent>().Should().ContainSingle(fc => fc.Location == "BLL/Entities/Identity/RegisterUserModel.cs");
        contents.OfType<FileContent>().Should().ContainSingle(fc => fc.Location == "BLL/Services/Identity/UserIdentityService.cs");
        contents.OfType<FileContent>().Should().ContainSingle(fc => fc.Location == "BLL/Abstractions/Identity/IUserIdentityService");
        contents.OfType<FileContent>().Should().ContainSingle(fc => fc.Location == "BLL/Infrastructure/Automapper/Identity/UserIdentityProfile.cs");

        contents.OfType<ServiceRegistrationContent>().Should()
            .ContainSingle(s => s.ServiceRegistration.Contains("AddScoped<IUserEntityIdentityService"));
    }
}
