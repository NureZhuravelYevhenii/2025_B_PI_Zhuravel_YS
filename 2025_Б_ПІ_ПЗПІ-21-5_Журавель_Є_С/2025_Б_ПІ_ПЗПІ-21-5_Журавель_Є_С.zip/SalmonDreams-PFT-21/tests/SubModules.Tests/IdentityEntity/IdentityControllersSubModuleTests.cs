﻿using AspNet.Contents;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules;
using Moq;
using FluentAssertions;
using IdentityControllers;
using IdentityEntity;

namespace SubModules.Tests.IdentityEntity;
public class IdentityControllersSubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldReturnExpectedContents_WhenPropertiesAreValid()
    {
        // Arrange
        var identityControllerContent = new ControllerContent
        {
            Name = "Identity/EntityAuthController.cs",
            Content = "Some controller content"
        };

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { identityControllerContent });

        var subModule = new IdentityControllersSubModule
        {
            Modules = new List<ISubModule>() { mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(1);

        result[0].Should().BeOfType<ControllerContent>()
            .Which.Name.Should().Be("Identity/EntityAuthController.cs");
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldAddEntityController_WhenIdentityEntityContentHandlerIsInvoked()
    {
        // Arrange
        var entityContent = new IdentityEntityContent
        {
            Name = "User"
        };

        var mockSub = new Mock<ISubModule>();
        mockSub.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { entityContent });

        var subModule = new IdentityControllersSubModule
        {
            Modules = new List<ISubModule>() { mockSub.Object },
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().Contain(x => x is ControllerContent && ((ControllerContent)x).Name.Contains("User"));
        result.Should().Contain(x => x is IdentityEntityContent && ((IdentityEntityContent)x).Name == "User");
    }
}
