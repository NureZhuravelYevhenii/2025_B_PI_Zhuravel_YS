﻿using Entity;
using FluentAssertions;
using IdentityEntity;
using MainAbstractions.Modules;
using MainAbstractions.Modules.Content;
using Moq;
using Property;

namespace SubModules.Tests.IdentityEntity;
public class IdentityEntitySubModuleTests
{
    [Fact]
    public async Task ParseInCodeAsync_ShouldAppendIdentityContentAndUpdatedEntity_WhenEntityContentExists()
    {
        // Arrange
        var props = new IdentityEntityProperties
        {
            LoginProperty = "Email",
            IfSpecifiedPropertyNotExistsCreate = true
        };

        var entity = new EntityContent
        {
            Name = "User",
            Properties = new List<PropertyContent>
            {
                new() { Name = "Id", PropertyType = PropertyType.Int }
            }
        };

        var mockSub = new Mock<ISubModule>();
        mockSub
            .Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { entity });

        var subModule = new IdentityEntitySubModule
        {
            Properties = props,
            Modules = new List<ISubModule>() { mockSub.Object }
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(2);

        var updatedEntity = result.OfType<EntityContent>().First();
        var identityEntity = result.OfType<IdentityEntityContent>().First();

        updatedEntity.Name.Should().Be("User");
        updatedEntity.Properties.Should().Contain(p => p.Name == "Email");
        updatedEntity.Properties.Should().Contain(p => p.Name == "PasswordHash");
        updatedEntity.Properties.Should().Contain(p => p.Name == "PasswordSalt");

        identityEntity.Name.Should().Be("User");
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldDoNotDuplicateLogin_WhenAlreadyExists()
    {
        // Arrange
        var props = new IdentityEntityProperties
        {
            LoginProperty = "Email",
            IfSpecifiedPropertyNotExistsCreate = true
        };

        var entity = new EntityContent
        {
            Name = "Admin",
            Properties = new List<PropertyContent>
            {
                new() { Name = "Email", PropertyType = PropertyType.String }
            }
        };

        var mockSub = new Mock<ISubModule>();
        mockSub
            .Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { entity });

        var subModule = new IdentityEntitySubModule
        {
            Properties = props,
            Modules = new List<ISubModule>() { mockSub.Object }
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        var updatedEntity = result.OfType<EntityContent>().First();
        var loginProps = updatedEntity.Properties.Where(p => p.Name == "Email").ToList();

        loginProps.Should().HaveCount(1);
    }

    [Fact]
    public async Task ParseInCodeAsync_ShouldSkipNonEntityContent()
    {
        // Arrange
        var props = new IdentityEntityProperties();
        var nonEntity = new Mock<IContent>().Object;

        var mockSub = new Mock<ISubModule>();
        mockSub
            .Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(new List<IContent> { nonEntity });

        var subModule = new IdentityEntitySubModule
        {
            Properties = props,
            Modules = new List<ISubModule>() { mockSub.Object }
        };

        // Act
        var result = (await subModule.ParseInCodeAsync()).ToList();

        // Assert
        result.Should().HaveCount(1);
        result[0].Should().BeSameAs(nonEntity);
    }
}
