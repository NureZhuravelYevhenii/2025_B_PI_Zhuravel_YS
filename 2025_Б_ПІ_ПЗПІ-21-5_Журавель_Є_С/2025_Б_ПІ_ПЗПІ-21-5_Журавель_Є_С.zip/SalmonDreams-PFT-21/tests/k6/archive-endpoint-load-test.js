import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 300,
  duration: '1m',
};

const url = 'http://localhost:5276/api/project-generator/text/archive';

const requestBody = {
  text: JSON.stringify([
    {
      name: "DotNet",
      properties: { projectName: "TestApp" },
      modules: [
        {
          name: "AspNet",
          modules: [
            {
              name: "AutomapperRegistration",
              modules: [
                {
                  name: "JwtControllers",
                  modules: [
                    {
                      name: "CrudControllers",
                      modules: [
                        {
                          name: "JwtIdentityServices",
                          modules: [
                            {
                              name: "Services",
                              modules: [
                                {
                                  name: "EfCoreDataAccess",
                                  modules: [
                                    {
                                      name: "JwtIdentityEntity",
                                      modules: [
                                        {
                                          name: "IdentityEntity",
                                          properties: { loginProperty: "Login" },
                                          modules: [
                                            {
                                              name: "EntityModel",
                                              properties: { properties: ["Name"] },
                                              modules: [
                                                {
                                                  name: "Entity",
                                                  properties: { name: "Test" },
                                                  modules: [
                                                    {
                                                      name: "Property",
                                                      properties: { name: "Name", type: "String" }
                                                    }
                                                  ]
                                                }
                                              ]
                                            }
                                          ]
                                        }
                                      ]
                                    }
                                  ]
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  ]),
  markupType: "json"
};

const params = {
  headers: {
    'Content-Type': 'application/json',
  },
};

export default function () {
  const response = http.post(url, JSON.stringify(requestBody), params);

  check(response, {
    'response code is 200': (res) => res.status === 200,
  });

  sleep(1);
}
