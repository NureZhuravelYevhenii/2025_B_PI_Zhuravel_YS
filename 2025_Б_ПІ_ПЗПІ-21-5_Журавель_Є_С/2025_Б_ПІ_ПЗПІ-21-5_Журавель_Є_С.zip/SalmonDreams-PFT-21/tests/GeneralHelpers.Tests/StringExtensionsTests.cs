﻿using FluentAssertions;

namespace GeneralHelpers.Tests;
public class StringExtensionsTests
{
    [Fact]
    public void ReplaceEntity_ShouldReplaceEntityPlaceholder()
    {
        // Arrange
        var template = "public class Entity {}";
        var newName = "Customer";

        // Act
        var result = template.ReplaceEntity(newName);

        // Assert
        result.Should().Be("public class Customer {}");
    }

    [Fact]
    public void ReplaceEntity_ShouldThrowIfNull()
    {
        // Act
        var act = () => ((string)null!).ReplaceEntity("Any");

        // Assert
        act.Should().Throw<ArgumentNullException>();
    }

    [Theory]
    [InlineData("word1    word2", "word1_word2")]
    [InlineData("  A    B   C  ", "A_B_C")]
    [InlineData("X", "X")]
    [InlineData("", "")]
    [InlineData(null, "")]
    public void ReplaceMultipleSpaces_ShouldReplaceWithSingleUnderscore(string input, string expected)
    {
        // Act
        var result = input.ReplaceMultipleSpaces();

        // Assert
        result.Should().Be(expected);
    }
}
