﻿using FluentAssertions;
using System.Reflection;

namespace GeneralHelpers.Tests;
public class AssemblyExtensionsTests
{
    private readonly Assembly _assembly = typeof(AssemblyExtensionsTests).Assembly;

    [Fact]
    public async Task GetResource_ShouldReturnEmbeddedResourceContent()
    {
        // Arrange
        var resourceName = "test.txt";
        var expectedContent = "Hello from embedded resource!";

        // Act
        var content = await _assembly.GetResource(resourceName);

        // Assert
        content.Trim().Should().Be(expectedContent);
    }

    [Fact]
    public async Task GetResource_ShouldThrowIfResourceNotFound()
    {
        // Arrange
        var resourceName = "notfound.txt";

        // Act
        var act = async () => await _assembly.GetResource(resourceName);

        // Assert
        await act.Should().ThrowAsync<InvalidOperationException>()
            .WithMessage("*Unable to load resource*");
    }
}
