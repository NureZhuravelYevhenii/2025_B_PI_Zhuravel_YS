﻿using FluentAssertions;
using MainAbstractions.Modules;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using Moq;

namespace GeneralHelpers.Tests;
public class ModuleHelperTests
{
    [Fact]
    public async Task ExecuteSubModulesAsync_ShouldReturnCombinedContentFromAllSubModules()
    {
        // Arrange
        var subModule1 = new Mock<ISubModule>();
        var subModule2 = new Mock<ISubModule>();

        var content1 = new Mock<IContent>().Object;
        var content2 = new Mock<IContent>().Object;
        var content3 = new Mock<IContent>().Object;

        subModule1.Setup(x => x.ParseInCodeAsync(It.IsAny<CancellationToken>()))
                  .ReturnsAsync(new[] { content1, content2 });

        subModule2.Setup(x => x.ParseInCodeAsync(It.IsAny<CancellationToken>()))
                  .ReturnsAsync(new[] { content3 });

        var subModules = new[] { subModule1.Object, subModule2.Object };

        // Act
        var result = await ModuleHelper.ExecuteSubModulesAsync(subModules);

        // Assert
        result.Should().HaveCount(3).And.Contain(new[] { content1, content2, content3 });
    }

    [Fact]
    public async Task ExecuteSubModulesAsync_ShouldHandleEmptySubModuleList()
    {
        // Arrange
        var subModules = Enumerable.Empty<ISubModule>();

        // Act
        var result = await ModuleHelper.ExecuteSubModulesAsync(subModules);

        // Assert
        result.Should().BeEmpty();
    }

    [Fact]
    public async Task ProcessContentWithHandlersAsync_ShouldCallCorrectHandlers()
    {
        // Arrange
        var contentA = new AContent();
        var contentB = new BContent();

        var resultA = new[] { "Processed A1", "Processed A2" };
        var resultB = new[] { "Processed B1" };

        var handlers = new Dictionary<Type, Func<IContent, Task<IEnumerable<string>>>>
        {
            [typeof(AContent)] = content => Task.FromResult(resultA.AsEnumerable()),
            [typeof(BContent)] = content => Task.FromResult(resultB.AsEnumerable())
        };

        var contents = new IContent[] { contentA, contentB };

        // Act
        var result = await ModuleHelper.ProcessContentWithHandlersAsync<string>(contents, handlers);

        // Assert
        result.Should().HaveCount(3);
        result.Should().Contain(resultA).And.Contain(resultB);
    }

    [Fact]
    public async Task ProcessContentWithHandlersAsync_ShouldSkipContentWithoutHandler()
    {
        // Arrange
        var contentA = new AContent();
        var unknownContent = new UnknownContent();

        var handlers = new Dictionary<Type, Func<IContent, Task<IEnumerable<string>>>>
        {
            [typeof(AContent)] = content => Task.FromResult(new[] { "Handled A" }.AsEnumerable())
        };

        var contents = new IContent[] { contentA, unknownContent };

        // Act
        var result = await ModuleHelper.ProcessContentWithHandlersAsync<string>(contents, handlers);

        // Assert
        result.Should().ContainSingle().Which.Should().Be("Handled A");
    }

    // Dummy implementations for testing
    private class AContent : IContent { }
    private class BContent : IContent { }
    private class UnknownContent : IContent { }
}
