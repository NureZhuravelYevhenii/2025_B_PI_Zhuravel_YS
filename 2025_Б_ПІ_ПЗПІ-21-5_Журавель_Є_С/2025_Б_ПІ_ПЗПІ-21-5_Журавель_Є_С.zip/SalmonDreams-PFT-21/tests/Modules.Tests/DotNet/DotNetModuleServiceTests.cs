﻿using DotNetModule.Contents;
using DotNetModule.Contents.FileContentEntities;
using DotNetModule.Entities;
using DotNetModule.Services;
using FluentAssertions;
using Moq;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules;
using DotNetModule;

namespace Modules.Tests.DotNet;
public class DotNetModuleServiceTests
{
    private readonly DotNetModule.DotNetModule _dotNetModule;
    private readonly DotNetModuleService _service;

    public DotNetModuleServiceTests()
    {
        var properties = new DotNetModuleProperties();
        var fileContent = new FileContent
        {
            Location = "MyProject/File1.cs",
            Content = "class A { }",
            BuildAction = new BuildAction { Name = "Compile" },
            Dependencies = new List<Dependency> { new Dependency { Include = "Newtonsoft.Json", Version = "1.0.0" } }
        };

        var mockSubModule = new Mock<ISubModule>();
        mockSubModule.Setup(m => m.ParseInCodeAsync(It.IsAny<CancellationToken>()))
                     .ReturnsAsync(new List<IContent> { fileContent });

        _dotNetModule = new DotNetModule.DotNetModule
        {
            Properties = properties,
            Modules = new List<ISubModule> { mockSubModule.Object }
        };

        _service = new DotNetModuleService(_dotNetModule);
    }

    [Fact]
    public async Task GetRawContents_ShouldReturnRawContent_ForFileContent()
    {
        // Act
        var result = (await _service.GetRawContents()).ToList();

        // Assert
        result.Should().ContainSingle(x => x.Name == "MyProject/File1.cs");
        result.First().Content.Should().NotBeNull();
    }

    [Fact]
    public async Task GetRawContents_ShouldIncludeProjectFileAndSolution()
    {
        // Act
        var result = (await _service.GetRawContents()).ToList();

        // Assert
        result.Should().ContainSingle(x => x.Name == "MyProject/File1.cs");
        result.Should().Contain(x => x.Name.EndsWith(".csproj"));
        result.Should().Contain(x => x.Name.EndsWith(".sln"));
    }

    [Fact]
    public async Task GetRawContents_ShouldTrackDependenciesInProjectMetadata()
    {
        // Act
        var rawContents = (await _service.GetRawContents()).ToList();

        // Assert
        var csproj = rawContents.FirstOrDefault(x => x.Name.EndsWith(".csproj"));
        csproj.Should().NotBeNull();
        var csprojContent = System.Text.Encoding.UTF8.GetString(csproj!.Content);
        csprojContent.Should().Contain("Newtonsoft.Json");
    }
}
