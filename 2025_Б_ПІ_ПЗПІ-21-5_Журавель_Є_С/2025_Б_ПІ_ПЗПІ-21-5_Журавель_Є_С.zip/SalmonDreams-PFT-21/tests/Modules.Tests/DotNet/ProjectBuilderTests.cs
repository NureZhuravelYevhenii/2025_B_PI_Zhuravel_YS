﻿using DotNetModule.Builders;
using DotNetModule.Contents.FileContentEntities;
using DotNetModule.Entities;
using FluentAssertions;
using System.Text;

namespace Modules.Tests.DotNet;
public class ProjectBuilderTests
{
    [Fact]
    public void Build_ShouldIncludeTargetFrameworkAndSdk()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "TestProject" };
        var builder = new ProjectBuilder(projectEntry);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("<Project Sdk=\"Microsoft.NET.Sdk\">");
        content.Should().Contain("<TargetFramework>net8.0</TargetFramework>");
    }

    [Fact]
    public void Build_ShouldUseWebSdk_IfIsWebIsTrue()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "ProjectWeb" };
        var builder = new ProjectBuilder(projectEntry);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("<Project Sdk=\"Microsoft.NET.Sdk.Web\">");
    }

    [Fact]
    public void Build_ShouldIncludeDependencies()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "Lib" };
        var dependencies = new[]
        {
            new Dependency
            {
                Include = "Newtonsoft.Json",
                Version = "13.0.1"
            },
             new Dependency
            {
                Include = "Serilog",
                Version = "2.10.0"
            },
        };

        var builder = new ProjectBuilder(projectEntry)
            .WithDependencies(dependencies);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("<PackageReference Include=\"Newtonsoft.Json\" Version=\"13.0.1\" />");
        content.Should().Contain("<PackageReference Include=\"Serilog\" Version=\"2.10.0\" />");
    }

    [Fact]
    public void Build_ShouldIncludeProjectReferences()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "Main" };
        var references = new[] { "CoreLib", "Utils" };

        var builder = new ProjectBuilder(projectEntry)
            .WithProjectReferences(references);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("<ProjectReference Include=\"..\\CoreLib\\CoreLib.csproj\" />");
        content.Should().Contain("<ProjectReference Include=\"..\\Utils\\Utils.csproj\" />");
    }

    [Fact]
    public void Build_ShouldIncludeBuildActionsWithParameters()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "App" };

        var buildActions = new[]
        {
            new BuildAction
            {
                Name = "None",
                FileName = "appsettings.json",
                Action = "Update",
                AdditionalParameters = new Dictionary<string, string>
                {
                    ["CopyToOutputDirectory"] = "PreserveNewest"
                }
            }
        };

        var builder = new ProjectBuilder(projectEntry)
            .WithBuildActions(buildActions);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("<None Include=\"appsettings.json\"/>");
        content.Should().Contain("<None Update=\"appsettings.json\">");
        content.Should().Contain("<CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>");
        content.Should().Contain("</None>");
    }

    [Fact]
    public void Build_ShouldIncludeRemoveContentLine_WhenBuildActionProvided()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "MyApp" };

        var buildActions = new[]
        {
            new BuildAction
            {
                Name = "Content",
                FileName = "data.json",
                Action = "Update"
            }
        };

        var builder = new ProjectBuilder(projectEntry)
            .WithBuildActions(buildActions);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("<Content Remove=\"data.json\"/>");
        content.Should().Contain("<Content Include=\"data.json\"/>");
    }

    [Fact]
    public void Build_ShouldReturnRawContentWithCorrectName()
    {
        // Arrange
        var projectEntry = new ProjectEntry { Name = "MyLib" };
        var builder = new ProjectBuilder(projectEntry);

        // Act
        var result = builder.Build();

        // Assert
        result.Name.Should().Be("MyLib/MyLib.csproj");
    }
}
