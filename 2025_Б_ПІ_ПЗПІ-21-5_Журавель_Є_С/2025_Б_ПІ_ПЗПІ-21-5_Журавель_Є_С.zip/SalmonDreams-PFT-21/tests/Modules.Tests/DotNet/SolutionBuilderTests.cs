﻿using DotNetModule.Builders;
using DotNetModule.Entities;
using FluentAssertions;
using System.Text;
using DotNetModule;

namespace Modules.Tests.DotNet;
public class SolutionBuilderTests
{
    private DotNetModule.DotNetModule CreateTestModule(string name = "TestSolution")
    {
        return new DotNetModule.DotNetModule
        {
            Properties = new DotNetModuleProperties
            {
                ProjectName = name
            }
        };
    }

    [Fact]
    public void Build_ShouldContainSolutionHeader()
    {
        // Arrange
        var module = CreateTestModule();
        var builder = new SolutionBuilder(module);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("Microsoft Visual Studio Solution File, Format Version 12.00");
        content.Should().Contain("VisualStudioVersion = 17.8.34408.163");
    }

    [Fact]
    public void Build_ShouldIncludeAllProjects()
    {
        // Arrange
        var module = CreateTestModule("MySolution");

        var projects = new[]
        {
            new ProjectEntry { Name = "Core", Guid = Guid.NewGuid() },
            new ProjectEntry { Name = "Api", Guid = Guid.NewGuid() }
        };

        var builder = new SolutionBuilder(module).WithProjects(projects);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("Project(");
        content.Should().Contain("Core\\Core.csproj");
        content.Should().Contain("Api\\Api.csproj");
        content.Split(Environment.NewLine)
            .Count(line => line.Contains("EndProject"))
            .Should().Be(2);
    }

    [Fact]
    public void Build_ShouldContainProjectConfigurationSections()
    {
        // Arrange
        var module = CreateTestModule();

        var project = new ProjectEntry { Name = "Service", Guid = Guid.NewGuid() };
        var builder = new SolutionBuilder(module).WithProjects(new[] { project });

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain($"{{{project.Guid}}}.Debug|Any CPU.ActiveCfg = Debug|Any CPU");
        content.Should().Contain($"{{{project.Guid}}}.Release|Any CPU.Build.0 = Release|Any CPU");
    }

    [Fact]
    public void Build_ShouldContainGlobalSections()
    {
        // Arrange
        var module = CreateTestModule();
        var builder = new SolutionBuilder(module);

        // Act
        var result = builder.Build();
        var content = Encoding.UTF8.GetString(result.Content);

        // Assert
        content.Should().Contain("GlobalSection(SolutionConfigurationPlatforms) = preSolution");
        content.Should().Contain("GlobalSection(ProjectConfigurationPlatforms) = postSolution");
        content.Should().Contain("GlobalSection(SolutionProperties) = preSolution");
        content.Should().Contain("GlobalSection(ExtensibilityGlobals) = postSolution");
    }

    [Fact]
    public void Build_ShouldReturnCorrectSolutionFileName()
    {
        // Arrange
        var module = CreateTestModule("CoolApp");
        var builder = new SolutionBuilder(module);

        // Act
        var result = builder.Build();

        // Assert
        result.Name.Should().Be("CoolApp.sln");
    }
}

