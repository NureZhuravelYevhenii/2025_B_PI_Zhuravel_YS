﻿using MainAbstractions.Modules.Metadata;

namespace JwtIdentityEntity;

/// <summary>
/// Represents the components for jwt-based authorization.
/// </summary>
public class JwtIdentityEntityProperties : IModuleProperties
{
    /// <summary>
    /// Fields used for access token claims creation.
    /// </summary>
    public IEnumerable<string> ClaimsForAccessToken { get; set; } = [];

    /// <summary>
    /// Fields used for refresh token claims creation.
    /// </summary>
    public IEnumerable<string> ClaimsForRefreshToken { get; set; } = [];
}
