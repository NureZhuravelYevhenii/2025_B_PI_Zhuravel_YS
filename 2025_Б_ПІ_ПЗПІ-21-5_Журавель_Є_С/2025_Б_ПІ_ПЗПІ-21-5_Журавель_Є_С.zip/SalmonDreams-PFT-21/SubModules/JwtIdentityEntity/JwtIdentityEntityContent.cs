﻿using MainAbstractions.Modules.Content;
using Property;

namespace JwtIdentityEntity;

/// <summary>
/// Represents the definition for jwt-based authorization.
/// </summary>
public class JwtIdentityEntityContent : IContent
{
    /// <summary>
    /// Primary entity's name.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Fields used for refresh token claims creation.
    /// </summary>
    public ICollection<PropertyContent> RefreshTokenClaimProperties { get; set; } = [];

    /// <summary>
    /// Fields used for access token claims creation.
    /// </summary>
    public ICollection<PropertyContent> AccessTokenClaimProperties { get; set; } = [];
}
