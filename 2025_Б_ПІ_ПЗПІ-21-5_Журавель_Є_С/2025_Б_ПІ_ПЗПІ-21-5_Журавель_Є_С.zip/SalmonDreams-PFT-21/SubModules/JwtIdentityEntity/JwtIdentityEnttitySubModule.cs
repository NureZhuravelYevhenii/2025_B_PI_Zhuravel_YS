﻿using Entity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using Property;

namespace JwtIdentityEntity;

/// <summary>
/// Provides functionality for defining an instance of <see cref="JwtIdentityEntityContent" /> for a specified <see cref="EntityContent" /> in the appliaction.
/// </summary>
public class JwtIdentityEnttitySubModule : BaseSubModule<JwtIdentityEntityProperties>
{
    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        var contents = await ModuleHelper.ExecuteSubModulesAsync(Modules, token);
        if (PropertiesWithType!.ClaimsForAccessToken is null
            && PropertiesWithType!.ClaimsForRefreshToken is null)
        {
            return contents;
        }

        var newContents = new List<IContent>();
        foreach (var content in contents)
        {
            if (content is not EntityContent)
            {
                newContents.Add(content);
                continue;
            }

            var entityContent = (EntityContent)content;
            newContents.Add(new EntityContent
            {
                Name = entityContent.Name,
                Properties = GetUpdatedEntityProperties(entityContent),
            });

            newContents.Add(GetJwtIdentityEntityContent(entityName: entityContent.Name));
        }

        return newContents;
    }

    #region Private methods

    private ICollection<PropertyContent> GetUpdatedEntityProperties(EntityContent entityContent)
    {
        var properties = entityContent.Properties;
        AddRefreshTokenProperty(properties);

        return properties;
    }

    private void AddRefreshTokenProperty(ICollection<PropertyContent> properties)
    {
        properties.Add(new PropertyContent
        {
            Name = "RefreshToken",
            PropertyType = PropertyType.String,
        });
    }

    private JwtIdentityEntityContent GetJwtIdentityEntityContent(string entityName)
    {
        var accessTokenClaims = GetTokenClaimProperties(PropertiesWithType!.ClaimsForAccessToken);
        var refreshTokenClaims = GetTokenClaimProperties(PropertiesWithType!.ClaimsForRefreshToken);

        return new JwtIdentityEntityContent
        {
            Name = entityName,
            AccessTokenClaimProperties = accessTokenClaims,
            RefreshTokenClaimProperties = refreshTokenClaims
        };
    }

    private List<PropertyContent> GetTokenClaimProperties(IEnumerable<string> claims)
    {
        return claims.Distinct()
            .Select(GetClaim)
            .ToList();
    }

    private PropertyContent GetClaim(string claim)
    {
        return new PropertyContent
        {
            Name = claim,
            PropertyType = PropertyType.String,
        };
    }

    #endregion
}
