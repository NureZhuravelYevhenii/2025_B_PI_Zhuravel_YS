﻿using AutoMapper;
using BLL.Entities.Identity;

namespace BLL.Infrastructure.Automapper.Identity;

public class JwtEntityIdentityProfile : Profile
{
    public JwtEntityIdentityProfile()
    {
        CreateMap<RegisterEntityModel, DAL.Entities.Entity>();
    }
}
