﻿using BLL.Entities.Jwt;
using DAL.Entities.BaseEntities;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BLL.Infrastructure.Helpers.Jwt;

public interface IJwtManager
{
    Task<IEnumerable<Claim>> DecodeTokenAsync(string jwtToken, CancellationToken token = default);
    JwtSecurityToken GetJwtToken(IEnumerable<Claim> claims);
    TokenPair GenerateTokenPair(IEnumerable<Claim> accessTokenClaims, IEnumerable<Claim> refreshTokenClaims);
    TokenPair GenerateTokenPair(BaseEntity entity);
}
