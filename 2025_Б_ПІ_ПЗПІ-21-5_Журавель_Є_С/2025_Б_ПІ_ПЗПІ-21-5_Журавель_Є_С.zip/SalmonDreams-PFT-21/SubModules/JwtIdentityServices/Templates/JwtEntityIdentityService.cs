﻿using AutoMapper;
using BLL.Abstractions.Identity;
using BLL.Infrastructure.Helpers;
using BLL.Entities.Identity;
using DAL.Abstractions;
using BLL.Entities.Jwt;
using BLL.Infrastructure.Helpers.Jwt;
using System.Threading;
using System.Threading.Tasks;
using System;
using System.Linq;

namespace BLL.Services.Identity;

public class JwtEntityIdentityService : IJwtEntityIdentityService
{
    private readonly IMapper _mapper;
    private readonly IRepository<DAL.Entities.Entity> _repository;
    private readonly IJwtManager _jwtManager;

    public JwtEntityIdentityService(
        IRepository<DAL.Entities.Entity> repository,
        IJwtManager jwtManager,
        IMapper mapper)
    {
        _repository = repository;
        _jwtManager = jwtManager;
        _mapper = mapper;
    }

    public async Task<TokenPair> LoginEntityAsync(LoginEntityModel loginModel, CancellationToken cancellationToken = default)
    {
        var entity = await _repository.GetByPredicateFirstAsync(x => x.Login == loginModel.Login, cancellationToken);
        if (entity is null
            || !HashHelper.VerifyPassword(loginModel.Password, entity.PasswordSalt, entity.PasswordHash))
        {
            throw new UnauthorizedAccessException("Incorrect login or password");
        }

        var tokenPair = _jwtManager.GenerateTokenPair(entity);
        await UpdateRefreshToken(tokenPair.RefreshToken, entity);

        return tokenPair;
    }

    public async Task<TokenPair> RegisterEntityAsync(RegisterEntityModel model, CancellationToken cancellationToken = default)
    {
        if (await _repository.GetByPredicateFirstAsync(x => x.Login == model.Login, cancellationToken) is not null)
            throw new ArgumentException("Login already exists");

        var (salt, passwordHash) = HashHelper.GetNewPasswordHash(model.Password);
        var entity = _mapper.Map<DAL.Entities.Entity>(model);

        entity.PasswordSalt = salt;
        entity.PasswordHash = passwordHash;

        var tokenPair = _jwtManager.GenerateTokenPair(entity);
        entity.RefreshToken = tokenPair.RefreshToken;

        await _repository.AddAsync(entity);

        return tokenPair;
    }

    public async Task<TokenPair> RefreshTokenAsync(string refreshToken, CancellationToken token = default)
    {
        var claims = await _jwtManager.DecodeTokenAsync(refreshToken, token);
        var idClaim = claims.FirstOrDefault(c => c.Type == "id");
        if (idClaim is null)
            throw new UnauthorizedAccessException("Invalid refresh token.");

        var entity = await _repository.GetByIdAsync(int.Parse(idClaim.Value), token);
        if (entity == null)
            throw new UnauthorizedAccessException("Invalid refresh token.");

        var tokenPair = _jwtManager.GenerateTokenPair(entity);
        await UpdateRefreshToken(tokenPair.RefreshToken, entity);

        return tokenPair;
    }

    private async Task UpdateRefreshToken(string refreshToken, DAL.Entities.Entity entity)
    {
        entity.RefreshToken = refreshToken;
        await _repository.UpdateAsync(entity);
    }
}
