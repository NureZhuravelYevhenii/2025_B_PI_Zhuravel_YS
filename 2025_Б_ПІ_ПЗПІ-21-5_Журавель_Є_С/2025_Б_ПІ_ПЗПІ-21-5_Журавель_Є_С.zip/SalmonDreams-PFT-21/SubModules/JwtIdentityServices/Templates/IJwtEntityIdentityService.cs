﻿using BLL.Entities.Jwt;
using BLL.Entities.Identity;
using System.Threading;
using System.Threading.Tasks;

namespace BLL.Abstractions.Identity;

public interface IJwtEntityIdentityService
{
    Task<TokenPair> LoginEntityAsync(LoginEntityModel loginModel, CancellationToken cancellationToken = default);
    Task<TokenPair> RegisterEntityAsync(RegisterEntityModel model, CancellationToken cancellationToken = default);
    Task<TokenPair> RefreshTokenAsync(string refreshToken, CancellationToken token = default);
}
