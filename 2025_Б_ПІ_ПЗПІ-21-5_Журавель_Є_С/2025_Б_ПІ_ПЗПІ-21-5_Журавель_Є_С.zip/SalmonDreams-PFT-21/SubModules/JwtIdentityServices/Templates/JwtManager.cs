﻿using BLL.Entities.Jwt;
using DAL.Entities.BaseEntities;
using Common.Configurations;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System;
using BLL.Infrastructure.Helpers.Jwt;

#nullable enable

namespace BLL.Helpers.Jwt;

public class JwtManager : IJwtManager
{
    private readonly JwtConfiguration _jwtConfiguration;

    public JwtManager(IOptions<JwtConfiguration> jwtConfigurationOptions)
    {
        _jwtConfiguration = jwtConfigurationOptions.Value
            ?? throw new ArgumentException(nameof(jwtConfigurationOptions));
    }        

    public Task<IEnumerable<Claim>> DecodeTokenAsync(string jwtToken, CancellationToken token = default)
    {
        var tokenHandler = new JwtSecurityTokenHandler();

        var tokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = _jwtConfiguration.ValidateIssuer,
            ValidateLifetime = _jwtConfiguration.ValidateLifetime,
            ValidateAudience = _jwtConfiguration.ValidateAudience,
            ValidateIssuerSigningKey = _jwtConfiguration.ValidateSecretKey,

            ValidIssuer = _jwtConfiguration.Issuer,
            ValidAudience = _jwtConfiguration.Audience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtConfiguration.SecretKey)),
        };

        try
        {
            var principal = tokenHandler.ValidateToken(jwtToken, tokenValidationParameters, out var validatedToken);
            return Task.FromResult(principal.Claims);
        }
        catch
        {
            return Task.FromResult(new List<Claim>().AsEnumerable());
        }
    }

    public JwtSecurityToken GetJwtToken(IEnumerable<Claim> claims)
    {
        SigningCredentials? signingCredentials = null;
        if (_jwtConfiguration.ValidateSecretKey)
            signingCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtConfiguration.SecretKey)), SecurityAlgorithms.HmacSha256);

        DateTime? expires = null;
        if (_jwtConfiguration.ValidateLifetime)
            expires = DateTime.Now.AddMinutes(_jwtConfiguration.LifetimeInMinutes);

        string? issuer = null;
        if (_jwtConfiguration.ValidateIssuer)
            issuer = _jwtConfiguration.Issuer;

        string? audience = null;
        if (_jwtConfiguration.ValidateAudience)
            audience = _jwtConfiguration.Audience;

        var jwtToken = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(30),
            signingCredentials: signingCredentials
        );

        return jwtToken;
    }

    public TokenPair GenerateTokenPair(IEnumerable<Claim> accessTokenClaims, IEnumerable<Claim> refreshTokenClaims)
    {
        var accessToken = GetJwtToken(accessTokenClaims);
        var refreshToken = GetJwtToken(refreshTokenClaims);

        return new TokenPair
        {
            AccessToken = new JwtSecurityTokenHandler().WriteToken(accessToken),
            RefreshToken = new JwtSecurityTokenHandler().WriteToken(refreshToken)
        };
    }

    public TokenPair GenerateTokenPair(BaseEntity entity)
    {
        var accessToken = GetJwtToken(GetClaimsForAccessToken(entity));
        var refreshToken = GetJwtToken(GetClaimsForRefreshToken(entity));

        return new TokenPair
        {
            AccessToken = new JwtSecurityTokenHandler().WriteToken(accessToken),
            RefreshToken = new JwtSecurityTokenHandler().WriteToken(refreshToken)
        };
    }

    private IEnumerable<Claim> GetClaimsForAccessToken(BaseEntity entity) => [
        new Claim("id", entity.Id.ToString())
       ];

    private IEnumerable<Claim> GetClaimsForRefreshToken(BaseEntity entity) => [
            new Claim("id", entity.Id.ToString()),
            new Claim("nonce", GenerateRandomString())
        ];

    private string GenerateRandomString()
    {
        var randomBytes = new byte[128];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomBytes);
        return Convert.ToBase64String(randomBytes);
    }
}
