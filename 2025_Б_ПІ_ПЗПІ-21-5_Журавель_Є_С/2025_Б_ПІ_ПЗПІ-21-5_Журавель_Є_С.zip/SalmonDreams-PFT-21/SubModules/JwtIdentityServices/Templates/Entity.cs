﻿using DAL.Entities.BaseEntities;

namespace DAL.Models;

public class Entity : BaseEntity
{
    public string Login { get; set; }

    public string PasswordHash { get; set; }

    public string PasswordSalt { get; set; }

    public string RefreshToken { get; set; }
}
