﻿using MainAbstractions.Modules.Metadata;

namespace JwtIdentityEntityServices;

/// <summary>
/// Represents the components for jwt-based authorization services creation.
/// The authorization services in the applicaton are those that have "Login", "Register" methods.
/// </summary>
public class JwtIdentityServiceProperties : IModuleProperties { }
