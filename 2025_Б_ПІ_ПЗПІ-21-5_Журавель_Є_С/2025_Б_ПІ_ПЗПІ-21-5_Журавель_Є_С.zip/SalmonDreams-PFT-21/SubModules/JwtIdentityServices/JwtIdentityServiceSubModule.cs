﻿using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using SharpCodeGenerator;
using SharpCodeGenerator.Entities;
using System.Reflection;
using System.Text;
using JwtIdentityEntity;
using DotNetModule.Contents;
using DotNetModule.Entities;
using GeneralHelpers;
using AspNet.Contents;
using JwtIdentityServices.AppSettingsTemplates;
using AutomapperRegistration;

namespace JwtIdentityEntityServices;

/// <summary>
/// Generates a collection of <see cref="IContent"/> for jwt-based authorization services creation.
/// </summary>
public class JwtIdentityServiceSubModule : BaseSubModule<JwtIdentityServiceProperties>
{
    private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(JwtIdentityServiceSubModule).Assembly);
    private readonly Lazy<StringCodeGenerator> _stringGenerator = new Lazy<StringCodeGenerator>();

    private const string BASE_SERVICE_NAME = "JwtEntityIdentityService";

    public JwtIdentityServiceSubModule()
    {
        RegisterHandler<JwtIdentityEntityContent>(JwtIdentityEntityContentHandler);
    }

    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token))
           .Concat(await GetJwtManagerFiles())
           .Concat([
               await GetStartupRegistration(),
               await GetHashHelper(),
               GetAppSettingsContent(),
               GetStartupContent(),
               GenerateProjectRelation(),
               GetAutomapperRegistration()
           ]).ToList();
    }

    private async Task<IEnumerable<IContent>> JwtIdentityEntityContentHandler(JwtIdentityEntityContent rawContent, ICollection<IContent> contents)
    {
        contents.Add(await GetLoginEntityModel(rawContent.Name));
        contents.Add(await GetAutomapperProfile(rawContent.Name));
        contents.Add(await GetRegisterEntityModel(rawContent.Name));
        contents.Add(await GetService(rawContent.Name));
        contents.Add(await GetServiceAbstraction(rawContent.Name));
        contents.Add(await GetEntityServiceRegistration(rawContent.Name));

        return contents;
    }

    private async Task<IContent> GetEntityServiceRegistration(string entity)
    {
        return new ServiceRegistrationContent
        {
            Usings = [
                 await _stringGenerator.Value.GenerateUsingAsync(new Using
                 {
                     Name = "BLL.Services.Identity"
                 }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "BLL.Abstractions.Identity"
                }),
            ],
            ServiceRegistration = $"builder.Services.AddScoped<IJwt{entity}IdentityService, Jwt{entity}IdentityService>();"
        };
    }

    private async Task<IContent> GetStartupRegistration()
    {
        return new ServiceRegistrationContent
        {
            Usings = [
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "BLL.Infrastructure.Helpers.Jwt"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "BLL.Helpers.Jwt"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Common.Configurations"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Microsoft.IdentityModel.Tokens"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "System.Text"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Microsoft.AspNetCore.Authentication.JwtBearer"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Microsoft.Extensions.Configuration"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Microsoft.Extensions.Options"
                }),
            ],
            ServiceRegistration = GetStartupServiceRegistration()
        };
    }

    private string GetStartupServiceRegistration()
    {
        var serviceRegistration = new StringBuilder();
        serviceRegistration.AppendLine($"builder.Services.AddScoped<IJwtManager, JwtManager>();");
        serviceRegistration.AppendLine(
$@"builder.Services.Configure<JwtConfiguration>(
    builder.Configuration.GetSection(""JwtConfiguration"")
);

builder.Services.AddSingleton(sp => 
    sp.GetRequiredService<IOptions<JwtConfiguration>>().Value
);"
        );

        serviceRegistration.AppendLine(GetAuthenticationSection());

        return serviceRegistration.ToString();
    }

    private string GetAuthenticationSection()
    {
        return @"
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        var jwtConfiguration = builder.Configuration
            .GetSection(""JwtConfiguration"")
            .Get<JwtConfiguration>() ?? new JwtConfiguration();

        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = jwtConfiguration.ValidateSecretKey,
            ValidateLifetime = jwtConfiguration.ValidateLifetime,
            ValidateIssuer = jwtConfiguration.ValidateIssuer,
            ValidateAudience = jwtConfiguration.ValidateAudience
        };

        if (jwtConfiguration.ValidateSecretKey)
        {
            options.TokenValidationParameters.IssuerSigningKey = 
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtConfiguration.SecretKey));
        }

        if (jwtConfiguration.ValidateIssuer)
        {
            options.TokenValidationParameters.ValidIssuer = jwtConfiguration.Issuer;
        }

        if (jwtConfiguration.ValidateAudience)
        {
            options.TokenValidationParameters.ValidAudience = jwtConfiguration.Audience;
        }
    });

    builder.Services.AddSwaggerGen(options =>
    {
        options.AddSecurityDefinition(""Bearer"", new OpenApiSecurityScheme
        {
            In = ParameterLocation.Header,
            Name = ""Authorization"",
            Type = SecuritySchemeType.ApiKey,
            Scheme = ""Bearer"",
            BearerFormat = ""JWT"",
            Description = ""Enter your Bearer token""
        });

        options.AddSecurityRequirement(new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = ""Bearer""
                    }
                },
                new string[] { }
            }
        });
    });";
    }

    private IContent GetStartupContent()
    {
        return new StartupContent
        {
            MiddlewareRegistration = @"
app.UseAuthentication();
app.UseAuthorization();
            "
        };
    }

    private async Task<IContent> GetHashHelper()
    {
        return new FileContent
        {
            Location = $"BLL/Infrastructure/Helpers/HashHelper.cs",
            Content = await Assembly.Value.GetResource($"HashHelper.cs")
        };
    }

    private async Task<IContent> GetService(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Services/Identity/Jwt{entity}IdentityService.cs",
            Content = (await Assembly.Value.GetResource($"JwtEntityIdentityService.cs")).ReplaceEntity(entity),
            Dependencies = [
                new Dependency
                {
                    Include = "AutoMapper",
                    Version = "13.0.1",
                },
                new Dependency
                {
                    Include = "BCrypt.Net-Next",
                    Version = "4.0.3",
                },
            ]
        };
    }

    private async Task<IContent> GetServiceAbstraction(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Abstractions/Identity/IJwt{entity}IdentityService.cs",
            Content = (await Assembly.Value.GetResource($"IJwtEntityIdentityService.cs")).ReplaceEntity(entity)
        };
    }

    private ProjectRelationContent GenerateProjectRelation()
    {
        return new ProjectRelationContent
        {
            ProjectName = "BLL",
            ProjectDependencies =
            [
                "Common", "DAL"
            ]
        };
    }

    private static AppSettingsContent GetAppSettingsContent()
    {
        return new AppSettingsContent
        {
            Object = typeof(JwtConfigurationTemplate),
            Title = "JwtConfiguration",
        };
    }

    private async Task<IContent> GetLoginEntityModel(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Entities/Identity/Login{entity}Model.cs",
            Content = (await Assembly.Value.GetResource("LoginEntityModel.cs")).ReplaceEntity(entity)
        };
    }

    private async Task<IContent> GetRegisterEntityModel(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Entities/Identity/Register{entity}Model.cs",
            Content = (await Assembly.Value.GetResource("RegisterEntityModel.cs")).ReplaceEntity(entity)
        };
    }

    private async Task<IEnumerable<IContent>> GetJwtManagerFiles()
    {
        return new List<IContent>
        {
            await GetJwtConfiguration(),
            await GetJwtTokenPair(),
            await GetJwtManager(),
            await GetJwtManagerAbstraction()
        };
    }

    private async Task<IContent> GetJwtConfiguration()
    {
        return new FileContent
        {
            Location = "Common/Configurations/JwtConfiguration.cs",
            Content = await Assembly.Value.GetResource("JwtConfiguration.cs")
        };
    }

    private async Task<IContent> GetJwtTokenPair()
    {
        return new FileContent
        {
            Location = "BLL/Entities/Jwt/TokenPair.cs",
            Content = await Assembly.Value.GetResource("TokenPair.cs")
        };
    }

    private async Task<IContent> GetJwtManager()
    {
        return new FileContent
        {
            Location = "BLL/Infrastructure/Helpers/Jwt/JwtManager.cs",
            Content = await Assembly.Value.GetResource("JwtManager.cs"),
            Dependencies = [
                new Dependency
                {
                    Include = "Microsoft.Extensions.Options",
                    Version = "8.0.2",
                },
                new Dependency
                {
                    Include = "Microsoft.IdentityModel.Tokens",
                    Version = "8.1.0",
                },
                new Dependency
                {
                    Include = "System.IdentityModel.Tokens.Jwt",
                    Version = "8.1.0",
                }
            ]
        };
    }

    private async Task<IContent> GetJwtManagerAbstraction()
    {
        return new FileContent
        {
            Location = "BLL/Infrastructure/Helpers/Jwt/IJwtManager.cs",
            Content = await Assembly.Value.GetResource("IJwtManager.cs")
        };
    }

    private async Task<IContent> GetAutomapperProfile(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Infrastructure/Automapper/Entities/Identity/Jwt{entity}IdentityProfile.cs",
            Content = (await Assembly.Value.GetResource("JwtEntityIdentityProfile.cs")).ReplaceEntity(entity),
        };
    }

    private IContent GetAutomapperRegistration()
    {
        return new AutomapperRegistrationContent
        {
            AutomapperAssemblies = new[] { "BLL" }
        };
    }
}
