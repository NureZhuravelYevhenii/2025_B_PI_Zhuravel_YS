﻿using MainAbstractions.Modules.Metadata;

namespace AspNet;

/// <summary>
/// Represents the components relevant for ASP.NET app creation.
/// </summary>
public class AspNetProperties : IModuleProperties { }
