﻿using DotNetModule.Contents;
using DotNetModule.Entities;

namespace AspNet.Abstractions;

/// <summary>
/// Defines the contract for building middleware extension configurations.
/// </summary>
public interface IServiceRegistrationBuilder
{
    /// <summary>
    /// Adds custom usings to the program configuration.
    /// </summary>
    /// <param name="usings">A collection of usings to include.</param>
    /// <returns>The current instance of <see cref="IServiceRegistrationBuilder"/> for method chaining.</returns>
    IServiceRegistrationBuilder WithUsings(IEnumerable<string> usings);

    /// <summary>
    /// Add services for registration.
    /// </summary>
    /// <param name="serviceRegistration">A block of the services registration.</param>
    /// <returns>The current instance of <see cref="IServiceRegistrationBuilder"/> for method chaining.</returns>
    IServiceRegistrationBuilder WithServiceRegistration(string serviceRegistration);

    /// <summary>
    /// Configures Autofac as the dependency injection container in the middleware extensions.
    /// </summary>
    /// <returns>The current instance for method chaining.</returns>
    IServiceRegistrationBuilder WithAutofac();

    /// <summary>
    /// Configures localization services within the middleware extensions.
    /// </summary>
    /// <returns>The current instance for method chaining.</returns>
    IServiceRegistrationBuilder WithLocalization();

    /// <summary>
    /// Configures CORS policies in the middleware extensions.
    /// </summary>
    /// <returns>The current instance for method chaining.</returns>
    IServiceRegistrationBuilder WithCors();

    /// <summary>
    /// Configures Swagger for API documentation within the middleware extensions.
    /// </summary>
    /// <returns>The current instance for method chaining.</returns>
    IServiceRegistrationBuilder WithSwagger();

    IServiceRegistrationBuilder WithDependencies(IEnumerable<Dependency> dependencies);

    /// <summary>
    /// Builds the program configuration and writes it to a file.
    /// </summary>
    FileContent Build();
}
