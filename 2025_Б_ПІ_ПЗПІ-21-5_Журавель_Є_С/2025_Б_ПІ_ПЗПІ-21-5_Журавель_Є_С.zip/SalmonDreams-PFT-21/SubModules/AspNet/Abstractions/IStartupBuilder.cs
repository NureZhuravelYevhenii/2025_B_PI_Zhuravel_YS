﻿using DotNetModule.Contents;
using DotNetModule.Entities;

namespace AspNet.Abstractions;

/// <summary>
/// Defines a builder interface for constructing a Startup.cs file.
/// </summary>
public interface IStartupBuilder
{
    /// <summary>
    /// Adds custom usings to the program configuration.
    /// </summary>
    /// <param name="usings">A collection of usings to include.</param>
    /// <returns>The current instance of <see cref="IStartupBuilder"/> for method chaining.</returns>
    IStartupBuilder WithUsings(IEnumerable<string> usings);

    /// <summary>
    /// Add custom middleware for registration.
    /// </summary>
    /// <param name="middleware">A block of the middleware registration.</param>
    /// <returns>The current instance of <see cref="IStartupBuilder"/> for method chaining.</returns>
    IStartupBuilder WithMiddleware(string middleware);

    // <summary>
    /// Adds project dependencies.
    /// </summary>
    /// <returns>The current instance of <see cref="IStartupBuilder"/> for method chaining.</returns>
    IStartupBuilder WithDependencies(IEnumerable<Dependency> dependencies);

    /// <summary>
    /// Builds the program configuration and writes it to a file.
    /// </summary>
    FileContent Build();
}
