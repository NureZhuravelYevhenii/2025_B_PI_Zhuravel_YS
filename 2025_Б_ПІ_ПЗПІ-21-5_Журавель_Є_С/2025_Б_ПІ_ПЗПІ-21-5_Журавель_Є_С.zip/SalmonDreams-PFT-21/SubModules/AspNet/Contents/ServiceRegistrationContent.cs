﻿using DotNetModule.Entities;
using MainAbstractions.Modules.Content;

namespace AspNet.Contents;

/// <summary>
/// Represents the dependencies that should be registered in Middleware.
/// </summary>
public class ServiceRegistrationContent : IContent
{
    /// <summary>
    /// Collection of usings that should be added.
    /// </summary>
    public IEnumerable<string> Usings { get; set; } = [];

    /// <summary>
    /// Collection of project dependencies that should be added to .sln file.
    /// </summary>
    public IEnumerable<Dependency> Dependencies { get; set; } = [];

    /// <summary>
    /// Registration block.
    /// </summary>
    public string ServiceRegistration { get; set; } = string.Empty;
}
