﻿using DotNetModule.Entities;
using MainAbstractions.Modules.Content;

namespace AspNet.Contents;

/// <summary>
/// Represents the dependencies that should be registered in Startup.
/// </summary>
public class StartupContent : IContent
{
    /// <summary>
    /// Collection of usings that should be added.
    /// </summary>
    public IEnumerable<string> Usings { get; set; } = [];

    /// <summary>
    /// Collection of project dependencies that should be added to .sln file.
    /// </summary>
    public IEnumerable<Dependency> Dependencies { get; set; } = [];

    /// <summary>
    /// Middlewares that should be registered in Startup.cs.
    /// </summary>
    public string MiddlewareRegistration { get; set; } = string.Empty;
}
