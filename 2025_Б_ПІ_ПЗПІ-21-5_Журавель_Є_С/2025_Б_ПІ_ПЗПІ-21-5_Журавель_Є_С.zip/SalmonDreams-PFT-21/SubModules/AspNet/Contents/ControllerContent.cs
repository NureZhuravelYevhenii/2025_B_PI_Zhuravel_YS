﻿using MainAbstractions.Modules.Content;

namespace AspNet.Contents;

/// <summary>
/// Represents the definition of ASP.NET controller.
/// </summary>
public class ControllerContent : IContent
{
    /// <summary>
    /// Controller's name.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Controller's file content.
    /// </summary>
    public string Content { get; set; } = string.Empty;
}
