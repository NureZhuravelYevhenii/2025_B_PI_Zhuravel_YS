﻿using MainAbstractions.Modules.Content;

namespace AspNet.Contents;

/// <summary>
/// Represents the definition of appsettings.json section.
/// </summary>
public class AppSettingsContent : IContent
{
    /// <summary>
    /// Section name.
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// Configuration object to be serialized into a designated section of the appsettings.json file.
    /// </summary>
    public Type Object { get; set; } = null!;
}
