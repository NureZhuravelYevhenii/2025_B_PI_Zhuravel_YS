﻿namespace AspNet.Helpers;

/// <summary>
/// The <see cref="ReadyToPrintTypes"/> static class contains a dictionary that maps C# data types
/// to functions that return their default string representations. It includes types such as
/// <c>string</c>, <c>bool</c>, <c>char</c>, <c>byte</c> etc.
/// </summary>
public static class ReadyToPrintTypes
{
    public static IDictionary<Type, Func<string>> TypePrinters { get; set; } = new Dictionary<Type, Func<string>>
    {
        { typeof(string), () => "\"\"" },
        { typeof(bool), () => default(bool).ToString().ToLower() },
        { typeof(char), () => "\"\"" },
        { typeof(byte), () => default(byte).ToString() },
        { typeof(int), () => default(int).ToString() },
        { typeof(long), () => default(long).ToString() },
        { typeof(decimal), () => default(decimal).ToString() },
    };
}
