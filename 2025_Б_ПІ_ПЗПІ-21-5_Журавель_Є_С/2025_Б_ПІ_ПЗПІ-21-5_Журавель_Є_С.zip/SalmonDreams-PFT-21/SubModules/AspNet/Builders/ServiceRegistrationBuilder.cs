﻿using AspNet.Abstractions;
using DotNetModule.Contents;
using DotNetModule.Entities;
using System.Text;
using GeneralHelpers;

namespace AspNet.Builders;

public class ServiceRegistrationBuilder : IServiceRegistrationBuilder
{
    private const int TAB_SIZE = 8;

    private IEnumerable<string> _usings;
    private IEnumerable<Dependency> _dependencies = [];

    private bool _useAutofac;
    private bool _useLocalization;
    private bool _useSwagger;
    private bool _useCors;

    private string _serviceRegistration;

    private readonly StringBuilder _content;

    public ServiceRegistrationBuilder()
    {
        _usings = [];
        _serviceRegistration = string.Empty;

        _content = new StringBuilder();
    }

    public IServiceRegistrationBuilder WithUsings(IEnumerable<string> usings)
    {
        _usings = usings;
        return this;
    }

    public IServiceRegistrationBuilder WithAutofac()
    {
        _useAutofac = true;
        _usings = _usings.Append("using Autofac.Extensions.DependencyInjection;");
        return this;
    }

    public IServiceRegistrationBuilder WithServiceRegistration(string serviceRegistration)
    {
        _serviceRegistration = serviceRegistration;
        return this;
    }

    public IServiceRegistrationBuilder WithLocalization()
    {
        _useLocalization = true;
        return this;
    }

    public IServiceRegistrationBuilder WithCors()
    {
       _useCors = true;
        return this;
    }

    public IServiceRegistrationBuilder WithSwagger()
    {
       _useSwagger = true;
        return this;
    }

    public IServiceRegistrationBuilder WithDependencies(IEnumerable<Dependency> dependencies)
    {
        _dependencies = dependencies;
        return this;
    }

    public FileContent Build()
    {
        AddUsings();
        AddLayout();        

        return CreateFileContent();
    }

    private void AddUsings()
    {
        AddBaseUsings();
        AddCustomUsings();
    }

    private void AddBaseUsings()
    {
        AppendToContent(new[]
        {
            "using Microsoft.AspNetCore.Builder;",
            "using Microsoft.Extensions.DependencyInjection;",
            "using AutoMapper;",
            "using Microsoft.OpenApi.Models;"
        });
    }

    private void AddCustomUsings()
    {
        foreach (var u in _usings)
            AppendToContent(u);

        AppendToContent(string.Empty);
    }

    private void AddLayout()
    {
        AppendToContent(new[]
        {
            "namespace Web.Middleware;",
            "public static class MiddlewareExtensions",
            "{",
            "    public static WebApplicationBuilder DefaultConfiguration(this WebApplicationBuilder builder)",
            "    {",
        });


        AddControllers();
        AddCustomLayout();

        AppendToContent(new[]
        {
            "        return builder;",
            "    }",
            "}",
        });
    }

    private void AddControllers()
    {
        AppendToContent(
        [
            "builder.Services.AddControllers();",
            ""
        ], TAB_SIZE);
    }

    private void AddSwagger()
    {
        AppendToContent(
        [
            "builder.Services.AddEndpointsApiExplorer();",
            "builder.Services.AddSwaggerGen();"
        ], TAB_SIZE);
    }

    private void AddCustomLayout()
    {
        AppendToContent(_serviceRegistration.ShiftEachLineWithIndentation(TAB_SIZE));

        if (_useSwagger)
            AddSwagger();

        if (_useAutofac)
            AddAutofac();

        if (_useCors)
            AddCors();

        if (_useLocalization)
            AddLocalization();
    }

    private void AddLocalization()
    {
        AppendToContent(new[]
        {
            "#region Localization",
            "builder.Services.AddLocalization();",
            "builder.Services.Configure<RequestLocalizationOptions>(options =>",
            "{",
            "    var supportedCultures = new List<CultureInfo>",
            "    {",
            "        new CultureInfo(\"en-US\")",
            "        {",
            "            DateTimeFormat = { LongTimePattern = \"MM/DD/YYYY\", ShortTimePattern = \"MM/DD/YYYY \" }",
            "        },",
            "        new CultureInfo(\"uk-UA\")",
            "        {",
            "            DateTimeFormat = { LongTimePattern = \"DD/MM/YYYY\", ShortTimePattern = \"DD/MM/YYYY\" }",
            "        },",
            "    };",
            "    options.DefaultRequestCulture = new RequestCulture(culture: \"uk-UA\", uiCulture: \"uk-UA\");",
            "    options.SupportedCultures = supportedCultures;",
            "    options.SupportedUICultures = supportedCultures;",
            "});",
            "",
            "builder.Services.AddMvc()",
            "    .AddDataAnnotationsLocalization(options =>",
            "    {",
            "        options.DataAnnotationLocalizerProvider = (type, factory) =>",
            "            factory.Create(typeof(Resources));",
            "    });",
            "#endregion"
        }, TAB_SIZE);
    }

    private void AddAutofac()
    {
        AppendToContent("builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());".ShiftEachLineWithIndentation(TAB_SIZE));
    }

    private void AddCors()
    {
        AppendToContent(new[]
        {
            "builder.Services.AddCors(option =>",
            "{",
            "    option.AddPolicy(name: \"MyOrigins\", builder =>",
            "    {",
            "        builder.AllowAnyOrigin()",
            "               .AllowAnyMethod()",
            "               .AllowAnyHeader();",
            "    });",
            "});"
        }, TAB_SIZE);
    }

    private void AppendToContent(string line, int indent = 0)
    {
        _content.AppendLine(line.ShiftEachLineWithIndentation(indent));
    }

    private void AppendToContent(IEnumerable<string> lines, int indent = 0)
    {
        foreach (var line in lines)
            AppendToContent(line, indent);
    }

    private FileContent CreateFileContent()
    {
        return new FileContent
        {
            Location = $"Web/Middleware/MiddlewareExtensions.cs",
            Content = _content.ToString(),
            Dependencies = _dependencies,
        };
    }
}
