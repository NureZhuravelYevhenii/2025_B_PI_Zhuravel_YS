﻿using AspNet.Abstractions;
using DotNetModule.Contents;
using DotNetModule.Entities;
using System.Text;

namespace AspNet.Builders;

public class StartupBuilder : IStartupBuilder
{
    private readonly StringBuilder _content;

    private IEnumerable<string> _usings;
    private string _middleWare;
    private IEnumerable<Dependency> _dependencies = [];

    public StartupBuilder()
    {
        _usings = [];
        _content = new StringBuilder();
        _middleWare = string.Empty;
    }

    public IStartupBuilder WithUsings(IEnumerable<string> usings)
    {
        _usings = usings;
        return this;
    }

    public IStartupBuilder WithMiddleware(string middleware)
    {
        _middleWare = middleware;
        return this;
    }

    public IStartupBuilder WithDependencies(IEnumerable<Dependency> dependencies)
    {
        _dependencies = dependencies;
        return this;
    }

    public FileContent Build()
    {
        AddUsings();
        AddLayout();

        return CreateFileContent();
    }

    private void AddUsings()
    {
        AddBaseUsings();
        AddCustomUsings();
    }

    private void AddLayout()
    {
        AddBaseLayout();
        AddCustomLayout();

        _content.AppendLine("app.Run();");
    }

    private void AddBaseUsings()
    {
        AppendToContent(
        [
            "using Microsoft.AspNetCore.Builder;",
            "using Microsoft.Extensions.Hosting;",
            "using Web.Middleware;",
        "",
        ]);
    }

    private void AddBaseLayout()
    {
        AppendToContent(
        [
            "var builder = WebApplication.CreateBuilder(args);",
            "builder.DefaultConfiguration();",
            "",
            "var app = builder.Build();",
            "app.MapControllers();",
            "app.UseRouting();",
            "app.UseHttpsRedirection();",
            "app.UseCors(builder => builder.AllowAnyHeader().AllowAnyHeader().AllowAnyOrigin());",
            "",
        ]);

        AddSwagger();
    }

    private void AddSwagger()
    {
        AppendToContent(new[]
        {
            "if (app.Environment.IsDevelopment()) ",
            "{",
            "    app.UseSwagger();",
            "    app.UseSwaggerUI();",
            "}",
            ""
        });
    }

    private void AddCustomLayout()
    {
        AppendToContent(_middleWare);
    }

    private void AddCustomUsings()
    {
        foreach (var u in _usings)
            AppendToContent($"using {u};");
    }

    private void AppendToContent(string line)
    {
        _content.AppendLine(line);
    }

    private void AppendToContent(IEnumerable<string> lines)
    {
        foreach (var line in lines)
            AppendToContent(line);
    }

    private FileContent CreateFileContent()
    {
        return new FileContent
        {
            Location = $"Web/Startup.cs",
            Content = _content.ToString(),
            Dependencies = _dependencies,
        };
    }
}
