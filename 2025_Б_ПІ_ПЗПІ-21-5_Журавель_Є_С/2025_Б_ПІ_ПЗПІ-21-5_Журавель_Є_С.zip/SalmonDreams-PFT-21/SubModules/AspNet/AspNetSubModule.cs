﻿using AspNet.Builders;
using AspNet.Contents;
using AspNet.Helpers;
using DotNetModule.Contents;
using DotNetModule.Entities;
using GeneralHelpers;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using System.Reflection;
using System.Text;

namespace AspNet;

/// <summary>
/// Provides functionality for generating <see cref="IContent" /> for ASP.NET application.
/// </summary>
public class AspNetSubModule : BaseSubModule<AspNetProperties>
{
    private readonly Lazy<Assembly> Assembly = new Lazy<Assembly>(() => typeof(AspNetSubModule).Assembly);

	private readonly ICollection<Dependency> _dependencies = new HashSet<Dependency>();
	private readonly ICollection<string> _startupUsings = new HashSet<string>();
	private readonly StringBuilder _middlewareRegistrations = new StringBuilder();

	private readonly ICollection<string> _serviceRegistrationUsings = new HashSet<string>();
	private readonly StringBuilder _serviceRegistrations = new StringBuilder();

    private readonly ICollection<AppSettingsContent> _appSettingsContents = new List<AppSettingsContent>();

    public AspNetSubModule()
	{
        RegisterHandler<StartupContent>(StartupContentHandler);
        RegisterHandler<ServiceRegistrationContent>(ServiceRegistrationHandler);
        RegisterHandler<ControllerContent>(ControllerContentHandler);
        RegisterHandler<AppSettingsContent>(AppSettingsContentHandler);
	}

    public async override Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token))
            .Concat(
            [
                GenerateServiceRegistrationMiddlewareFile(),
                GenerateStartupFile(),
                GenerateAppSettings(),
                await GeneratePropertiesFile(),
                GenerateProjectRelationContents(),
            ])
            .ToList();
    }

    private Task StartupContentHandler(StartupContent content, IEnumerable<IContent> contents)
	{
        AddDepenencies(content.Dependencies);

        foreach (var @using in content.Usings)
            _startupUsings.Add(@using);

        _middlewareRegistrations.AppendLine(content.MiddlewareRegistration);
        return Task.CompletedTask;
	}

    private Task ServiceRegistrationHandler(ServiceRegistrationContent content, IEnumerable<IContent> contents)
    {
        AddDepenencies(content.Dependencies);

        foreach (var @using in content.Usings)
            _serviceRegistrationUsings.Add(@using);

        _serviceRegistrations.AppendLine(content.ServiceRegistration);
        return Task.CompletedTask;
    }

    private Task ControllerContentHandler(ControllerContent content, ICollection<IContent> contents)
    {
        contents.Add(
            new FileContent
            {
                Content = content.Content,
                Location = $"Web/Controllers/{content.Name}Controller.cs",
            }
        );

        return Task.CompletedTask;
    }

    private Task AppSettingsContentHandler(AppSettingsContent content, IEnumerable<IContent> contents)
    {
        _appSettingsContents.Add(content);
        return Task.CompletedTask;
    }

    private FileContent GenerateServiceRegistrationMiddlewareFile()
    {
        AddDepenencies(GetMiddlewareDependencies());

        return new ServiceRegistrationBuilder()
            .WithUsings(_serviceRegistrationUsings)
            .WithAutofac()
            .WithServiceRegistration(_serviceRegistrations.ToString())
            .WithCors()
            .WithSwagger()
            .WithDependencies(_dependencies)
            .Build();
    }

    private IEnumerable<Dependency> GetMiddlewareDependencies()
    {
        var dependencies = new List<Dependency>
        {
            new Dependency
            {
                Include = "Autofac",
                Version = "8.0.0"
            },
            new Dependency
            {
                Include = "Autofac.Extensions.DependencyInjection",
                Version = "9.0.0"
            },
            new Dependency
            {
                Include = "Microsoft.AspNetCore.Authentication.JwtBearer",
                Version = "8.0.8"
            },
            new Dependency
            {
                Include = "Microsoft.EntityFrameworkCore.Design",
                Version = "8.0.8",
                Properties =
                {
                    { "PrivateAssets", "all" },
                    { "IncludeAssets", "runtime; build; native; contentfiles; analyzers; buildtransitive" }
                }
            },
            new Dependency
            {
                Include = "Swashbuckle.AspNetCore",
                Version = "6.7.1"
            }
        };

        return dependencies;
    }

    private void AddDepenencies(IEnumerable<Dependency> dependencies)
    {
        foreach (var dependency in dependencies)
            _dependencies.Add(dependency);
    }

    private FileContent GenerateStartupFile()
    {
        return new StartupBuilder()
            .WithUsings(_startupUsings)
            .WithMiddleware(_middlewareRegistrations.ToString())
            .Build();
    }

    private async Task<FileContent> GeneratePropertiesFile()
    {
        return new FileContent
        {
            Location = "Web/Properties/launchSettings.json",
            Content = await Assembly.Value.GetResource("launchSettings.json"),
        };
    }

    private FileContent GenerateAppSettings()
    {
        var configurationSections = _appSettingsContents
            .Select(asc => GenerateConfigurationSection(asc.Title, asc.Object));

        return new FileContent
        {
            Location = "Web/appsettings.json",
            Content = $"{{\r\n{string.Join(",\r\n", configurationSections)}\r\n}}"
        };
    }

    private string GenerateConfigurationSection(string name, Type type, int indent = 4)
    {
        var section = new StringBuilder($"\"{name}\": ");

        if (TryGetTypeDefaultValue(type, section))
            return section.ToString().ShiftEachLineWithIndentation(indent);

        section.Append("{\r\n");
        AppendProperties(type, section, indent);
        section.Append("\r\n}");

        return section.ToString().ShiftEachLineWithIndentation(indent);
    }

    private bool TryGetTypeDefaultValue(Type type, StringBuilder section)
    {
        if (ReadyToPrintTypes.TypePrinters.TryGetValue(type, out Func<string>? printer)
            && printer is not null)
        {
            section.Append(printer());
            return true;
        }

        return false;
    }

    private void AppendProperties(Type type, StringBuilder section, int indent)
    {
        bool isFirst = true;
        foreach (var property in type.GetProperties())
        {
            var subSection = GenerateConfigurationSection(property.Name, property.PropertyType, indent);
            if (isFirst)
                isFirst = false;
            else
                section.Append(",\r\n");

            section.Append(subSection);
        }
    }

    private IContent GenerateProjectRelationContents()
    {
        return new ProjectRelationContent
        {
            ProjectName = "Web",
            ProjectDependencies = [
                "BLL",
                "DAL",
                "Common"
            ],
        };
    }
}
