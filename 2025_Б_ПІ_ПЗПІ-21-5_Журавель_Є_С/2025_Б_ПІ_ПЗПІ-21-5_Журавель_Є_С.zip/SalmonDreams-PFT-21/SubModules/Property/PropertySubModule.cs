﻿using GeneralHelpers;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;

namespace Property;

/// <summary>
/// Provides functionality for defining entity properties in the application.
/// </summary>
public class PropertySubModule : BaseSubModule<PropertyProperties>
{
    public override Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        var properties = Properties as PropertyProperties;
        if (properties is null)
            return Task.FromResult(new List<IContent>().AsEnumerable());

        return Task.FromResult(new List<IContent>
        {
            new PropertyContent
            {
                Name = properties.Name.ReplaceMultipleSpaces(),
                PropertyType = properties.Type,
            }
        }.AsEnumerable());
    }
}
