﻿using MainAbstractions.Modules.Content;

namespace Property;

/// <summary>
/// Represents the definition of a property, including its type and name.
/// </summary>
public class PropertyContent : IContent
{
    /// <summary>
    /// Property name.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Property type.
    /// </summary>
    public PropertyType PropertyType { get; set; }
}
