﻿namespace Property;

/// <summary>
/// Represents the possible types of properties in the application.
/// </summary>
public enum PropertyType
{
    Int,
    Long,
    Decimal,
    Bool,
    String,
    DateTime
}
