﻿using MainAbstractions.Modules.Metadata;

namespace Property;

/// <summary>
/// Represents the components for property creation.
/// </summary>
public class PropertyProperties : IModuleProperties
{
    /// <summary>
    /// Property name.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Representation of a <see cref="PropertyProperties.Type"> as enum.
    /// </summary>
    public PropertyType Type { get; set; }
}
