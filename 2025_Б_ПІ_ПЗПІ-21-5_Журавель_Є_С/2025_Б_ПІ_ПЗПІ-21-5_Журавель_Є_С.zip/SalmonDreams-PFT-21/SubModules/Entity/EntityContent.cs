﻿using MainAbstractions.Modules.Content;
using Property;

namespace Entity;

/// <summary>
/// Represents the definition of an entity.
/// </summary>
public class EntityContent : IContent
{
    /// <summary>
    /// Entity name.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Entity properties.
    /// </summary>
    public ICollection<PropertyContent> Properties { get; set; } = new List<PropertyContent>();
}
