﻿using MainAbstractions.Modules.Metadata;

namespace Entity;

/// <summary>
/// Represents the components for entity creation.
/// </summary>
public class EntityProperties : IModuleProperties
{
    /// <summary>
    /// Entity name.
    /// </summary>
    public string Name { get; set; } = string.Empty;
}
