﻿using Entity.Comparators;
using GeneralHelpers;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using Property;

namespace Entity;

/// <summary>
/// Provides functionality for defining entities in the application.
/// </summary>
public class EntitySubModule : BaseSubModule<EntityProperties>
{
    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        var contents = await ModuleHelper.ExecuteSubModulesAsync(Modules, token);
        if (PropertiesWithType is null)
            return contents;

        var entityContent = CreateEntityContent(contents);
        return contents.Append(entityContent).ToList();
    }

    private IContent CreateEntityContent(IEnumerable<IContent> contents)
    {
        var entityContent = new EntityContent
        {
            Name = PropertiesWithType.Name.ReplaceMultipleSpaces()
        };

        var uniqueProperties = contents
            .OfType<PropertyContent>()
            .Where(pc => pc.Name != PropertiesWithType.Name)
            .Distinct(new PropertyContentComparator())
            .ToList();

        entityContent.Properties = uniqueProperties;

        return entityContent;
    }
}
