﻿using Property;
using System.Diagnostics.CodeAnalysis;

namespace Entity.Comparators;

public class PropertyContentComparator : IEqualityComparer<PropertyContent>
{
    public bool Equals(PropertyContent? x, PropertyContent? y)
    {
        return x?.Name == y?.Name;
    }

    public int GetHashCode([DisallowNull] PropertyContent obj)
    {
        return obj.Name.GetHashCode();
    }
}
