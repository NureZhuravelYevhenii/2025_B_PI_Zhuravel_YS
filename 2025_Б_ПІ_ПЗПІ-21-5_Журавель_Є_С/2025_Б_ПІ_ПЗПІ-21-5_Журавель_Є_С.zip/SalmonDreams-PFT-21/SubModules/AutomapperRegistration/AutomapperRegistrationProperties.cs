﻿using MainAbstractions.Modules.Metadata;

namespace AutomapperRegistration;

/// <summary>
/// Represents the components relevant for registration Automapper profiles.
/// </summary>
public class AutomapperRegistrationProperties : IModuleProperties { }
