﻿using MainAbstractions.Modules.Content;

namespace AutomapperRegistration;

/// <summary>
/// Components relevant for Automapper registration.
/// </summary>
public class AutomapperRegistrationContent : IContent
{
    /// <summary>
    /// Collection of Automapper profiles to register.
    /// </summary>
    public IEnumerable<string> AutomapperAssemblies { get; set; } = [];
}
