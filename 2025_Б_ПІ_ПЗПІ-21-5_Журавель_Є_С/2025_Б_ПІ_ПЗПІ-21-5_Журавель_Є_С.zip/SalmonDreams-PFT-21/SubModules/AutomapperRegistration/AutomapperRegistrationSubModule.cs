﻿using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using AspNet.Contents;

namespace AutomapperRegistration;

/// <summary>
/// Provides functionality for registering AutoMapper profiles in the application,
/// facilitating object-object mapping for .NET applications using the AutoMapper library.
/// </summary>
public class AutomapperRegistrationSubModule : BaseSubModule<AutomapperRegistrationProperties>
{
    private readonly HashSet<string> _profileAssemblies = [];

	public AutomapperRegistrationSubModule()
	{
		RegisterHandler<AutomapperRegistrationContent>(AutomapperContentHandler);
	}

	public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
	{
		return (await base.ParseInCodeAsync(token))
			.Append(GetServiceRegistrationContent())
			.ToList();
	}

    #region Private methods

    private Task AutomapperContentHandler(AutomapperRegistrationContent content, ICollection<IContent> contents)
    {
        foreach (var profileAssembly in content.AutomapperAssemblies)
            _profileAssemblies.Add(profileAssembly);

        return Task.CompletedTask;
    }

    private IContent GetServiceRegistrationContent()
    {
        var mapperConfigSection = GenerateMapperConfigSection();

        return new ServiceRegistrationContent
        {
            ServiceRegistration = $@"
#region Init Mapper Profiles

{mapperConfigSection}

var mapper = mapperConfig.CreateMapper();
builder.Services.AddSingleton(mapper);

#endregion"
        };
    }

    private string GenerateMapperConfigSection()
    {
        var profiles = string.Join(",", _profileAssemblies.Distinct().Select(p => $"\"{p}\""));
        return $@"
var mapperConfig = new MapperConfiguration(cfg =>
{{
    cfg.AddMaps(new[]
    {{
        {profiles}
    }});
}});";
    }

    #endregion
}
