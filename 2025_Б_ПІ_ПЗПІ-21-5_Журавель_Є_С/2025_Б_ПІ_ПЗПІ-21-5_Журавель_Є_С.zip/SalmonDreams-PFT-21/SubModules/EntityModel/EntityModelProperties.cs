﻿using MainAbstractions.Modules.Metadata;

namespace EntityModel;

/// <summary>
/// Represents the components for entity DTO creation.
/// </summary>
public class EntityModelProperties : IModuleProperties
{
    /// <summary>
    /// Entity properties that will be visible in DTO.
    /// </summary>
    public IEnumerable<string> Properties { get; set; } = [];
}