﻿using MainAbstractions.Modules.Content;
using Property;

namespace EntityModel;

/// <summary>
/// Represents the definition of an entity DTO.
/// </summary>
public class EntityModelContent : IContent
{
    /// <summary>
    /// Entity name.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Entity properties.
    /// </summary>
    public IEnumerable<PropertyContent> Properties { get; set; } = [];
}
