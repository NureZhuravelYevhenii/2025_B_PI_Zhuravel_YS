﻿using Entity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;

namespace EntityModel;

/// <summary>
/// Provides functionality for defining entity DTOs in the application.
/// </summary>
public class EntityModelSubModule : BaseSubModule<EntityModelProperties>
{
	public EntityModelSubModule()
	{
		RegisterHandler<EntityContent>(PropertyContentHandler);
	}

	private Task PropertyContentHandler(EntityContent content, ICollection<IContent> contents)
	{
		if (PropertiesWithType is null)
			return Task.FromResult(contents);

        contents.Add(new EntityModelContent
        {
			Name = content.Name,
            Properties = content.Properties.Where(property => PropertiesWithType.Properties.Contains(property.Name)),
        });

        return Task.CompletedTask;
	}
}
