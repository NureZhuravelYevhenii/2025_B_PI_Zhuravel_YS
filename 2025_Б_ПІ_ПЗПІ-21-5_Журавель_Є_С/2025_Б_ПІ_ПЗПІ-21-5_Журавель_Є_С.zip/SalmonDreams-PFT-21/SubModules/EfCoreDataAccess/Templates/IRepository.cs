﻿using DAL.Entities.BaseEntities;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

#nullable enable

namespace DAL.Abstractions;

/// <summary>
/// Repository.
/// </summary>
/// <typeparam name="TEntity">Entity type for which the repository performs actions.</typeparam>
public interface IRepository<TEntity> where TEntity : BaseEntity
{
    /// <summary>
    /// Asynchronously retrieves an entity by its ID.
    /// </summary>
    /// <param name="id">The ID of the entity to retrieve.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the entity if found; otherwise, null.</returns>
    Task<TEntity?> GetByIdAsync(int id, CancellationToken token = default);

    /// <summary>
    /// Asynchronously retrieves the first entity that matches the specified predicate.
    /// </summary>
    /// <param name="predicate">The predicate to match entities.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the first matching entity if found; otherwise, null.</returns>
    Task<TEntity?> GetByPredicateFirstAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken token = default);

    /// <summary>
    /// Asynchronously retrieves all entities that match the specified predicate with optional pagination.
    /// </summary>
    /// <param name="predicate">The predicate to match entities.</param>
    /// <param name="skip">The number of entities to skip.</param>
    /// <param name="take">The number of entities to take.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains a queryable collection of matching entities.</returns>
    Task<IQueryable<TEntity>> GetByPredicateAsync(Expression<Func<TEntity, bool>> predicate, int skip = 0, int take = int.MaxValue, CancellationToken token = default);

    /// <summary>
    /// Asynchronously retrieves all entities with optional pagination.
    /// </summary>
    /// <param name="skip">The number of entities to skip.</param>
    /// <param name="take">The number of entities to take.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains a queryable collection of entities.</returns>
    Task<IQueryable<TEntity>> GetAllAsync(int skip = 0, int take = int.MaxValue, CancellationToken token = default);

    /// <summary>
    /// Asynchronously adds a new entity.
    /// </summary>
    /// <param name="entity">The entity to add.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task AddAsync(TEntity entity, CancellationToken token = default);

    /// <summary>
    /// Asynchronously updates an existing entity.
    /// </summary>
    /// <param name="entity">The entity to update.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task UpdateAsync(TEntity entity, CancellationToken token = default);

    /// <summary>
    /// Asynchronously deletes an existing entity.
    /// </summary>
    /// <param name="entity">The entity to delete.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    Task DeleteAsync(int id, CancellationToken token = default);
}
