﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace DAL.DesignTimeTypes;

public class DesignTimeFactory : IDesignTimeDbContextFactory<BaseDbContext>
{
    public BaseDbContext CreateDbContext(string[] args)
    {
        var configurations = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", false)
            .Build();

        var options = new DbContextOptionsBuilder<BaseDbContext>()
            .UseSqlServer(configurations.GetConnectionString("MainConnectionString"))
            .Options;

        return new BaseDbContext(options);
    }
}
