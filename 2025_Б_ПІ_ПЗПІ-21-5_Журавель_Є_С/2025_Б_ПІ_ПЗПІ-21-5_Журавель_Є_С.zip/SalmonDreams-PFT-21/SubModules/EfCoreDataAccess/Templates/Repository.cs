﻿using DAL.Abstractions;
using DAL.Entities.BaseEntities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

#nullable enable

namespace DAL;

/// <summary>
/// Repository class for performing actions on entities.
/// </summary>
/// <typeparam name="TEntity">The type of entity that the repository manages.</typeparam>
public class Repository<TEntity> : IRepository<TEntity> where TEntity : BaseEntity
{
    private readonly BaseDbContext _dbContext;
    private readonly DbSet<TEntity> _dbSet;

    /// <summary>
    /// Initializes a new instance of the <see cref="Repository{TEntity}"/> class.
    /// </summary>
    /// <param name="dbContext">The database context to be used.</param>
    public Repository(BaseDbContext dbContext)
    {
        _dbContext = dbContext;
        _dbSet = dbContext.Set<TEntity>();
    }

    /// <summary>
    /// Asynchronously adds a new entity.
    /// </summary>
    /// <param name="entity">The entity to add.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task AddAsync(TEntity entity, CancellationToken token = default)
    {
        await _dbSet.AddAsync(entity);
        await _dbContext.SaveChangesAsync();
    }

    /// <summary>
    /// Asynchronously deletes an existing entity.
    /// </summary>
    /// <param name="entity">The entity to delete.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task DeleteAsync(int id, CancellationToken token = default)
    {
        var entity = await GetByIdAsync(id, token);

        if (entity is null)
            return;

        _dbSet.Remove(entity);
        await _dbContext.SaveChangesAsync();
    }

    /// <summary>
    /// Asynchronously retrieves all entities with optional pagination.
    /// </summary>
    /// <param name="skip">The number of entities to skip.</param>
    /// <param name="take">The number of entities to take.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains a queryable collection of entities.</returns>
    public Task<IQueryable<TEntity>> GetAllAsync(int skip = 0, int take = int.MaxValue, CancellationToken token = default)
    {
        return Task.FromResult(_dbSet.Skip(skip).Take(take));
    }

    /// <summary>
    /// Asynchronously retrieves an entity by its ID.
    /// </summary>
    /// <param name="id">The ID of the entity to retrieve.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the entity if found; otherwise, null.</returns>
    public Task<TEntity?> GetByIdAsync(int id, CancellationToken token = default)
    {
        return _dbSet.FirstOrDefaultAsync(entity => entity.Id == id, token);
    }

    /// <summary>
    /// Asynchronously retrieves all entities that match the specified predicate with optional pagination.
    /// </summary>
    /// <param name="predicate">The predicate to match entities.</param>
    /// <param name="skip">The number of entities to skip.</param>
    /// <param name="take">The number of entities to take.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains a queryable collection of matching entities.</returns>
    public Task<IQueryable<TEntity>> GetByPredicateAsync(Expression<Func<TEntity, bool>> predicate, int skip = 0, int take = int.MaxValue, CancellationToken token = default)
    {
        return Task.FromResult(_dbSet.Where(predicate).Skip(skip).Take(take));
    }

    /// <summary>
    /// Asynchronously retrieves the first entity that matches the specified predicate.
    /// </summary>
    /// <param name="predicate">The predicate to match entities.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation. The task result contains the first matching entity if found; otherwise, null.</returns>
    public Task<TEntity?> GetByPredicateFirstAsync(Expression<Func<TEntity, bool>> predicate, CancellationToken token = default)
    {
        return _dbSet.FirstOrDefaultAsync(predicate, token);
    }

    /// <summary>
    /// Asynchronously updates an existing entity.
    /// </summary>
    /// <param name="entity">The entity to update.</param>
    /// <param name="token">A cancellation token to observe while waiting for the task to complete.</param>
    /// <returns>A task that represents the asynchronous operation.</returns>
    public async Task UpdateAsync(TEntity entity, CancellationToken token = default)
    {
        var existingEntity = await GetByIdAsync(entity.Id, token);

        if (existingEntity is null)
            return;

        var entityEntry = _dbSet.Entry(existingEntity);
        entityEntry.CurrentValues.SetValues(entity);
        await _dbContext.SaveChangesAsync();
    }
}

