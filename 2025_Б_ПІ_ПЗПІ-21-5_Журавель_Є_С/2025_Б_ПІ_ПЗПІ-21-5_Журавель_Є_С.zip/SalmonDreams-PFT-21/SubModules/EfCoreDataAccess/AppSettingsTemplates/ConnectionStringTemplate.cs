﻿namespace EfCoreDataAccess.AppSettingsTemplates;

public class ConnectionStringTemplate
{
    public string MainConnectionString { get; set; } = string.Empty;
}
