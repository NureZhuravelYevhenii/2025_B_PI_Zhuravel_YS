﻿using DotNetModule.Contents;
using DotNetModule.Entities;
using Entity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using Microsoft.EntityFrameworkCore;
using Relation;
using SharpCodeGenerator;
using SharpCodeGenerator.Entities;
using SharpCodeGenerator.Entities.Enums;
using System.Reflection;
using PropertySubModuleHelpers;
using GeneralHelpers;
using AspNet.Contents;
using EfCoreDataAccess.AppSettingsTemplates;
using DotNetModule.Contents.FileContentEntities;

namespace EfCoreDataAccess;

/// <summary>
/// Generates Entity Framework Core (EF Core) data access components.
/// This includes generating the DbContext and repository implementations for handling 
/// data operations related to specific entities in the application.
/// </summary>
public class EfCoreDataAccessSubModule : BaseSubModule<EfCoreDataAccessProperties>
{
    private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(EfCoreDataAccessSubModule).Assembly);
    private readonly Lazy<StringCodeGenerator> _stringGenerator = new Lazy<StringCodeGenerator>();

    private readonly ICollection<string> _entities = new HashSet<string>();
    private readonly ICollection<RelationContent> _relationContents = new List<RelationContent>();
    private readonly IDictionary<string, SharpCodeGenerator.Entities.File> _entityFiles = new Dictionary<string, SharpCodeGenerator.Entities.File>();

    public EfCoreDataAccessSubModule()
    {
        RegisterHandler<EntityContent>(EntityContentHandler);
        RegisterHandler<RelationContent>(RelationContentHandler);
    }

    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token))
            .Concat(await AddEntityFiles())
            .Concat([
                await GenerateStartupRegistration(),
                await GenerateDbContext(),
                await GenerateBaseRepository(),
                await GenerateRepositoryAbstraction(),
                await GenerateBaseEntity(),
                await GetDesignTimeFactories(),
                GetAppSettingsContent(),
                GetFakeAppSettings(),
            ])
            .ToList();
    }

    private Task EntityContentHandler(EntityContent content, IEnumerable<IContent> contents)
    {
        if (_entities.Contains(content.Name))
            content.Name += Guid.NewGuid();

        _entities.Add(content.Name);
        var @class = new Class
        {
            Name = content.Name,
            AccessModifier = AccessModifier.Public,
            InheritedClassString = "BaseEntity",
        };

        @class.Properties = GetEntityProperties(content);
        _entityFiles.Add(content.Name, GetEntityFile(@class));

        return Task.CompletedTask;
    }

    private Task RelationContentHandler(RelationContent content, IEnumerable<IContent> contents)
    {
        _relationContents.Add(content);
        return Task.CompletedTask;
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> GetEntityProperties(EntityContent content)
    {
        return content.Properties.Select(property =>
        {
            return new SharpCodeGenerator.Entities.Property
            {
                AccessModifier = AccessModifier.Public,
                Name = property.Name,
                Type = property.PropertyType.GetTypeFromPropertyType()
                   ?? throw new ArgumentNullException($"Unable to create property {property.Name} because unable to resolve type {property.PropertyType} in entity {content.Name}"),
            };
        });
    }

    private SharpCodeGenerator.Entities.File GetEntityFile(Class @class)
    {
        return new SharpCodeGenerator.Entities.File
        {
            NamespaceName = "DAL.Entities",
            Usings =
            [
                new Using
                {
                    Name = "DAL.Entities.BaseEntities"
                }
            ],
            Classes =
            [
                @class
            ],
        };
    }

    private async Task<IEnumerable<IContent>> AddEntityFiles()
    {
        EnsureNoRelationLoop();

        var contents = new List<IContent>();
        var relationBaseGroups = _relationContents.GroupBy(rel => rel.BaseEntity);
        var relationSecondaryGroups = _relationContents.GroupBy(rel => rel.SecondaryEntity);

        foreach (var entity in _entityFiles)
        {
            var @class = entity.Value.Classes.First();
            var additionalFiles = new List<SharpCodeGenerator.Entities.File>();

            var primaryEntityRelations = relationBaseGroups.FirstOrDefault(group => group.Key == entity.Key);
            @class.Properties = @class.Properties
                .Concat(primaryEntityRelations?
                    .SelectMany(rel => ResolvePropertiesForBaseEntities(rel, additionalFiles)) ?? [])
                .ToList();

            var secondaryEntityRelations = relationSecondaryGroups.FirstOrDefault(group => group.Key == entity.Key);
            @class.Properties = @class.Properties
                .Concat(secondaryEntityRelations?
                        .SelectMany(ResolvePropertiesForSecondaryEntities) ?? [])
                .ToList();

            AddGenericCollectionsUsing(entity, primaryEntityRelations, secondaryEntityRelations);

            contents.Add(await GetEntityFile(entity.Key, entity.Value));
            foreach (var file in additionalFiles)
                contents.Add(await GetEntityFile(file.Classes.First().Name, file));
        }

        return contents;
    }

    private void EnsureNoRelationLoop()
    {
        if (RelationLoopDetector.HasLoop(_relationContents))
            throw new InvalidOperationException("Entity Relation Loop is detected");
    }

    private void AddGenericCollectionsUsing(
        KeyValuePair<string, SharpCodeGenerator.Entities.File> entity,
        IGrouping<string, RelationContent>? primaryEntityRelations,
        IGrouping<string, RelationContent>? secondaryEntityRelations)
    {
        bool requiresGenericCollections =
            primaryEntityRelations?.Any(rel => rel.RelationType is RelationType.ManyToMany or RelationType.OneToMany) == true
            || secondaryEntityRelations?.Any(rel => rel.RelationType == RelationType.ManyToMany) == true;

        if (requiresGenericCollections)
            entity.Value.Usings = entity.Value.Usings.Append(new Using { Name = "System.Collections.Generic" }).ToList();
    }


    private async Task<IContent> GetEntityFile(string entity, SharpCodeGenerator.Entities.File entityFile)
    {
        return new FileContent
        {
            Location = $"DAL/Entities/{entity}.cs",
            Content = await _stringGenerator.Value.GenerateFileAsync(entityFile),
        };
    }

    private async Task<IContent> GenerateStartupRegistration()
    {
        return new ServiceRegistrationContent
        {
            Usings = 
            [
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "DAL.Abstractions"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "DAL"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Microsoft.Extensions.Configuration"
                }),
                await _stringGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "Microsoft.EntityFrameworkCore"
                }),
            ],
            Dependencies = [
                new Dependency{
                    Include = "Microsoft.EntityFrameworkCore.SqlServer",
                    Version = "8.0.7",
                },
            ],
            ServiceRegistration = @"
builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
builder.Services.AddDbContext<BaseDbContext>(optBuilder =>
{
    optBuilder.UseSqlServer(
        builder.Configuration.GetConnectionString(""MainConnectionString"")
    );
});"
        };
    }

    private async Task<IContent> GenerateBaseRepository()
    {
        return new FileContent
        {
            Location = "DAL/Abstractions/Repository.cs",
            Content = await Assembly.Value.GetResource("Repository.cs"),
        };
    }

    private async Task<IContent> GenerateRepositoryAbstraction()
    {
        return new FileContent
        {
            Location = "DAL/Abstractions/IRepository.cs",
            Content = await Assembly.Value.GetResource("IRepository.cs"),
        };
    }

    private async Task<IContent> GenerateBaseEntity()
    {
        return new FileContent
        {
            Location = "DAL/Entities/BaseEntities/BaseEntity.cs",
            Content = await Assembly.Value.GetResource("BaseEntity.cs"),
        };
    }

    private async Task<IContent> GenerateDbContext()
    {
        var dependencies = new List<Dependency>
        {
             new Dependency
             {
                 Include = "Microsoft.EntityFrameworkCore",
                 Version = "8.0.7",
             },
              new Dependency
              {
                  Include = "Microsoft.EntityFrameworkCore.SqlServer",
                  Version = "8.0.7",
              },
              new Dependency
              {
                  Include = "Microsoft.EntityFrameworkCore.Tools",
                  Version = "8.0.7",
                  Properties = new Dictionary<string, string>
                  {
                      { "PrivateAssets", "all" },
                      { "IncludeAssets", "runtime; build; native; contentfiles; analyzers; buildtransitive " }
                  }
              }
        };
               
        return new FileContent
        {
            Location = "DAL/BaseDbContext.cs",
            Content = await CreateDbContextFile(),
            Dependencies = dependencies
        };
    }

    private async Task<string> CreateDbContextFile()
    {
        var file = new SharpCodeGenerator.Entities.File
        {
            Usings =
            [
                new Using
                {
                    Name = "DAL.Entities",
                },
                new Using
                {
                    Name = "Microsoft.EntityFrameworkCore",
                },
            ],
            NamespaceName = "DAL",
            Classes =
            [
                new Class
                {
                    AccessModifier = AccessModifier.Public,
                    InheritedClass = typeof(DbContext),
                    Name = "BaseDbContext",
                    Properties = _entities.Select(entity => new SharpCodeGenerator.Entities.Property
                    {
                        AccessModifier = AccessModifier.Public,
                        Name = $"{entity}s",
                        TypeAsString = $"DbSet<{entity}>",
                    }),
                    Methods =
                    [
                        new Method
                        {
                            Name = "BaseDbContext",
                            AccessModifier = AccessModifier.Public,
                            Parameters =
                            [
                                new Parameter
                                {
                                    Name = "options",
                                    TypeAsString = "DbContextOptions<BaseDbContext>",
                                }
                            ],
                            BaseParameters =
                            [
                                "options"
                            ]
                        }
                    ]
                }
            ]
        };

        return await _stringGenerator.Value.GenerateFileAsync(file);
    }

    private AppSettingsContent GetAppSettingsContent()
    {
        return new AppSettingsContent
        { 
            Object = typeof(ConnectionStringTemplate),
            Title = "ConnectionStrings",
        };
    }

    private FileContent GetFakeAppSettings()
    {
        return new FileContent
        {
            Location = "DAL/appsettings.json",
            Content = "{\"ConnectionStrings\": { \"MainConnectionString\": \"\" } }",
            BuildAction = new BuildAction
            {
                FileName = "appsettings.json",
                Name = "None",
                AdditionalParameters = new Dictionary<string, string>
                {
                    { "CopyToOutputDirectory", "Always" }
                }
            },
        };
    }

    private async Task<FileContent> GetDesignTimeFactories()
    {
        return new FileContent 
        {
            Location = "DAL/DesignTimeTypes/DesignTimeFactory.cs",
            Content = await Assembly.Value.GetResource("DesignTimeFactory.cs"),
            Dependencies = 
            [
                new Dependency
                {
                    Include = "Microsoft.Extensions.Configuration",
                    Version = "8.0.0",
                },
                new Dependency
                {
                    Include = "Microsoft.Extensions.Configuration.Json",
                    Version = "8.0.0",
                },
            ]
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> ResolvePropertiesForBaseEntities(
        RelationContent relationContent,
        ICollection<SharpCodeGenerator.Entities.File> additionalFiles)
    {
        return relationContent.RelationType switch
        {
            RelationType.ManyToMany => ResolveManyToManyProperties(relationContent, additionalFiles),
            RelationType.OneToMany => ResolveOneToManyProperties(relationContent),
            RelationType.OneToOne => Enumerable.Empty<SharpCodeGenerator.Entities.Property>(),
            _ => Enumerable.Empty<SharpCodeGenerator.Entities.Property>(),
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> ResolvePropertiesForSecondaryEntities(RelationContent relationContent)
    {
        return relationContent.RelationType switch
        {
            RelationType.ManyToMany => CreateManyToManyProperties(relationContent),
            RelationType.OneToMany => CreateOneToManyProperties(relationContent),
            RelationType.OneToOne => CreateOneToOneProperties(relationContent),
            _ => Enumerable.Empty<SharpCodeGenerator.Entities.Property>()
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> ResolveManyToManyProperties(
        RelationContent relationContent,
        ICollection<SharpCodeGenerator.Entities.File> additionalFiles)
    {
        var entityName = $"{relationContent.BaseEntity}{relationContent.SecondaryEntity}";
        var file = new SharpCodeGenerator.Entities.File
        {
            NamespaceName = "DAL.Entities",
            Usings = new List<Using>
            {
                new Using { Name = "DAL.Entities.BaseEntities" }
            },
            Classes = new List<Class>
            {
                new Class
                {
                    Name = entityName,
                    AccessModifier = AccessModifier.Public,
                    InheritedClassString = "BaseEntity",
                    Properties = new List<SharpCodeGenerator.Entities.Property>
                    {
                        new SharpCodeGenerator.Entities.Property
                        {
                            AccessModifier = AccessModifier.Public,
                            Name = relationContent.BaseEntity,
                            TypeAsString = relationContent.BaseEntity
                        },
                        new SharpCodeGenerator.Entities.Property
                        {
                            AccessModifier = AccessModifier.Public,
                            Name = relationContent.SecondaryEntity,
                            TypeAsString = relationContent.SecondaryEntity
                        }
                    }
                }
            }
        };

        additionalFiles.Add(file);

        return new List<SharpCodeGenerator.Entities.Property>
        {
            new SharpCodeGenerator.Entities.Property
            {
                AccessModifier = AccessModifier.Public,
                Name = entityName,
                TypeAsString = $"IEnumerable<{entityName}>"
            }
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> ResolveOneToManyProperties(RelationContent relationContent)
    {
        return new List<SharpCodeGenerator.Entities.Property>
        {
            new SharpCodeGenerator.Entities.Property
            {
                AccessModifier = AccessModifier.Public,
                Name = $"{relationContent.SecondaryEntity}s",
                TypeAsString = $"IEnumerable<{relationContent.SecondaryEntity}>"
            }
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> CreateManyToManyProperties(RelationContent relationContent)
    {
        return new[]
        {
            new SharpCodeGenerator.Entities.Property
            {
                AccessModifier = AccessModifier.Public,
                Name = $"{relationContent.BaseEntity}{relationContent.SecondaryEntity}",
                TypeAsString = $"IEnumerable<{relationContent.BaseEntity}{relationContent.SecondaryEntity}>"
            }
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> CreateOneToManyProperties(RelationContent relationContent)
    {
        return new[]
        {
            new SharpCodeGenerator.Entities.Property
            {
                AccessModifier = AccessModifier.Public,
                Name = relationContent.BaseEntity,
                TypeAsString = relationContent.BaseEntity
            }
        };
    }

    private IEnumerable<SharpCodeGenerator.Entities.Property> CreateOneToOneProperties(RelationContent relationContent)
    {
        return new[]
        {
            new SharpCodeGenerator.Entities.Property
            {
                AccessModifier = AccessModifier.Public,
                Name = relationContent.BaseEntity,
                TypeAsString = relationContent.BaseEntity
            }
        };
    }
}
