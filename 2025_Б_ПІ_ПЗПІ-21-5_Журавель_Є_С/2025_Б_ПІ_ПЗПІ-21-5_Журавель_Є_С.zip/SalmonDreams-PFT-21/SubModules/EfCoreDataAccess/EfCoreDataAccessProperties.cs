﻿using MainAbstractions.Modules.Metadata;

namespace EfCoreDataAccess;

/// <summary>
/// Represents the components for creation EF Core data-layer.
/// </summary>
public class EfCoreDataAccessProperties : IModuleProperties { }
