﻿using Entity;
using AspNet.Contents;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using System.Reflection;
using GeneralHelpers;

namespace CrudControllers;

/// <summary>
/// Generates <see cref="ControllerContent"/> for a specific entity controller.
/// </summary>
public class CrudControllersSubModule : BaseSubModule<CrudControllersProperties>
{
	private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(CrudControllersSubModule).Assembly);

	public CrudControllersSubModule()
	{
		RegisterHandler<EntityContent>(EntityContentHandler);
	}

	public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
	{
		return (await base.ParseInCodeAsync(token)).ToList();
	}

	private async Task<IEnumerable<IContent>> EntityContentHandler(EntityContent content, ICollection<IContent> contents)
	{
		contents.Add(new ControllerContent
		{
			Content = (await Assembly.Value.GetResource("Controller.cs")).Replace("Entity", content.Name),
			Name = $"{content.Name}s",
		});

        return contents;
    }
}
