﻿using MainAbstractions.Modules.Metadata;

namespace CrudControllers;

/// <summary>
/// Represents the components for ASP.NET controllers creation.
/// </summary>
public class CrudControllersProperties : IModuleProperties { }
