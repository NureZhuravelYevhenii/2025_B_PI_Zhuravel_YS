﻿using BLL.Abstractions.Services.BaseServices;
using BLL.Entities.EntityModels;
using DAL.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;


namespace Web.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class EntitysController : ControllerBase
    {
        private readonly ICrudService<Entity, EntityModel, EntityCreationModel, EntityIdModel, EntityUpdateModel> _crudService;

        public EntitysController(ICrudService<Entity, EntityModel, EntityCreationModel, EntityIdModel, EntityUpdateModel> crudService)
        {
            _crudService = crudService;
        }

        // POST: api/[controller]
        [HttpPost]
        public async Task<ActionResult<EntityIdModel>> CreateAsync([FromBody] EntityCreationModel creationModel, CancellationToken token)
        {
            var createdId = await _crudService.CreateAsync(creationModel, token);
            return Ok(createdId);
        }

        // GET: api/[controller]/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<EntityModel>> GetByIdAsync(int id, CancellationToken token)
        {
            var entity = await _crudService.GetByIdAsync(id, token);

            if (entity == null)
            {
                return NotFound();
            }

            return Ok(entity);
        }

        // GET: api/[controller]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EntityModel>>> GetAllAsync(int skip = 0, int take = int.MaxValue, CancellationToken token = default)
        {
            var entities = await _crudService.GetAllAsync(skip, take, token);
            return Ok(entities);
        }

        // PUT: api/[controller]
        [HttpPut]
        public async Task<IActionResult> UpdateAsync([FromBody] EntityUpdateModel updateModel, CancellationToken token)
        {
            await _crudService.UpdateAsync(updateModel, token);
            return NoContent();
        }

        // DELETE: api/[controller]/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAsync(int id, CancellationToken token)
        {
            await _crudService.DeleteAsync(id, token);
            return NoContent();
        }
    }
}
