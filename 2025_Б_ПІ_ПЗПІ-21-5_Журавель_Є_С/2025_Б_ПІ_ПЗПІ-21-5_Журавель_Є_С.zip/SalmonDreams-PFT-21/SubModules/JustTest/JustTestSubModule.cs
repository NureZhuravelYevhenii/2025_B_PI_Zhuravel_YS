﻿using MainAbstractions.Modules.BaseClasses;

namespace JustTest;

public class JustTestSubModule : BaseSubModule<JustTestProperties>
{
}
