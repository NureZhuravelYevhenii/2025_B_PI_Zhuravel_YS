﻿using MainAbstractions.Modules.Metadata;

namespace JustTest;

public class JustTestProperties : IModuleProperties
{
}
