﻿namespace BLL.Entities.Identity;

public class EntityModel { }
