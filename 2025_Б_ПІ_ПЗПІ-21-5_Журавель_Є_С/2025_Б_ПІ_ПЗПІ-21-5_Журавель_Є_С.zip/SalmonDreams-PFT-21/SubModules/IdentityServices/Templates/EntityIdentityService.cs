﻿using AutoMapper;
using BLL.Abstractions.Identity;
using BLL.Infrastructure.Helpers;
using BLL.Models.Identity;
using DAL.Abstractions;

namespace BLL.Services.Identity;

public class EntityIdentityService : IEntityIdentityService
{
    private readonly Lazy<IMapper> _mapper;
    private readonly IRepository<DAL.Models.Entity> _repository;

    public EntityIdentityService(
        IRepository<DAL.Models.Entity> repository,
        Lazy<IMapper> mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    public async Task<EntityModel> LoginEntityAsync(LoginEntityModel loginEntityModel, CancellationToken token = default)
    {
        var entity = await _repository.GetByPredicateFirstAsync(x => x.Login == loginEntityModel.Login, token);
        if (entity is null
            || !HashHelper.VerifyPassword(loginEntityModel.Password, entity.PasswordSalt, entity.PasswordHash))
        {
            throw new UnauthorizedAccessException();
        }

        var entityModel = _mapper.Value.Map<EntityModel>(entity);

        return entityModel;
    }

    public async Task RegisterEntityAsync(RegisterEntityModel model, CancellationToken token = default)
    {
        if (await _repository.GetByPredicateFirstAsync(x => x.Login == model.Login, token) is not null)
            throw new ArgumentException("LOGIN_ALREADY_EXISTS");

        var (salt, passwordHash) = HashHelper.GetNewPasswordHash(model.Password);
        var entity = _mapper.Value.Map<DAL.Models.Entity>(model);

        entity.PasswordSalt = salt;
        entity.PasswordHash = passwordHash;

        await _repository.AddAsync(entity, token);
    }
}
