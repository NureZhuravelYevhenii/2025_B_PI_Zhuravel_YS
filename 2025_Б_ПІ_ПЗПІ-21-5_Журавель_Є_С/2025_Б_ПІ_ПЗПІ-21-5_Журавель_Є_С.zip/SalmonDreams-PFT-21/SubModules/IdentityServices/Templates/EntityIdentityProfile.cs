﻿using AutoMapper;
using BLL.Entities.Identity;

namespace BLL.Infrastructure.Automapper.Identity;

public class EntityIdentityProfile : Profile
{
    public EntityIdentityProfile()
    {
        CreateMap<DAL.Models.Entity, EntityModel>();
        CreateMap<RegisterEntityModel, DAL.Models.Entity>();
    }
}
