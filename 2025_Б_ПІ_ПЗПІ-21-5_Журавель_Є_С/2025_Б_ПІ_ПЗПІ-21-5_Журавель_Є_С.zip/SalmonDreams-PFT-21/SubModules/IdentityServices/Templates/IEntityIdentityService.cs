﻿using BLL.Entities.Identity;

namespace BLL.Abstractions.Identity;

public interface IEntityIdentityService
{
    Task<EntityModel> LoginEntityAsync(LoginEntityModel loginEntityModel, CancellationToken token = default);
    Task RegisterEntityAsync(RegisterEntityModel model, CancellationToken token = default);
}
