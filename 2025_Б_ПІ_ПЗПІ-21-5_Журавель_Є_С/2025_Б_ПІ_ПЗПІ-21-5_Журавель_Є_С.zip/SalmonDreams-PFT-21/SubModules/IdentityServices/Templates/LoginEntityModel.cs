﻿namespace BLL.Entities.Identity;

public class LoginEntityModel
{
    public string Login { get; set; }

    public string Password { get; set; }
}
