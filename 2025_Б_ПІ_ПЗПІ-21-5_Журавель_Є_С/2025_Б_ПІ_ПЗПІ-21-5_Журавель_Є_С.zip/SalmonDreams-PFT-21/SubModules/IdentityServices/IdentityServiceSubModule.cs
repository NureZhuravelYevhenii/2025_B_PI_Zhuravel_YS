﻿using DotNetModule.Contents;
using DotNetModule.Entities;
using GeneralHelpers;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using SharpCodeGenerator;
using SharpCodeGenerator.Entities;
using System.Reflection;
using IdentityEntity;
using AspNet.Contents;

namespace IdentityServices;

/// <summary>
/// Generates a collection of <see cref="IContent"/> for authorization services creation.
/// </summary>
public class IdentityServiceSubModule : BaseSubModule<IdentityServiceProperties>
{
    private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(IdentityServiceSubModule).Assembly);
    private readonly Lazy<StringCodeGenerator> _stringCodeGenerator = new Lazy<StringCodeGenerator>();

    private const string BASE_SERVICE_NAME = "EntityIdentityService";

    public IdentityServiceSubModule()
    {
        RegisterHandler<IdentityEntityContent>(IdentityEntityContentHandler);
    }

    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token))
            .Append(await GetHashHelper())
            .ToList();
    }

    private async Task<IEnumerable<IContent>> IdentityEntityContentHandler(IdentityEntityContent content, ICollection<IContent> contents)
    {
        contents.Add(await GetLoginEntityModel(content.Name));
        contents.Add(await GetRegisterEntityModel(content.Name));
        contents.Add(await GetService(content.Name));
        contents.Add(await GetServiceAbstraction(content.Name));
        contents.Add(await GetAutomapperProfile(content.Name));
        contents.Add(await GetStartupRegistration(content.Name));

        return contents;
    }

    private async Task<IContent> GetLoginEntityModel(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Entities/Identity/Login{entity}Model.cs",
            Content = (await Assembly.Value.GetResource("LoginEntityModel.cs")).ReplaceEntity(entity)
        };
    }

    private async Task<IContent> GetRegisterEntityModel(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Entities/Identity/Register{entity}Model.cs",
            Content = (await Assembly.Value.GetResource("RegisterEntityModel.cs")).ReplaceEntity(entity)
        };
    }

    private async Task<IContent> GetStartupRegistration(string entity)
    {
        return new ServiceRegistrationContent
        {
            Usings = [
                await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "BLL.Abstractions"
                }),
                await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
                {
                    Name = "BLL"
                }),
            ],
            ServiceRegistration = $"builder.Services.AddScoped<I{entity}{BASE_SERVICE_NAME}, {entity}{BASE_SERVICE_NAME}>();"
        };
    }

    private async Task<FileContent> GetService(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Services/Identity/{entity}IdentityService.cs",
            Content = (await Assembly.Value.GetResource($"{BASE_SERVICE_NAME}.cs")).Replace("Entity", entity, StringComparison.Ordinal),
            Dependencies = [
                new Dependency
                {
                    Include = "AutoMapper",
                    Version = "13.0.1",
                },
                new Dependency
                {
                    Include = "BCrypt.Net",
                    Version = "0.1.0",
                },
            ]
        };
    }

    private async Task<FileContent> GetServiceAbstraction(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Abstractions/Identity/I{entity}IdentityService",
            Content = (await Assembly.Value.GetResource($"I{BASE_SERVICE_NAME}.cs")).Replace("Entity", entity, StringComparison.Ordinal),
        };
    }

    private async Task<IContent> GetHashHelper()
    {
        return new FileContent
        {
            Location = $"BLL/Infrastructure/Helpers/HashHelper.cs",
            Content = await Assembly.Value.GetResource("HashHelper.cs")
        };
    }

    private async Task<FileContent> GetAutomapperProfile(string entity)
    {
        return new FileContent
        {
            Location = $"BLL/Infrastructure/Automapper/Identity/{entity}IdentityProfile.cs",
            Content = (await Assembly.Value.GetResource("EntityIdentityProfile.cs")).Replace("Entity", entity, StringComparison.Ordinal),
        };
    }
}
