﻿using MainAbstractions.Modules.Metadata;

namespace IdentityServices;

/// <summary>
/// Represents the components for authorization services creation.
/// The authorization services in the applicaton are those that have "Login", "Register" methods.
/// </summary>
public class IdentityServiceProperties : IModuleProperties { }
