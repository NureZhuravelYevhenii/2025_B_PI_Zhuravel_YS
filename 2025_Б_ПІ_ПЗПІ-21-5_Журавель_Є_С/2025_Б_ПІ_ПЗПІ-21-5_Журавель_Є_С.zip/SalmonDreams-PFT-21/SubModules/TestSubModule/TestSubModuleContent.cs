﻿using MainAbstractions.Modules.Content;
using Property;

namespace TestSubModule
{
    public class TestSubModuleContent : IContent
    {
        public string Name { get; set; } = string.Empty;
        public ICollection<PropertyContent> RefreshTokenClaimProperties { get; set; } = [];
        public ICollection<PropertyContent> AccessTokenClaimProperties { get; set; } = [];
    }
}
