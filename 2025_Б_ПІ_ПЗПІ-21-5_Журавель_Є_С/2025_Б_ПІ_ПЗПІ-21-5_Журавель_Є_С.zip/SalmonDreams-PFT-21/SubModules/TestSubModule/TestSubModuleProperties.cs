﻿using MainAbstractions.Modules.Metadata;

namespace TestSubModule
{
    public class TestSubModuleProperties : IModuleProperties
    {
        public IEnumerable<string> ClaimsForAccessToken { get; set; } = [];

        public IEnumerable<string> ClaimsForRefreshToken { get; set; } = [];
    }
}
