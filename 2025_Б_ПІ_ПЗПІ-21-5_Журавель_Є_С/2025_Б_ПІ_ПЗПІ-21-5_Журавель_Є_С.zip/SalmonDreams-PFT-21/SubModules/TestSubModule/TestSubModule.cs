﻿using Entity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using Property;

namespace TestSubModule
{
    public class TestSubModule : BaseSubModule<TestSubModuleProperties>
    {
        public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
        {
            var contents = await ModuleHelper.ExecuteSubModulesAsync(Modules, token);
            if (PropertiesWithType is null)
                return contents;

            var newContents = new List<IContent>();
            foreach (var content in contents)
            {
                newContents.Add(content);
                if (content is not EntityContent)
                    continue;

                if (PropertiesWithType!.ClaimsForAccessToken is null
                    && PropertiesWithType!.ClaimsForRefreshToken is null)
                {
                    continue;
                }

                var entityContent = (EntityContent)content;
                newContents.Add(GetJwtIdentityEntityContent(entityName: entityContent.Name));
            }

            return newContents;
        }

        private TestSubModuleContent GetJwtIdentityEntityContent(string entityName)
        {
            var accessTokenClaims = GetTokenClaimProperties(PropertiesWithType!.ClaimsForAccessToken);
            var refreshTokenClaims = GetTokenClaimProperties(PropertiesWithType!.ClaimsForRefreshToken);

            return new TestSubModuleContent
            {
                Name = entityName,
                AccessTokenClaimProperties = accessTokenClaims,
                RefreshTokenClaimProperties = refreshTokenClaims
            };
        }

        private List<PropertyContent> GetTokenClaimProperties(IEnumerable<string> claims)
        {
            return claims.Distinct()
                .Select(GetClaim)
                .ToList();
        }

        private PropertyContent GetClaim(string claim)
        {
            return new PropertyContent
            {
                Name = claim,
                PropertyType = PropertyType.String,
            };
        }
    }
}
