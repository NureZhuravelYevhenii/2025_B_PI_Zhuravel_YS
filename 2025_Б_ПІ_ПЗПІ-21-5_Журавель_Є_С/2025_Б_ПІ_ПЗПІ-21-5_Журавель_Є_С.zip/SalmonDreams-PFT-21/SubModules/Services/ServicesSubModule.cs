﻿using AspNet.Contents;
using AutomapperRegistration;
using DotNetModule.Contents;
using DotNetModule.Entities;
using Entity;
using EntityModel;
using GeneralHelpers;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using Property;
using PropertySubModuleHelpers;
using SharpCodeGenerator;
using SharpCodeGenerator.Entities;
using SharpCodeGenerator.Entities.Enums;
using System.Reflection;
using System.Text;

namespace Services;

/// <summary>
/// Represents a submodule responsible for generating entity service classes with CRUD operations within the application.
/// </summary>
public class ServicesSubModule : BaseSubModule<ServicesProperties>
{
    private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(ServicesSubModule).Assembly);
    private readonly Lazy<StringCodeGenerator> _stringCodeGenerator = new Lazy<StringCodeGenerator>();

    private ICollection<EntityContent> _entities = new List<EntityContent>();
	private ICollection<EntityModelContent> _entityModels = new List<EntityModelContent>();

	public ServicesSubModule()
	{
		RegisterHandler<EntityContent>(EntityContentHandler);
		RegisterHandler<EntityModelContent>(EntityModelContentHandler);
	}

    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token))
			.Concat([
                await GenerateBaseService(),
                await GenerateBaseServiceInterface(),
                await GenerateServiceRegistration(),
                GenerateProjectRelation(),
                GetAutomapperRegistrationContent()
            ])
            .Concat(GenerateModels())
            .ToList();
    }

    private async Task EntityContentHandler(EntityContent content, ICollection<IContent> contents)
	{
		contents.Add(GenerateService(content));
		contents.Add(GenerateServiceAbstraction(content));
		contents.Add(await GenerateProfiles(content));

		_entities.Add(content);
	}

	private Task EntityModelContentHandler(EntityModelContent content, IEnumerable<IContent> contents)
	{
		_entityModels.Add(content);
        return Task.CompletedTask;
    }

	private async Task<IContent> GenerateProfiles(EntityContent entity)
	{
		return new FileContent
		{
			Location = $"BLL/Infrastructure/AutoMapper/Entities/{entity.Name}Mappings/{entity.Name}Profile.cs",
			Content = (await Assembly.Value.GetResource("EntityProfile.cs")).Replace("Entity", entity.Name),
			Dependencies = [
				new Dependency{
					Include = "AutoMapper",
					Version = "13.0.1",
                }
			],
        };
	}

	private IContent GenerateServiceAbstraction(EntityContent content)
	{
		return new FileContent
		{
			Location = $"BLL/Abstractions/Services/I{content.Name}Service.cs",
			StronglyTypedContent = new SharpCodeGenerator.Entities.File
			{
				Usings = [
                    new Using
					{
						Name = "BLL.Abstractions.Services.BaseServices",
					},
					new Using
					{
						Name = $"BLL.Entities.{content.Name}Models",
					},
					new Using
					{
						Name = "DAL.Entities",
					},
                ],
				NamespaceName = "BLL.Abstractions.Services",
				Interfaces = [
					new Interface{
						InheritedInterfaceStrings = [
                            $"ICrudService<{content.Name}, {content.Name}Model, {content.Name}CreationModel, {content.Name}IdModel, {content.Name}UpdateModel>"
                        ],
						Name = $"I{content.Name}Service",
						AccessModifier = AccessModifier.Public,
					}
				]
			}
		};
	}

    private IContent GenerateService(EntityContent content)
    {
        return new FileContent
        {
            Location = $"BLL/Services/{content.Name}Service.cs",
            StronglyTypedContent = new SharpCodeGenerator.Entities.File
            {
                Usings = 
				[
                    new Using
					{
						Name = "AutoMapper",
					},
					new Using
					{
						Name = "BLL.Abstractions.Services",
					},
					new Using
					{
						Name = $"BLL.Entities.{content.Name}Models",
					},
					new Using
					{
						Name = "BLL.Services.BaseServices",
					},
					new Using
					{
						Name = "DAL.Abstractions",
					},
					new Using
					{
						Name = "DAL.Entities",
					},
                ],
				NamespaceName = "BLL.Services",
                Classes = 
				[
                    GetServiceClass(content.Name)
                ]
            }
        };
    }

	private Class GetServiceClass(string entityName)
	{
		return new Class
		{
			InheritedClassString = $"BaseCrudService<{entityName}, {entityName}Model, {entityName}CreationModel, {entityName}IdModel, {entityName}UpdateModel>",
			InheritedInterfaceStrings =
			[
				$"I{entityName}Service"
			],
			Name = $"{entityName}Service",
			AccessModifier = AccessModifier.Public,
			Methods = [
				new Method
				{
					AccessModifier = AccessModifier.Public,
					BaseParameters =
					[
						"repository",
						"mapper",
					],
					Name = $"{entityName}Service",
					Parameters =
					[
						new Parameter
						{
							Name = "repository",
							TypeAsString = $"IRepository<{entityName}>",
						},
						new Parameter
						{
							Name = "mapper",
							TypeAsString = "IMapper",
						},
					]
				}
			],
		};
    }

    private IEnumerable<IContent> GenerateModels()
    {
        var contents = new List<IContent>();
        foreach (var entity in _entities)
        {
            var properties = _entityModels.FirstOrDefault(em => em.Name == entity.Name)?.Properties ?? entity.Properties;
            var modelTypes = new[] { "", "Creation", "Update" };

            foreach (var modelType in modelTypes)
                contents.Add(GenerateModel(entity.Name, modelType, properties));

            contents.Add(GenerateIdModel(entity.Name));
        }

        return contents;
    }

    private IContent GenerateModel(string name, string type, IEnumerable<PropertyContent> properties)
	{
		properties = properties.Concat(
		[
			new PropertyContent{
				Name = "Id",
				PropertyType = PropertyType.Int,
			}
		]);

		return new FileContent
		{
			Location = $"BLL/Entities/{name}Models/{name}{type}Model.cs",
			StronglyTypedContent = new SharpCodeGenerator.Entities.File
			{
				NamespaceName = $"BLL.Entities.{name}Models",
				Classes = [
					new Class{
						Name = $"{name}{type}Model",
						Properties = properties.Select(prop => new SharpCodeGenerator.Entities.Property
						{
							Name = prop.Name,
							AccessModifier = AccessModifier.Public,
							Type = prop.PropertyType.GetTypeFromPropertyType(),
                        }),
                        AccessModifier = AccessModifier.Public,
                    }
				]
			},
		};
	}

    private IContent GenerateIdModel(string name)
    {
        return new FileContent
        {
            Location = $"BLL/Entities/{name}Models/{name}IdModel.cs",
            StronglyTypedContent = new SharpCodeGenerator.Entities.File
            {
				NamespaceName = $"BLL.Entities.{name}Models",
                Classes = [
                    new Class{
                        Name = $"{name}IdModel",
                        Properties = [
							new SharpCodeGenerator.Entities.Property
							{
								Type = typeof(int),
								Name = "Id",
								AccessModifier= AccessModifier.Public,
							}
						],
                        AccessModifier = AccessModifier.Public,
                    }
                ]
            },
        };
    }

    private async Task<IContent> GenerateBaseServiceInterface()
	{
		return new FileContent
		{
			Location = "BLL/Abstractions/Services/BaseServices/ICrudService.cs",
			Content = await Assembly.Value.GetResource("ICrudService.cs"),
		};
	}

    private async Task<IContent> GenerateBaseService()
    {
        return new FileContent
        {
            Location = "BLL/Services/BaseServices/BaseCrudService.cs",
            Content = await Assembly.Value.GetResource("BaseCrudService.cs"),
        };
    }

	private ProjectRelationContent GenerateProjectRelation()
	{
		return new ProjectRelationContent
		{
			ProjectName = "BLL",
			ProjectDependencies = 
			[
				"DAL",
			]
		};
	}

	private async Task<ServiceRegistrationContent> GenerateServiceRegistration()
	{
		var generateUsingsForModelsTasks = _entities.Select(async entity => await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
		{
			Name = $"BLL.Entities.{entity.Name}Models"
        }));

		var usings = (await Task.WhenAll(generateUsingsForModelsTasks))
			.Concat([
                await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
				{
                    Name = "BLL.Services"
                }),
                await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
				{
                    Name = "BLL.Abstractions.Services.BaseServices"
                }),
                await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
				{
                    Name = "BLL.Abstractions.Services"
                }),
				await _stringCodeGenerator.Value.GenerateUsingAsync(new Using
				{
                    Name = "DAL.Entities"
                }),
            ]);

        return new ServiceRegistrationContent
		{
			Usings = usings,
			ServiceRegistration = GetServiceRegistration()
        };
	}

	private string GetServiceRegistration()
	{
		return _entities
			.SelectMany<EntityContent, string>(entity =>
			[
				$"builder.Services.AddScoped<ICrudService<{entity.Name}, {entity.Name}Model, {entity.Name}CreationModel, {entity.Name}IdModel, {entity.Name}UpdateModel>, {entity.Name}Service>();",
				$"builder.Services.AddScoped<I{entity.Name}Service, {entity.Name}Service>();",
			])
			.Aggregate(new StringBuilder(), (sb, line) => sb.AppendLine(line))
			.ToString();
	}

	private IContent GetAutomapperRegistrationContent()
	{
		return new AutomapperRegistrationContent
		{
			AutomapperAssemblies = new[] { "BLL" }
		};
	}
}
