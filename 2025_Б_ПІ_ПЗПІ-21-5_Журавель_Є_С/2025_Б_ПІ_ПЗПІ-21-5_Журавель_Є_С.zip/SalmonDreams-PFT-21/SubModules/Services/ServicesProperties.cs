﻿using MainAbstractions.Modules.Metadata;

namespace Services;

/// <summary>
/// Represents the components for services creation.
/// </summary>
public class ServicesProperties : IModuleProperties { }
