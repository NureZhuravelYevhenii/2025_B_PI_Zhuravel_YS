﻿using AutoMapper;
using BLL.Entities.EntityModels;
using DAL.Entities;

namespace BLL.Infrastructure.Automapper.Entities.EntityMappings;

public class EntityProfile : Profile
{
    public EntityProfile()
    {
        CreateMap<Entity, EntityModel>().ReverseMap();
        CreateMap<Entity, EntityCreationModel>().ReverseMap();
        CreateMap<Entity, EntityUpdateModel>().ReverseMap();
        CreateMap<Entity, EntityIdModel>().ReverseMap();
    }
}
