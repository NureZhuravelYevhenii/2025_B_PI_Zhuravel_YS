﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

#nullable enable

namespace BLL.Abstractions.Services.BaseServices;

public interface ICrudService<TEntity, TEntityModel, TEntityCreationModel, TEntityIdModel, TEntityUpdateModel>
{
    Task<TEntityIdModel> CreateAsync(TEntityCreationModel creationModel, CancellationToken token = default);
    Task<TEntityModel?> GetByIdAsync(int id, CancellationToken token = default);
    Task<IEnumerable<TEntityModel>> GetAllAsync(int skip = 0, int take = int.MaxValue, CancellationToken token = default);
    Task UpdateAsync(TEntityUpdateModel updateModel, CancellationToken token = default);
    Task DeleteAsync(int id, CancellationToken token = default);
}
