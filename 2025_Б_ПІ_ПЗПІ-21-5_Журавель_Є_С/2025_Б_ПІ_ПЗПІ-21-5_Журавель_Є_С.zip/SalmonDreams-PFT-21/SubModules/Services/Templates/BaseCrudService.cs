﻿using AutoMapper;
using BLL.Abstractions.Services.BaseServices;
using DAL.Abstractions;
using DAL.Entities.BaseEntities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading;
using System.Threading.Tasks;

#nullable enable

namespace BLL.Services.BaseServices;

public class BaseCrudService<TEntity, TEntityModel, TEntityCreationModel, TEntityIdModel, TEntityUpdateModel>
    : ICrudService<TEntity, TEntityModel, TEntityCreationModel, TEntityIdModel, TEntityUpdateModel>
    where TEntity : BaseEntity
{
    private static IDictionary<Type, Func<object, int>> _idRetrievers = new Dictionary<Type, Func<object, int>>();

    private readonly IRepository<TEntity> _repository;
    private readonly IMapper _mapper;

    static BaseCrudService()
    {
        _idRetrievers.Add(typeof(TEntityUpdateModel), GetIdRetriever(typeof(TEntityUpdateModel)));
    }

    public BaseCrudService(IRepository<TEntity> repository, IMapper mapper)
    {
        _repository = repository;
        _mapper = mapper;
    }

    public async Task<TEntityIdModel> CreateAsync(TEntityCreationModel creationModel, CancellationToken token = default)
    {
        var entity = _mapper.Map<TEntity>(creationModel);
        await _repository.AddAsync(entity, token);

        return _mapper.Map<TEntityIdModel>(entity);
    }

    public async Task<TEntityModel?> GetByIdAsync(int id, CancellationToken token = default)
    {
        return _mapper.Map<TEntityModel>(await _repository.GetByIdAsync(id, token));
    }

    public async Task<IEnumerable<TEntityModel>> GetAllAsync(int skip = 0, int take = int.MaxValue, CancellationToken token = default)
    {
        return _mapper.Map<IEnumerable<TEntityModel>>(await _repository.GetAllAsync(skip, take, token));
    }

    public async Task UpdateAsync(TEntityUpdateModel updateModel, CancellationToken token = default)
    {
        if(updateModel is null)
            throw new ArgumentNullException(nameof(updateModel));
        var id = _idRetrievers[typeof(TEntityUpdateModel)]?.Invoke(updateModel)
            ?? throw new ArgumentException($"Unable to retrieve Id property from {typeof(TEntityUpdateModel).Name}.");
        var entity = await _repository.GetByIdAsync(id, token);
        if (entity == null) throw new Exception("Entity not found");

        _mapper.Map(updateModel, entity);  // Map update model to existing entity
        await _repository.UpdateAsync(entity, token);
    }

    public async Task DeleteAsync(int id, CancellationToken token = default)
    {
        var entity = await _repository.GetByIdAsync(id, token);
        if (entity == null) throw new Exception("Entity not found");

        await _repository.DeleteAsync(id, token);
    }

    private static Func<object, int> GetIdRetriever(Type type)
    {
        var objectParameter = Expression.Parameter(typeof(object), "entity");
        var castObjectToType = Expression.Convert(objectParameter, type);
        var idProperty = Expression.Property(castObjectToType, "Id");
        return Expression.Lambda<Func<object, int>>(idProperty, objectParameter).Compile();
    }
}

