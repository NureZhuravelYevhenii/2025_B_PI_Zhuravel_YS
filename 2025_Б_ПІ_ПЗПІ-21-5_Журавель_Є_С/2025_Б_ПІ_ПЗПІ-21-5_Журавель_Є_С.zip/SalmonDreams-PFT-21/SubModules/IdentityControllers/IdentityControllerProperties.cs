﻿using MainAbstractions.Modules.Metadata;

namespace IdentityControllers;

/// <summary>
/// Represents the components for ASP.NET basic authorization controllers creation.
/// </summary>
public class IdentityControllerProperties : IModuleProperties { }
