﻿using BLL.Models.Identity;
using Microsoft.AspNetCore.Mvc;
using BLL.Abstractions.Identity;

namespace WebAPI.Controllers.Identity;

[Route("api/[controller]")]
[ApiController]
public class EntityAuthController : ControllerBase
{
    private readonly IEntityIdentityService _entityIdentityService;

    public EntityAuthController(IEntityIdentityService entityIdentityService)
    {
        _entityIdentityService = entityIdentityService;
    }

    [HttpPost("register")]
    public async Task<IActionResult> RegisterAsync(RegisterEntityModel newEntity, CancellationToken token)
    {
        await _entityIdentityService.RegisterEntityAsync(newEntity, token);
        return Ok();
    }

    [HttpPost("login")]
    public async Task<IActionResult> LoginAsync(LoginEntityModel loginModel, CancellationToken token)
    {
        return Ok(await _entityIdentityService.LoginEntityAsync(loginModel, token));
    }
}
