﻿using IdentityEntity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using System.Reflection;
using GeneralHelpers;
using AspNet.Contents;

namespace IdentityControllers;

/// <summary>
/// Generates <see cref="ControllerContent"/> for a specific entity identity controller.
/// </summary>
public class IdentityControllersSubModule : BaseSubModule<IdentityControllerProperties>
{
    private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(IdentityControllersSubModule).Assembly);
    private const string BASE_CONTROLLER_NAME = "EntityAuthController";

    public IdentityControllersSubModule()
    {
        RegisterHandler<IdentityEntityContent>(IdentityEntityContentHandler);
    }

    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token)).ToList();
    }

    private async Task<IEnumerable<IContent>> IdentityEntityContentHandler(IdentityEntityContent rawContent, ICollection<IContent> contents)
    {
        contents.Add(await GetEntityController(rawContent.Name));
        return contents;
    }

    private async Task<IContent> GetEntityController(string entity)
    {
        return new ControllerContent
        {
            Name = $"Identity/{BASE_CONTROLLER_NAME}.cs".ReplaceEntity(entity),
            Content = (await Assembly.Value.GetResource($"{BASE_CONTROLLER_NAME}.cs")).ReplaceEntity(entity)
        };
    }
}
