﻿using MainAbstractions.Modules.Content;

namespace Relation;

/// <summary>
/// Represents the definition of a relation.
/// </summary>
public class RelationContent : IContent
{
    /// <summary>
    /// The principal entity in a relationship.
    /// </summary>
    public string BaseEntity { get; set; } = string.Empty;

    /// <summary>
    /// Represents the dependent entity in a relationship
    /// </summary>
    public string SecondaryEntity { get; set; } = string.Empty;

    /// <summary>
    /// Relation type.
    /// </summary>
    public RelationType RelationType { get; set; }
}
