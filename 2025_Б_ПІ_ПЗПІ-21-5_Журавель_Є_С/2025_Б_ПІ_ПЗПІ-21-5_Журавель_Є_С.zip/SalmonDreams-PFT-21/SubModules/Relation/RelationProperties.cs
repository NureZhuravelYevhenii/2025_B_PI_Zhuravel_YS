﻿using MainAbstractions.Modules.Metadata;

namespace Relation;

/// <summary>
/// Represents the components for relation creation.
/// </summary>
public class RelationProperties : IModuleProperties
{
    public string PrimaryEntity { get; set; } = string.Empty;
    public string SecondaryEntity { get; set; } = string.Empty;
    public RelationType RelationType { get; set; }
}
