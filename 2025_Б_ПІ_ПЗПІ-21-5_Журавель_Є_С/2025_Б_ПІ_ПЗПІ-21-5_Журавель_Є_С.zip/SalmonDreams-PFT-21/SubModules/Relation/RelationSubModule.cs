﻿using Entity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;

namespace Relation;

/// <summary>
/// Provides functionality for defining entity relations in the application.
/// </summary>
public class RelationSubModule : BaseSubModule<RelationProperties>
{
    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        if (string.IsNullOrEmpty(PropertiesWithType.PrimaryEntity)
            || string.IsNullOrEmpty(PropertiesWithType.SecondaryEntity))
        {
            throw new ArgumentNullException("Relation properties cannot be null");
        }

        return (await base.ParseInCodeAsync(token))
            .Concat([
                new RelationContent
                {
                    BaseEntity = PropertiesWithType.PrimaryEntity,
                    SecondaryEntity = PropertiesWithType.SecondaryEntity,
                    RelationType = PropertiesWithType.RelationType,
                }
            ])
            .ToList();
    }
}
