﻿namespace Relation;

/// <summary>
/// Represents the types of relationships between entities in the application.
/// </summary>
public enum RelationType
{
    ManyToMany,
    OneToMany,
    OneToOne,
}
