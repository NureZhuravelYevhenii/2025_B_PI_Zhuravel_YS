﻿using MainAbstractions.Modules.Metadata;

namespace IdentityEntity;

/// <summary>
/// Represents the components for identity-based entities.
/// Provides options for configuring login properties and handling missing properties.
/// </summary>
public class IdentityEntityProperties : IModuleProperties
{
    /// <summary>
    /// The name of the login property for the entity.
    /// </summary>
    public string? LoginProperty { get; set; }

    /// <summary>
    /// Indicates whether to create the specified property
    /// if it does not already exist in the entity.
    /// </summary>
    public bool IfSpecifiedPropertyNotExistsCreate { get; set; }
}
