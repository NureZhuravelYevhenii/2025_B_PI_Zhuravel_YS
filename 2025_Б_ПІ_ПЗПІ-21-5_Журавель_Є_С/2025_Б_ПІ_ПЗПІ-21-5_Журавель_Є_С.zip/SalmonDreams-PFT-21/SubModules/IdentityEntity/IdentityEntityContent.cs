﻿using MainAbstractions.Modules.Content;

namespace IdentityEntity;

/// <summary>
/// Represents the definition of identity-based entity.
/// </summary>
public class IdentityEntityContent : IContent
{
    /// <summary>
    /// Primary entity's name.
    /// </summary>
    public string Name { get; set; } = string.Empty;
}
