﻿using Entity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using MainAbstractions.Modules.Helpers;
using Property;

namespace IdentityEntity;

/// <summary>
/// Provides functionality for defining an instance of <see cref="IdentityEntityContent" /> for a specified <see cref="EntityContent" /> in the appliaction.
/// </summary>
public class IdentityEntitySubModule : BaseSubModule<IdentityEntityProperties>
{
    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        var contents = await ModuleHelper.ExecuteSubModulesAsync(Modules, token);
        if (PropertiesWithType is null)
            return contents;

        var newContents = new List<IContent>();
        foreach (var content in contents)
        {
            if (content is not EntityContent)
            {
                newContents.Add(content);
                continue;
            }

            var entityContent = (EntityContent)content;
            newContents.Add(new EntityContent
            {
                Name = entityContent.Name,
                Properties = GetUpdatedEntityProperties(entityContent),
            });

            newContents.Add(new IdentityEntityContent
            {
                Name = entityContent.Name
            });
        }

        return newContents;
    }

    #region Private methods

    private ICollection<PropertyContent> GetUpdatedEntityProperties(EntityContent entityContent)
    {
        var properties = entityContent.Properties;

        AddLoginProperty(properties);
        AddPasswordProperty(properties);

        return properties;
    }

    private void AddLoginProperty(ICollection<PropertyContent> properties)
    {
        if (PropertiesWithType!.LoginProperty is not null
            && !properties.Any(p => p.Name == PropertiesWithType.LoginProperty)
            && PropertiesWithType.IfSpecifiedPropertyNotExistsCreate)
        {
            properties.Add(new PropertyContent
            {
                Name = PropertiesWithType.LoginProperty,
                PropertyType = PropertyType.String,
            });

            return;
        }

        properties.Add(new PropertyContent
        {
            Name = "Login",
            PropertyType = PropertyType.String,
        });
    }

    private void AddPasswordProperty(ICollection<PropertyContent> properties)
    {
        properties.Add(new PropertyContent
        {
            Name = "PasswordHash",
            PropertyType = PropertyType.String,
        });

        properties.Add(new PropertyContent
        {
            Name = "PasswordSalt",
            PropertyType = PropertyType.String,
        });
    }

    #endregion
}
