﻿using AspNet.Contents;
using DotNetModule.Contents;
using GeneralHelpers;
using JwtIdentityEntity;
using MainAbstractions.Modules.BaseClasses;
using MainAbstractions.Modules.Content;
using System.Reflection;

namespace JwtControllers;

/// <summary>
/// Generates <see cref="ControllerContent"/> for a specific entity authorization controller.
/// </summary>
public class JwtControllersSubModule : BaseSubModule<JwtControllerProperties>
{
    private Lazy<Assembly> Assembly => new Lazy<Assembly>(() => typeof(JwtControllersSubModule).Assembly);
    private const string BASE_CONTROLLER_NAME = "EntityJwtController";

    public JwtControllersSubModule()
    {
        RegisterHandler<JwtIdentityEntityContent>(JwtIdentityEntityContentHandler);
    }

    public override async Task<IEnumerable<IContent>> ParseInCodeAsync(CancellationToken token = default)
    {
        return (await base.ParseInCodeAsync(token))
            .Append(await GetJwtHttpConstants())
            .Append(await GetTokenModel());
    }

    private async Task<IEnumerable<IContent>> JwtIdentityEntityContentHandler(JwtIdentityEntityContent rawContent, ICollection<IContent> contents)
    {
        contents.Add(await GetEntityController(rawContent.Name));
        return contents;
    }

    private async Task<FileContent> GetJwtHttpConstants()
    {
        return new FileContent
        {
            Location = "Common/Constants/JwtHttpConstants.cs",
            Content = await Assembly.Value.GetResource("JwtHttpConstants.cs")
        };
    }

    private async Task<IContent> GetEntityController(string entity)
    {
        return new ControllerContent
        {
            Name = $"Identity/{BASE_CONTROLLER_NAME}.cs".ReplaceEntity(entity),
            Content = (await Assembly.Value.GetResource($"{BASE_CONTROLLER_NAME}.cs")).ReplaceEntity(entity)
        };
    }

    private async Task<FileContent> GetTokenModel()
    {
        return new FileContent
        {
            Location = "Web/Models/Jwt/Token.cs",
            Content = await Assembly.Value.GetResource("Token.cs")
        };
    }
}
