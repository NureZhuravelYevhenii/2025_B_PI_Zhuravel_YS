﻿using BLL.Abstractions.Identity;
using BLL.Entities.Jwt;
using BLL.Entities.Identity;
using Common.Constants;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using Web.Models.Jwt;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Web.Controllers.Identity;

[Route("api/[controller]")]
[ApiController]
public class EntityJwtController : ControllerBase
{
    private readonly IJwtEntityIdentityService _entityIdentityService;

    public EntityJwtController(IJwtEntityIdentityService entityIdentityService)
    {
        _entityIdentityService = entityIdentityService;
    }

    [HttpPost("register")]
    public async Task<IActionResult> RegisterAsync(RegisterEntityModel newEntity, CancellationToken token)
    {
        return FormTokensResponse(await _entityIdentityService.RegisterEntityAsync(newEntity, token));
    }

    [HttpPost("login")]
    public async Task<IActionResult> LoginAsync(LoginEntityModel loginModel, CancellationToken token)
    {
        return FormTokensResponse(await _entityIdentityService.LoginEntityAsync(loginModel, token));
    }

    [HttpPost("refresh")]
    public async Task<IActionResult> RefreshAsync(CancellationToken token)
    {
        var refreshToken = GetCookie(JwtHttpConstants.RefreshTokenCookieName);
        if (string.IsNullOrEmpty(refreshToken))
            throw new UnauthorizedAccessException("There is no refresh token specified");

        return FormTokensResponse(await _entityIdentityService.RefreshTokenAsync(refreshToken, token));
    }

    private IActionResult FormTokensResponse(TokenPair tokens)
    {
        AddCookie(JwtHttpConstants.RefreshTokenCookieName, tokens.RefreshToken);

        return Ok(new Token
        {
            AccessToken = tokens.AccessToken,
        });
    }

    protected void AddCookie(string name, string value)
    {
        Response.Cookies.Append(name, value, new CookieOptions
        {
            HttpOnly = true,
            Domain = Request.Host.Host,
        });
    }

    protected string GetCookie(string name) => Request.Cookies.FirstOrDefault(pair => pair.Key == name).Value;
}
