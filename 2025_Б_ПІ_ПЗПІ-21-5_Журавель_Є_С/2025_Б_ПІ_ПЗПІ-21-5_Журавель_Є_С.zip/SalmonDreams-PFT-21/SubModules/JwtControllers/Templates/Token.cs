﻿namespace Web.Models.Jwt;

public class Token
{
    public string AccessToken { get; set; } = string.Empty;
}
