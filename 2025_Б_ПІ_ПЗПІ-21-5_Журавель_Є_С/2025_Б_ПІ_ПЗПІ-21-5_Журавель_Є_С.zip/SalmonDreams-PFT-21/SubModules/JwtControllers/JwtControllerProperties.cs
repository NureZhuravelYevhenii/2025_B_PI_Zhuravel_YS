﻿using MainAbstractions.Modules.Metadata;

namespace JwtControllers;

/// <summary>
/// Represents the components for ASP.NET authorization controllers creation.
/// </summary>
public class JwtControllerProperties : IModuleProperties { }
