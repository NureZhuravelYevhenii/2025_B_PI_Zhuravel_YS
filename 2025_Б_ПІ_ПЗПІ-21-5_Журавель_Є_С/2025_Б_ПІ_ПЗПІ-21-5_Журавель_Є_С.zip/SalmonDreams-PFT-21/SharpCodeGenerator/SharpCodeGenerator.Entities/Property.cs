﻿using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a property in C# that can encapsulate fields, provide accessors, and include various attributes.
/// </summary>
public class Property
{
    /// <summary>
    /// Gets or sets the collection of attributes applied to the property.
    /// </summary>
    public IEnumerable<Attribute> Attributes { get; set; } = Array.Empty<Attribute>();

    /// <summary>
    /// Gets or sets the collection of modifiers for the property.
    /// </summary>
    public IEnumerable<PropertyModifier> Modifiers { get; set; } = Array.Empty<PropertyModifier>();

    /// <summary>
    /// Gets or sets the access modifier for the property.
    /// </summary>
    public AccessModifier? AccessModifier { get; set; }

    /// <summary>
    /// Gets or sets the name of the property.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the type of the property.
    /// </summary>
    public Type? Type { get; set; }

    /// <summary>
    /// Gets or sets the type name of the property as a string.
    /// </summary>
    public string? TypeAsString { get; set; }

    /// <summary>
    /// Gets or sets the default value of the property, if applicable.
    /// </summary>
    public string? Value { get; set; }

    /// <summary>
    /// Gets or sets the access modifier for the property getter, if defined.
    /// </summary>
    public AccessModifier? GetterAccessModifier { get; set; }

    /// <summary>
    /// Gets or sets the method associated with the property getter.
    /// </summary>
    public Method? Getter { get; set; }

    /// <summary>
    /// Gets or sets the access modifier for the property setter, if defined.
    /// </summary>
    public AccessModifier? SetterAccessModifier { get; set; }

    /// <summary>
    /// Gets or sets the method associated with the property setter.
    /// </summary>
    public Method? Setter { get; set; }

    /// <summary>
    /// Gets or sets the method that initializes the property, if applicable.
    /// </summary>
    public Method? Initializer { get; set; }
}
