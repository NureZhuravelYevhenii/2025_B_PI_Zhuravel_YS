﻿using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a method definition in C#.
/// </summary>
public class Method
{
    /// <summary>
    /// Gets or sets the collection of modifiers applied to the method.
    /// </summary>
    public IEnumerable<MethodModifier> MethodModifiers { get; set; } = Array.Empty<MethodModifier>();

    /// <summary>
    /// Gets or sets the collection of attributes applied to the method.
    /// </summary>
    public IEnumerable<Attribute> Attributes { get; set; } = Array.Empty<Attribute>();

    /// <summary>
    /// Gets or sets the access modifier of the method.
    /// </summary>
    public AccessModifier? AccessModifier { get; set; }

    /// <summary>
    /// Gets or sets the name of the method.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the content or body of the method.
    /// </summary>
    public string? Content { get; set; }

    /// <summary>
    /// Gets or sets the return type of the method.
    /// </summary>
    public Type? ReturnType { get; set; }

    /// <summary>
    /// Gets or sets the collection of parameters for the method.
    /// </summary>
    public IEnumerable<Parameter> Parameters { get; set; } = Array.Empty<Parameter>();

    /// <summary>
    /// Gets or sets the collection of base parameters for the method.
    /// </summary>
    public IEnumerable<string> BaseParameters { get; set; } = Array.Empty<string>();

    /// <summary>
    /// Gets or sets the collection of 'this' parameters for the method.
    /// </summary>
    public IEnumerable<string> ThisParameters { get; set; } = Array.Empty<string>();
}

