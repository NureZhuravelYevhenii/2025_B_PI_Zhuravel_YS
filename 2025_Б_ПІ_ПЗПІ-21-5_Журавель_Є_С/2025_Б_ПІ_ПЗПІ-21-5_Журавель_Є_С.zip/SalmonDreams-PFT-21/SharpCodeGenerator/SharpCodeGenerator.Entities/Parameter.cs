﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a parameter in a method or function definition in C#.
/// </summary>
public class Parameter
{
    /// <summary>
    /// Gets or sets the collection of attributes applied to the parameter.
    /// </summary>
    public IEnumerable<Attribute> Attributes { get; set; } = Array.Empty<Attribute>();

    /// <summary>
    /// Gets or sets the name of the parameter.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the type of the parameter.
    /// </summary>
    public Type Type { get; set; } = null!;

    /// <summary>
    /// Gets or sets the type name of the parameter as a string.
    /// </summary>
    public string TypeAsString { get; set; } = null!;

    /// <summary>
    /// Gets or sets the default value of the parameter, if applicable.
    /// </summary>
    public string? Value { get; set; }
}
