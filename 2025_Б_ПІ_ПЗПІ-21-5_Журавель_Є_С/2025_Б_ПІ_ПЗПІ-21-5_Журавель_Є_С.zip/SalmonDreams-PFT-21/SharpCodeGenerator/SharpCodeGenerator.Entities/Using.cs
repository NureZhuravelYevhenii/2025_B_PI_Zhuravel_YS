﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a using directive in C# that allows the inclusion of namespaces or types in the code.
/// </summary>
public class Using
{
    /// <summary>
    /// Gets or sets the name of the namespace or type being referenced in the using directive.
    /// </summary>
    public string Name { get; set; } = string.Empty;
}
