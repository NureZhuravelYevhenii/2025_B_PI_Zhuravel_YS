﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents an interface with specific properties and behaviors.
/// </summary>
public class Interface : TypeDefinition { }
