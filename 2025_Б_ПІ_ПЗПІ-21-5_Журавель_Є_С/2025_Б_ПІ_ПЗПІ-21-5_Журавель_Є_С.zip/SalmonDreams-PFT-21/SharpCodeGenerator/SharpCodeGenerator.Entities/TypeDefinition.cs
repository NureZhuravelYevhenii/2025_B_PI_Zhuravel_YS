﻿using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a base type definition with common properties for classes and interfaces.
/// </summary>
public abstract class TypeDefinition
{
    /// <summary>
    /// Gets or sets the attributes associated with this type.
    /// </summary>
    public IEnumerable<Attribute> Attributes { get; set; } = Enumerable.Empty<Attribute>();

    /// <summary>
    /// Gets or sets the access modifier for this type.
    /// </summary>
    public AccessModifier? AccessModifier { get; set; }

    /// <summary>
    /// Gets or sets the name of this type.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the modifiers for this type (e.g., abstract, static).
    /// </summary>
    public IEnumerable<ClassModifier> ClassModifiers { get; set; } = Enumerable.Empty<ClassModifier>();

    /// <summary>
    /// Gets or sets the properties defined in this type.
    /// </summary>
    public IEnumerable<Property> Properties { get; set; } = Enumerable.Empty<Property>();

    /// <summary>
    /// Gets or sets the events defined in this type.
    /// </summary>
    public IEnumerable<Event> Events { get; set; } = Enumerable.Empty<Event>();

    /// <summary>
    /// Gets or sets the methods defined in this type.
    /// </summary>
    public IEnumerable<Method> Methods { get; set; } = Enumerable.Empty<Method>();

    /// <summary>
    /// Gets or sets the interfaces inherited by this type.
    /// </summary>
    public IEnumerable<Type> InheritedInterfaces { get; set; } = Enumerable.Empty<Type>();

    /// <summary>
    /// Gets or sets the string representations of inherited interfaces.
    /// </summary>
    public IEnumerable<string> InheritedInterfaceStrings { get; set; } = Enumerable.Empty<string>();
}
