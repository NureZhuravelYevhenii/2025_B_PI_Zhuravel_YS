﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a field in C#.
/// </summary>
public class Field : MemberDefinition
{
    /// <summary>
    /// Gets or sets the initial value of the field.
    /// </summary>
    public string? Value { get; set; } = string.Empty;
}
