﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents an event in C#.
/// </summary>
public class Event : MemberDefinition { }
