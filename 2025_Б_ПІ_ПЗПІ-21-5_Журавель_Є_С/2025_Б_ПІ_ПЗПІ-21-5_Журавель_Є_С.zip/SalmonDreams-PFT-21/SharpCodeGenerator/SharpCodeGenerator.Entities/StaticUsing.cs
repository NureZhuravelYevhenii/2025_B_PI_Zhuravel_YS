﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a static using directive in C# that allows the inclusion of static members from a type.
/// </summary>
public class StaticUsing
{
    /// <summary>
    /// Gets or sets the new name for the static type being referenced, which will be used in the using directive.
    /// </summary>
    public string NewTypeName { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the original name of the static type being referenced.
    /// </summary>
    public string OldTypeName { get; set; } = string.Empty;
}
