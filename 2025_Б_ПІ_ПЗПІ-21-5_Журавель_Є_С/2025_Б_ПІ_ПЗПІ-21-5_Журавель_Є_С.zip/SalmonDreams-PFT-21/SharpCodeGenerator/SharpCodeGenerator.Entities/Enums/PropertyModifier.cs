﻿namespace SharpCodeGenerator.Entities.Enums;

/// <summary>
/// Represents the different modifiers that can be applied to properties in C#.
/// </summary>
/// <remarks>
/// Property modifiers determine the accessibility and characteristics of properties within a class or struct. This enum includes the following values:
/// 
/// - <see cref="Public">Public</see>: Indicates that the property is accessible from any other code in the same assembly or another assembly that references it.
/// - <see cref="Private">Private</see>: Indicates that the property is accessible only within the containing class or struct.
/// - <see cref="Protected">Protected</see>: Indicates that the property is accessible within its class and by derived class instances.
/// - <see cref="Internal">Internal</see>: Indicates that the property is accessible only within the same assembly, but not from another assembly.
/// - <see cref="ProtectedInternal">ProtectedInternal</see>: Indicates that the property is accessible within its class and by derived class instances, as well as within the same assembly.
/// - <see cref="Static">Static</see>: Indicates that the property belongs to the type itself rather than to a specific object instance and can be accessed without creating an instance of the class.
/// - <see cref="ReadOnly">ReadOnly</see>: Indicates that the property can only be read (has a getter) and cannot be modified (does not have a setter).
/// - <see cref="WriteOnly">WriteOnly</see>: Indicates that the property can only be set (has a setter) and cannot be read (does not have a getter).
/// </remarks>
public enum PropertyModifier
{
    Public,
    Private,
    Protected,
    Internal,
    ProtectedInternal,
    Static,
    ReadOnly,
    WriteOnly
}
