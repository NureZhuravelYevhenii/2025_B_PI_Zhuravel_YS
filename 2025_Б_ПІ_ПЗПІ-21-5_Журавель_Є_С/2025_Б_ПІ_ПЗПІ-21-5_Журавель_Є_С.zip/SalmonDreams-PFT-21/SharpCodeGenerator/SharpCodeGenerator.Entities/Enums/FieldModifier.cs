﻿namespace SharpCodeGenerator.Entities.Enums;

/// <summary>
/// Represents the different modifiers that can be applied to fields in C#.
/// </summary>
/// <remarks>
/// Field modifiers determine the accessibility and behavior of fields within a class or struct. This enum includes the following values:
/// 
/// - <see cref="Public">Public</see>: Indicates that the field is accessible from any other code in the same assembly or another assembly that references it.
/// - <see cref="Private">Private</see>: Indicates that the field is accessible only within the containing class or struct.
/// - <see cref="Protected">Protected</see>: Indicates that the field is accessible within its class and by derived class instances.
/// - <see cref="Internal">Internal</see>: Indicates that the field is accessible only within the same assembly, but not from another assembly.
/// - <see cref="ProtectedInternal">ProtectedInternal</see>: Indicates that the field is accessible within its class and by derived class instances, as well as within the same assembly.
/// - <see cref="Static">Static</see>: Indicates that the field belongs to the type itself rather than to a specific object instance, shared across all instances of the class.
/// - <see cref="ReadOnly">ReadOnly</see>: Indicates that the field can only be assigned during declaration or in a constructor, preventing modification thereafter.
/// - <see cref="Const">Const</see>: Indicates that the field is a compile-time constant, and its value cannot be changed once defined.
/// </remarks>
public enum FieldModifier
{
    Public,
    Private,
    Protected,
    Internal,
    ProtectedInternal,
    Static,
    ReadOnly,
    Const
}
