﻿namespace SharpCodeGenerator.Entities.Enums;

/// <summary>
/// Represents the different modifiers that can be applied to classes in C#.
/// </summary>
/// /// <remarks>
/// Class modifiers affect the behavior and characteristics of a class. This enum includes the following values:
/// 
/// - <see cref="Abstract">Abstract</see>: Indicates that the class cannot be instantiated and is intended to be a base class for other classes.
/// - <see cref="Sealed">Sealed</see>: Indicates that the class cannot be inherited, preventing other classes from deriving from it.
/// - <see cref="Static">Static</see>: Indicates that the class is static and cannot be instantiated or inherited; all members of the class must be static.
/// - <see cref="Partial">Partial</see>: Indicates that the class definition can be split across multiple files, allowing for more modular development.
/// - <see cref="Unsafe">Unsafe</see>: Indicates that the class uses unsafe code, allowing pointer operations and direct memory access.
/// </remarks>
public enum ClassModifier
{
    Abstract,
    Sealed,
    Static,
    Partial,
    Unsafe
}
