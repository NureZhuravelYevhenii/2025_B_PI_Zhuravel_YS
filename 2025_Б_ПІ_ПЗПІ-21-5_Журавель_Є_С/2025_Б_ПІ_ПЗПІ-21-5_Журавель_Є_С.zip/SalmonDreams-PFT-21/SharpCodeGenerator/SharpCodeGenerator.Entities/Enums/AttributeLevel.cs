﻿namespace SharpCodeGenerator.Entities.Enums;

/// <summary>
/// Represents the different levels at which attributes can be applied in C#.
/// </summary>
public enum AttributeLevel
{
    Assembly,
    Module,
    Event,
    Field,
    Method,
    Param,
    Property,
    Return,
    Type,
    Typevar,
}
