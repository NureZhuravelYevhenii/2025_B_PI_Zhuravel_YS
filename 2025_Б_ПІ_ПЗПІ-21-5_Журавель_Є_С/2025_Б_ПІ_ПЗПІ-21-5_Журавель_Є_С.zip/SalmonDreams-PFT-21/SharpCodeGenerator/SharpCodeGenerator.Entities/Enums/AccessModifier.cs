﻿namespace SharpCodeGenerator.Entities.Enums;

/// <summary>
/// Represents the different access modifiers that can be applied to classes, methods, properties, and fields in C#.
/// </summary>
/// /// <remarks>
/// Access modifiers control the visibility of types and their members, determining how they can be accessed from other code. 
/// This enum includes the following values:
/// 
/// - <see cref="Public">Public</see>: The member is accessible from any other code in the same assembly or another assembly that references it.
/// - <see cref="Private">Private</see>: The member is accessible only within the body of the class or struct in which it is declared.
/// - <see cref="Protected">Protected</see>: The member is accessible within its class and by derived class instances.
/// - <see cref="Internal">Internal</see>: The member is accessible only within files in the same assembly.
/// - <see cref="ProtectedInternal">ProtectedInternal</see>: The member is accessible from its class and derived classes, as well as from any class in the same assembly.
/// - <see cref="PrivateProtected">PrivateProtected</see>: The member is accessible within its declaring class and by derived classes that are in the same assembly.
/// </remarks>
public enum AccessModifier
{
    Private,
    InternalProtected,
    Internal,
    Protected,
    Public,
}