﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a C# source file.
/// </summary>
public class File
{
    /// <summary>
    /// Gets or sets the collection of regular using directives in the file.
    /// </summary>
    public IEnumerable<Using> Usings { get; set; } = Array.Empty<Using>();

    /// <summary>
    /// Gets or sets the collection of static using directives in the file.
    /// </summary>
    public IEnumerable<StaticUsing> StaticUsings { get; set; } = Array.Empty<StaticUsing>();

    /// <summary>
    /// Gets or sets the namespace to which the file belongs.
    /// </summary>
    public string NamespaceName { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the collection of classes defined in the file.
    /// </summary>
    public IEnumerable<Class> Classes { get; set; } = Array.Empty<Class>();

    /// <summary>
    /// Gets or sets the collection of interfaces defined in the file.
    /// </summary>
    public IEnumerable<Interface> Interfaces { get; set; } = Array.Empty<Interface>();
}
