﻿using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a custom attribute in C#.
/// </summary>
public class Attribute
{
    /// <summary>
    /// Gets or sets the type of the attribute.
    /// </summary>
    public Type Type { get; set; } = null!;

    /// <summary>
    /// Gets or sets the level of the attribute's application (e.g., assembly-level, method-level).
    /// </summary>
    public AttributeLevel? Level { get; set; }

    /// <summary>
    /// Gets or sets the collection of parameters for the attribute.
    /// </summary>
    public IEnumerable<string> Parameters { get; set; } = Array.Empty<string>();
}
