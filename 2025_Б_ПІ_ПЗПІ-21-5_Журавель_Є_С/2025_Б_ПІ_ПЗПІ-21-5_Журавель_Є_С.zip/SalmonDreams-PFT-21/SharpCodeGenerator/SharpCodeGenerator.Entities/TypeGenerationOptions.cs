﻿using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents the options for generating a type definition, including
/// its name, type keyword (class or interface), access modifier, 
/// modifiers, and attributes.
/// </summary>
public class TypeGenerationOptions
{
    /// <summary>
    /// Gets or sets the name of the type (class or interface).
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the keyword representing the type, either "class" or "interface".
    /// </summary>
    public string TypeKeyword { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the access modifier for the type, which can be public, private, etc.
    /// Nullable, as a type may not have an access modifier specified.
    /// </summary>
    public AccessModifier? AccessModifier { get; set; }

    /// <summary>
    /// Gets or sets a collection of modifiers that apply to the type,
    /// such as static, abstract, or sealed.
    /// Default is an empty collection.
    /// </summary>
    public IEnumerable<ClassModifier> Modifiers { get; set; } = Enumerable.Empty<ClassModifier>();

    /// <summary>
    /// Gets or sets a collection of attributes associated with the type.
    /// Attributes provide metadata for the type and can affect its behavior.
    /// Default is an empty collection.
    /// </summary>
    public IEnumerable<Attribute> Attributes { get; set; } = Enumerable.Empty<Attribute>();

    /// <summary>
    /// Gets or sets the string representation of the inherited types.
    /// </summary>
    public string? InheritedTypesString { get; set; }
}
