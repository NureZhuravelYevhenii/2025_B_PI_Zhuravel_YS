﻿namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a class with specific properties and behaviors.
/// </summary>
public class Class : TypeDefinition
{
    /// <summary>
    /// Gets or sets the fields defined in this class.
    /// </summary>
    public IEnumerable<Field> Fields { get; set; } = Enumerable.Empty<Field>();

    /// <summary>
    /// Gets or sets the type of the class being inherited from.
    /// </summary>
    public Type? InheritedClass { get; set; }

    /// <summary>
    /// Gets or sets the string representation of the inherited class.
    /// </summary>
    public string? InheritedClassString { get; set; }

    /// <summary>
    /// Gets or sets the generic arguments for this class.
    /// </summary>
    public IEnumerable<string> GenericArguments { get; set; } = Enumerable.Empty<string>();

    /// <summary>
    /// Gets or sets the specifications for the generic arguments.
    /// </summary>
    public IDictionary<string, string> GenericArgumentsSpecification { get; set; } = new Dictionary<string, string>();
}
