﻿using SharpCodeGenerator.Entities.Enums;

namespace SharpCodeGenerator.Entities;

/// <summary>
/// Represents a common base for members in C#.
/// </summary>
public abstract class MemberDefinition
{
    /// <summary>
    /// Gets or sets a value indicating whether the member is static.
    /// </summary>
    public bool IsStatic { get; set; }

    /// <summary>
    /// Gets or sets the collection of attributes associated with the member.
    /// </summary>
    public IEnumerable<Attribute> Attributes { get; set; } = Array.Empty<Attribute>();

    /// <summary>
    /// Gets or sets the access modifier for the member.
    /// </summary>
    public AccessModifier? AccessModifier { get; set; }

    /// <summary>
    /// Gets or sets the name of the member.
    /// </summary>
    public string Name { get; set; } = string.Empty;

    /// <summary>
    /// Gets or sets the type of the member.
    /// </summary>
    public Type Type { get; set; } = null!;
}
