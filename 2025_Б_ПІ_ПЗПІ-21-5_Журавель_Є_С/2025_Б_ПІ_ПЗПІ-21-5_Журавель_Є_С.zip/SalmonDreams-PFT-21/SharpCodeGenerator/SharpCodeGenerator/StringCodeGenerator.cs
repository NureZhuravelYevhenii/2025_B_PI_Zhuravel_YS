﻿using GeneralHelpers;
using Microsoft.CSharp;
using SharpCodeGenerator.Abstractions;
using SharpCodeGenerator.Entities;
using System.CodeDom;
using System.Text;

namespace SharpCodeGenerator;

public class StringCodeGenerator : ICodeGenerator<string>
{
    private readonly int _tabSpaces = 4;

    public StringCodeGenerator(int tabSpaces)
    {
        if (tabSpaces <= 0)
            throw new ArgumentOutOfRangeException(nameof(tabSpaces), "Tab spaces must be greater than 0.");

        _tabSpaces = tabSpaces;
    }

    public StringCodeGenerator() { }

    public async Task<string> GenerateClassAsync(Class @class, CancellationToken token = default) =>
        await GenerateTypeDefinitionAsync(@class, token);

    public async Task<string> GenerateInterfaceAsync(Interface @interface, CancellationToken token = default) =>
        await GenerateTypeDefinitionAsync(@interface, token);

    public Task<string> GenerateStaticUsingAsync(StaticUsing staticUsing, CancellationToken token = default) =>
        Task.FromResult($"using static {staticUsing.NewTypeName} = {staticUsing.OldTypeName};");

    public Task<string> GenerateUsingAsync(Using @using, CancellationToken token = default) =>
        Task.FromResult($"using {@using.Name};");

    public async Task<string> GenerateFieldAsync(Field field, CancellationToken token = default) =>
        await GenerateMemberDefinitionAsync(field, token);

    public async Task<string> GenerateEventAsync(Event @event, CancellationToken token = default) =>
        await GenerateMemberDefinitionAsync(@event, token);

    public async Task<string> GenerateAttributeAsync(Entities.Attribute attribute, CancellationToken token = default)
    {
        var levelPrefix = attribute.Level is null ? string.Empty : GetModifier(attribute.Level.Value) + ": ";
        var attributeTypeName = GetTypeName(attribute.Type).Replace("Attribute", "");
        var parameters = attribute.Parameters.Any() ? "(" + string.Join(",", attribute.Parameters) + ")" : string.Empty;

        return await Task.FromResult($"[{levelPrefix}{attributeTypeName}{parameters}]");
    }

    public async Task<string> GenerateFileAsync(Entities.File file, CancellationToken token = default)
    {
        var sb = new StringBuilder();
        await AppendUsings(sb, file.Usings, file.StaticUsings, token);

        sb.AppendLine($"namespace {file.NamespaceName};");
        sb.AppendLine();

        await AppendEntitiesAsync(sb, file.Classes, GenerateClassAsync, token);
        await AppendEntitiesAsync(sb, file.Interfaces, GenerateInterfaceAsync, token);

        return sb.ToString();
    }

    public async Task<string> GenerateMethodAsync(Method method, bool isInterface = false, CancellationToken token = default)
    {
        var sb = new StringBuilder();
        await AddAttributes(sb, method.Attributes, token);

        var methodSignature = BuildMethodSignature(method, await GenerateParametersAsync(method.Parameters, token));
        sb.Append(methodSignature);

        AppendConstructorCalls(sb, method);

        if (isInterface && method.Content is null)
        {
            sb.Append(";");
            return sb.ToString();
        }

        AppendMethodBody(sb, method);

        return sb.ToString();
    }

    public async Task<string> GenerateParameterAsync(Parameter parameter, CancellationToken token = default)
    {
        var sb = new StringBuilder();
        await AddAttributesInline(sb, parameter.Attributes, token);

        var typeString = parameter.Type is not null
            ? GetTypeName(parameter.Type)
            : parameter.TypeAsString;

        sb.Append($"{typeString} {parameter.Name}");
        if (parameter.Value is not null)
            sb.Append($" = {parameter.Value}");

        return sb.ToString();
    }

    public async Task<string> GeneratePropertyAsync(Property property, CancellationToken token = default)
    {
        var sb = new StringBuilder();
        await AddAttributes(sb, property.Attributes, token);

        var propertySignature = BuildPropertySignature(property);
        sb.Append(propertySignature);

        if (property.Getter is null || property.Setter is null)
        {
            sb.Append(" { get; set; }");
            return sb.ToString();
        }

        AppendPropertyBody(sb, property);

        return sb.ToString();
    }

    #region Private methods

    private async Task<string> GenerateTypeDefinitionAsync(TypeDefinition typeDefinition, CancellationToken token = default)
    {
        var isClass = typeDefinition is Class;
        var typeKeyword = isClass ? "class" : "interface";

        var options = new TypeGenerationOptions
        {
            Name = typeDefinition.Name,
            TypeKeyword = typeKeyword,
            AccessModifier = typeDefinition.AccessModifier,
            Modifiers = typeDefinition.ClassModifiers,
            Attributes = typeDefinition.Attributes,
            InheritedTypesString = isClass
                ? GetInheritedClassesAndInterfaces((Class)typeDefinition)
                : GetInheritedInterfaces((Interface)typeDefinition)
        };

        return await GenerateTypeAsync(options, token, async sb =>
        {
            if (typeDefinition is Class @class)
                await AddFieldsAsync(sb, @class.Fields);

            await AddPropertiesAsync(sb, typeDefinition.Properties);
            await AddEventsAsync(sb, typeDefinition.Events);
            await AddMethodsAsync(sb, typeDefinition.Methods, typeKeyword == "interface");
        });
    }

    private async Task<string> GenerateTypeAsync(
        TypeGenerationOptions options,
        CancellationToken token,
        Func<StringBuilder, Task> addMembers)
    {
        var sb = new StringBuilder();
        await AddAttributes(sb, options.Attributes, token);

        sb.AppendLine($"{(options.AccessModifier is null ? "" : GetModifier(options.AccessModifier.Value) + " ")}" +
                      $"{(options.Modifiers.Any() ? GetMultipleModifiers(options.Modifiers) + " " : "")}" +
                      $"{options.TypeKeyword} {options.Name}{options.InheritedTypesString}");

        sb.AppendLine("{");
        await addMembers(sb);
        sb.Append("}");

        return sb.ToString();
    }

    private async Task<string> GenerateMemberDefinitionAsync(MemberDefinition memberDefinition, CancellationToken token)
    {
        var sb = new StringBuilder();
        await AddAttributes(sb, memberDefinition.Attributes, token);

        var accessModifierText = memberDefinition.AccessModifier is null
            ? string.Empty
            : GetModifier(memberDefinition.AccessModifier.Value) + " ";

        var staticModifierText = memberDefinition.IsStatic
            ? "static "
            : string.Empty;

        var memberName = memberDefinition.Name;
        if (memberDefinition is Field field)
            memberName += field.Value is not null ? $" = {field.Value}" : string.Empty;

        sb.AppendLine($"{accessModifierText}{staticModifierText}{GetTypeName(memberDefinition.Type)} {memberName};");

        return sb.ToString();
    }

    private string GetInheritedClassesAndInterfaces(Class @class)
    {
        if (@class.InheritedClass is null &&
            @class.InheritedClassString is null &&
            !@class.InheritedInterfaces.Any())
        {
            return string.Empty;
        }

        var inheritedClass = @class.InheritedClass is not null
            ? GetTypeName(@class.InheritedClass)
            : @class.InheritedClassString ?? string.Empty;

        var inheritedInterfaces = @class.InheritedInterfaces.Any()
            ? string.Join(", ", @class.InheritedInterfaces.Select(GetTypeName))
            : string.Join(", ", @class.InheritedInterfaceStrings);

        var separator = !string.IsNullOrEmpty(inheritedClass) && !string.IsNullOrEmpty(inheritedInterfaces)
            ? ", "
            : string.Empty;

        return $" : {inheritedClass}{separator}{inheritedInterfaces}";
    }

    private string GetInheritedInterfaces(Interface @interface)
    {
        if (!@interface.InheritedInterfaces.Any() && !@interface.InheritedInterfaceStrings.Any())
            return string.Empty;

        var inheritedInterfaces = @interface.InheritedInterfaces.Any()
            ? string.Join(", ", @interface.InheritedInterfaces.Select(GetTypeName))
            : string.Join(", ", @interface.InheritedInterfaceStrings);

        return $" : {inheritedInterfaces}";
    }

    private async Task AddElementsAsync<T>(StringBuilder sb, IEnumerable<T> elements, Func<T, Task<string>> generateElementAsync)
    {
        if (elements is null)
            return;

        foreach (var element in elements)
            sb.AppendLine((await generateElementAsync(element)).ShiftEachLineWithIndentation(_tabSpaces));
    }

    private async Task AddFieldsAsync(StringBuilder sb, IEnumerable<Field> fields) =>
        await AddElementsAsync(sb, fields, field => GenerateFieldAsync(field));

    private async Task AddPropertiesAsync(StringBuilder sb, IEnumerable<Property> properties) =>
        await AddElementsAsync(sb, properties, property => GeneratePropertyAsync(property));

    private async Task AddEventsAsync(StringBuilder sb, IEnumerable<Event> events) =>
        await AddElementsAsync(sb, events, @event => GenerateEventAsync(@event));

    private async Task AddMethodsAsync(StringBuilder sb, IEnumerable<Method> methods, bool isInterface = false)
    {
        if (methods is null)
            return;

        var isFirst = true;
        foreach (var method in methods)
        {
            if (!isFirst)
                sb.AppendLine();
            else
                isFirst = false;

            sb.AppendLine((await GenerateMethodAsync(method)).ShiftEachLineWithIndentation(_tabSpaces));
        }
    }

    private string GetTypeName(Type type)
    {
        var compiler = new CSharpCodeProvider();
        if (type.IsGenericType)
        {
            var genericTypeName = compiler.GetTypeOutput(new CodeTypeReference(type.GetGenericTypeDefinition()))
                .Split('.')
                .Last()
                .Split('<')
                .First();

            var genericArguments = string.Join(", ", type.GetGenericArguments().Select(GetTypeName));
            return $"{genericTypeName}<{genericArguments}>";
        }

        return compiler.GetTypeOutput(new CodeTypeReference(type)).Split('.').Last();
    }

    private async Task<IEnumerable<string>> GenerateParametersAsync(IEnumerable<Parameter> parameters, CancellationToken token)
    {
        if (parameters is null)
            return Enumerable.Empty<string>();

        var parameterTasks = parameters.Select(parameter => GenerateParameterAsync(parameter, token));
        return await Task.WhenAll(parameterTasks);
    }

    private async Task AddAttributesAsync(
        StringBuilder sb,
        IEnumerable<Entities.Attribute> attributes,
        Func<Entities.Attribute, CancellationToken, Task<string>> generateAttributeAsync,
        CancellationToken token = default)
    {
        if (attributes is null)
            return;

        foreach (var attribute in attributes)
            sb.Append(await generateAttributeAsync(attribute, token));
    }

    private async Task AddAttributes(StringBuilder sb, IEnumerable<Entities.Attribute> attributes, CancellationToken token = default)
    {
        await AddAttributesAsync(sb, attributes, async (attribute, cancellationToken) =>
        {
            var result = await GenerateAttributeAsync(attribute, cancellationToken);
            return result + Environment.NewLine;
        }, token);
    }

    private async Task AddAttributesInline(StringBuilder sb, IEnumerable<Entities.Attribute> attributes, CancellationToken token = default) =>
        await AddAttributesAsync(sb, attributes, GenerateAttributeAsync, token);

    private string GetMultipleModifiers<TEnum>(IEnumerable<TEnum> modifiers)
      where TEnum : struct, Enum
    {
        return string.Join(' ', modifiers.Select(GetModifier));
    }

    private string GetModifier<TEnum>(TEnum modifier)
        where TEnum : struct, Enum
    {
        var name = Enum.GetName(modifier);
        if (string.IsNullOrEmpty(name))
            return string.Empty;

        var result = new StringBuilder();
        foreach (var character in name)
        {
            if (char.IsUpper(character) && result.Length > 0)
                result.Append(' ');

            result.Append(char.ToLower(character));
        }

        return result.ToString();
    }

    private string BuildMethodSignature(Method method, IEnumerable<string> parameters)
    {
        var accessModifier = method.AccessModifier is null
            ? string.Empty
            : $"{GetModifier(method.AccessModifier.Value)} ";

        var methodModifiers = method.MethodModifiers.Any()
            ? $"{GetMultipleModifiers(method.MethodModifiers)} "
            : string.Empty;

        var returnType = method.ReturnType is null
            ? string.Empty
            : $"{GetTypeName(method.ReturnType)} ";

        return $"{accessModifier}{methodModifiers}{returnType}{method.Name}({string.Join(", ", parameters)})";
    }

    private void AppendConstructorCalls(StringBuilder sb, Method method)
    {
        if (method.BaseParameters.Any())
            sb.Append($" : base({string.Join(", ", method.BaseParameters)})");

        if (method.ThisParameters.Any())
            sb.Append($" : this({string.Join(", ", method.ThisParameters)})");
    }

    private void AppendMethodBody(StringBuilder sb, Method method)
    {
        sb.AppendLine();
        sb.AppendLine("{");

        if (method.Content != null)
            sb.Append(method.Content.ShiftEachLineWithIndentation(_tabSpaces));

        sb.AppendLine("}");
    }

    private string BuildPropertySignature(Property property)
    {
        var accessModifier = property.AccessModifier is null
            ? string.Empty
            : $"{GetModifier(property.AccessModifier.Value)} ";

        var modifiers = property.Modifiers.Any()
            ? GetMultipleModifiers(property.Modifiers)
            : string.Empty;

        var propertyType = property.Type is null
            ? property.TypeAsString
            : GetTypeName(property.Type);

        return $"{accessModifier}{modifiers}{propertyType} {property.Name}";
    }

    private async void AppendPropertyBody(StringBuilder sb, Property property)
    {
        sb.AppendLine();
        sb.AppendLine("{");

        if (property.Getter != null)
            sb.AppendLine((await GenerateMethodAsync(property.Getter)).ShiftEachLineWithIndentation(_tabSpaces));

        if (property.Setter != null)
            sb.AppendLine((await GenerateMethodAsync(property.Setter)).ShiftEachLineWithIndentation(_tabSpaces));

        sb.AppendLine("}");
    }

    private async Task AppendUsings(StringBuilder sb, IEnumerable<Using> usings, IEnumerable<StaticUsing> staticUsings, CancellationToken token)
    {
        foreach (var @using in usings)
            sb.AppendLine(await GenerateUsingAsync(@using, token));

        if (usings.Any())
            sb.AppendLine();

        foreach (var staticUsing in staticUsings)
            sb.AppendLine(await GenerateStaticUsingAsync(staticUsing, token));

        if (staticUsings.Any())
            sb.AppendLine();
    }

    private async Task AppendEntitiesAsync<T>(
        StringBuilder sb,
        IEnumerable<T> entities,
        Func<T, CancellationToken, Task<string>> generateAsync,
        CancellationToken token)
    {
        foreach (var entity in entities)
        {
            sb.AppendLine(await generateAsync(entity, token));
            sb.AppendLine();
        }
    }

    #endregion
}
