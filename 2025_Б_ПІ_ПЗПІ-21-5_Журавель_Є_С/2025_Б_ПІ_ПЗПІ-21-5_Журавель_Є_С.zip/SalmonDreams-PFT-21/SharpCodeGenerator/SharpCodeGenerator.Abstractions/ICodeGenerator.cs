﻿using SharpCodeGenerator.Entities;

namespace SharpCodeGenerator.Abstractions;

/// <summary>
/// Defines a contract for generating code-related constructs asynchronously.
/// </summary>
/// <typeparam name="TResult">The type of the result returned by the code generation methods.</typeparam>
public interface ICodeGenerator<TResult>
{
    /// <summary>
    /// Asynchronously generates a code representation for the specified attribute.
    /// </summary>
    /// <param name="attribute">The attribute entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateAttributeAsync(Entities.Attribute attribute, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified class.
    /// </summary>
    /// <param name="class">The class entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateClassAsync(Class @class, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified event.
    /// </summary>
    /// <param name="event">The event entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateEventAsync(Event @event, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified field.
    /// </summary>
    /// <param name="field">The field entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateFieldAsync(Field field, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified file.
    /// </summary>
    /// <param name="file">The file entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateFileAsync(Entities.File file, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified method.
    /// </summary>
    /// <param name="method">The method entity to be transformed into code.</param>
    /// <param name="isInterface">Indicates whether the method is part of an interface.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateMethodAsync(Method method, bool isInterface = false, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified parameter.
    /// </summary>
    /// <param name="parameter">The parameter entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateParameterAsync(Parameter parameter, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a code representation for the specified property.
    /// </summary>
    /// <param name="property">The property entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GeneratePropertyAsync(Property property, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a static using directive for the specified static using entity.
    /// </summary>
    /// <param name="staticUsing">The static using entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateStaticUsingAsync(StaticUsing staticUsing, CancellationToken token = default);

    /// <summary>
    /// Asynchronously generates a using directive for the specified using entity.
    /// </summary>
    /// <param name="using">The using entity to be transformed into code.</param>
    /// <param name="token">An optional cancellation token to cancel the operation if needed.</param>
    Task<TResult> GenerateUsingAsync(Using @using, CancellationToken token = default);
}
