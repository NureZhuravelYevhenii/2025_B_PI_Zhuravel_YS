﻿namespace SharpCodeGenerator.Extensions;

public static class PropertyTypeExtensions
{
    private static Type? GetTypeFromPropertyType(PropertyType propertyType) => propertyType switch
    {
        PropertyType.String => typeof(string),
        PropertyType.Long => typeof(long),
        PropertyType.Bool => typeof(bool),
        PropertyType.DateTime => typeof(DateTime),
        PropertyType.Decimal => typeof(decimal),
        PropertyType.Int => typeof(int),
        _ => null,
    };
}
